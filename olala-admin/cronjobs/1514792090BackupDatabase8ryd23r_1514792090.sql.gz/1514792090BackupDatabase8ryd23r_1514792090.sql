-- [MySQL -  Database Backup] Created time: 01/01/2018 - 14:34:50

-- Host: localhost
-- Server version: 5.6.20
-- Collation: utf8_general_ci
-- Time zone: SE Asia Standard Time

-- Database: ol_shome2


CREATE TABLE `olala3w_article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `article_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `price` float NOT NULL DEFAULT '0',
  `block` int(11) NOT NULL DEFAULT '0',
  `flat` int(11) NOT NULL DEFAULT '0',
  `open_sale` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `upload_id` bigint(20) NOT NULL DEFAULT '0',
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `youtube_img` varchar(255) NOT NULL DEFAULT 'no',
  `tags` varchar(255) NOT NULL,
  `tags_2` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `share` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=916 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_article VALUES('890','428','Giới thiệu S - Home','gioi-thieu-s-home','','','','no','','','0','0','0','0','0','1882','','<div class=\"youtube-embed-wrapper\" style=\"position:relative;padding-bottom:56.25%;padding-top:30px;height:0;overflow:hidden\"><iframe allowfullscreen=\"\" frameborder=\"0\" height=\"360\" src=\"https://www.youtube.com/embed/64lrBPb28c4\" style=\"position:absolute;top:0;left:0;width:100%;height:100%\" width=\"640\"></iframe></div>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>SCDA is a multi-disciplinary architectural practice established in 1995. Founding Principal and Design Director Soo K. Chan was the recipient of the inaugural President’s Design Award, Singapore Designer of the Year and is part of the Panel of Designers for Poliform. SCDA was awarded the inaugural Royal Institute of British Architects Award for International&nbsp; Excellence&nbsp; (2016);&nbsp; the&nbsp; RIBA&nbsp; International&nbsp; Award&nbsp; for&nbsp; OneKL&nbsp; (2012)&nbsp; and&nbsp; the&nbsp; Lincoln&nbsp; Modern&nbsp; (2003); and&nbsp; the&nbsp; SIA-Getz&nbsp; Architecture&nbsp; Prize&nbsp; for&nbsp; Emergent&nbsp; Architecture&nbsp; in&nbsp; Asia&nbsp; (2006),&nbsp; in&nbsp; addition&nbsp; to&nbsp; nine&nbsp; Chicago Athenaeum International Architecture Awards.</p>\r\n\r\n<p>SCDA’s&nbsp; designs&nbsp; strive&nbsp; for&nbsp; tranquility&nbsp; and&nbsp; calmness&nbsp; qualified&nbsp; by&nbsp; space,&nbsp; light&nbsp; and&nbsp; structural&nbsp; order.&nbsp;&nbsp;&nbsp; Architectural expressions are distilled to capture the spiritual essence of ‘place’. Its architecture and interiors are inspired by the cultural&nbsp; and&nbsp; climatic&nbsp; nuances&nbsp; of&nbsp; its&nbsp; context,&nbsp; integrating&nbsp; landscape,&nbsp; water&nbsp; features&nbsp; and&nbsp; blurring&nbsp; the&nbsp; distinction between&nbsp; interior&nbsp; and&nbsp; exterior.&nbsp;&nbsp;&nbsp; Spaces&nbsp; are&nbsp; often&nbsp; characterized&nbsp; by&nbsp; lush&nbsp; gardens,&nbsp; water&nbsp; courts&nbsp; and&nbsp; air&nbsp; wells, engendering&nbsp; a&nbsp; sensuous&nbsp; engagement &nbsp;with&nbsp; the&nbsp; elements.&nbsp; Projects display sensitivity&nbsp; to&nbsp; the&nbsp; inherent&nbsp; beauty&nbsp; of natural materials expressed through clarity in construction details and elemental architectural expression.</p>\r\n\r\n<p>SCDA projects have set benchmark sales prices for high-end luxury level condominiums in Singapore. These include The Ladyhill, The Boulevard Residence, The Marq and Nassim Park Residences.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Soundtrack:&nbsp;<em>Orteip</em>&nbsp;by&nbsp;<strong><a href=\"https://soundcloud.com/sense\">Sense</a></strong></p>\r\n\r\n<p><img .=\"\" alt=\"\" data-enlarge=\"http://images.scdaarchitects.com/www_scdaarchitects_com/Office_Photo_10.jpg\" height=\"330\" src=\"http://images.scdaarchitects.com/www_scdaarchitects_com/Office_Photo_11.jpg\" width=\"630\" /></p>\r\n\r\n<p><img .=\"\" alt=\"\" data-enlarge=\"http://images.scdaarchitects.com/www_scdaarchitects_com/Office_Photo_20.jpg\" height=\"332\" src=\"http://images.scdaarchitects.com/www_scdaarchitects_com/Office_Photo_21.jpg\" width=\"390\" /></p>\r\n\r\n<p><img .=\"\" alt=\"\" data-enlarge=\"http://images.scdaarchitects.com/www_scdaarchitects_com/Office_Photo_40.jpg\" height=\"332\" src=\"http://images.scdaarchitects.com/www_scdaarchitects_com/Office_Photo_41.jpg\" width=\"244\" /></p>\r\n','','no','','','1','0','0','90','1511803680','1512414362','1');
INSERT INTO olala3w_article VALUES('892','429','Ưu điểm của sàn gỗ công nghiệp','uu-diem-cua-san-go-cong-nghiep','','','','uu-diem-cua-san-go-cong-nghiep-1512405521.png','','','0','0','0','0','0','1885','Bên cạnh khả năng cách âm, cách nhiệt tốt, sàn gỗ công nghiệp có tác dụng điều hòa không khí, ấm về mùa đông, mát về mùa hè.','<p>Với ưu điểm điều hòa không khí, ấm về mùa đông và mát về mùa hè, xu hướng dùng sàn gỗ trong trang trí nội thất ngày càng được nhiều gia đình lựa chọn.</p>\r\n\r\n<p>Sàn gỗ công nghiệp được sản xuất từ bột gỗ tự nhiên kết hợp với nguyên liệu và công nghệ cao. Vì vậy, sản phẩm có thể thay thế sàn gỗ tự nhiên. Bên cạnh đó, sàn gỗ công nghiệp được xử lý tốt về chống mọt, cong vênh, đảm bảo độ bóng và sự đồng đều của sản phẩm khi sử dụng với số lượng lớn. Việc lót sàn nhà bằng gỗ còn giúp không gian căn hộ sang trọng, ấm cúng hơn.</p>\r\n\r\n<p><img alt=\"uu-diem-cua-san-go-cong-nghiep\" data-natural-width=\"500\" data-was-processed=\"true\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/Image-ExtractWord-0-Out-4064-1512113173.png\" /></p>\r\n\r\n<p>Khi lựa chọn sàn gỗ công nghiệp, gia chủ nên lưu ý sự phù hợp với phong cách thiết kế, bài trí tổng thể của ngôi nhà.</p>\r\n\r\n<p>Có hai phương thức bài trí chính là tương đồng và tương phản. Với cách trang trí tương đồng, sàn nhà sẽ có màu sắc ton sur ton với các thiết bị nội thất khác như tường nhà, bàn ghế, tủ, giá sách. Với phong cách tương phản, tất cả vật dụng trong nhà sẽ có màu sắc đối lập với sàn nhà.&nbsp;</p>\r\n\r\n<p><img alt=\"uu-diem-cua-san-go-cong-nghiep-1\" data-was-processed=\"true\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/Image-ExtractWord-1-Out-2249-1512113173.png\" /></p>\r\n\r\n<p>Ngoài ra, sàn gỗ còn giúp không gian căn phòng trở nên rộng rãi, thông thoáng. Những căn phòng nhỏ nên chọn loại sàn gỗ có nhiều miếng ghép nhỏ và gam màu sáng. Những căn phòng không gian rộng nên chọn sàn gỗ có gam màu tối, lát gỗ to để căn phòng trông ấm cúng, gọn gàng.</p>\r\n\r\n<p>Với nhiều ưu điểm, sàn gỗ công nghiệp ngày càng chiếm được lòng tin và sự tín nhiệm của người tiêu dùng. Tuy nhiên, thị trường sàn gỗ đa dạng dễ khiến người bối rối trong việc lựa chọn sàn gỗ hội tụ đầy đủ các yếu tố khả quan, phù hợp với không gian tổ ấm.</p>\r\n\r\n<p>\"Trên thị trường có nhiều loại sàn gỗ trôi nổi, đòi hỏi người tiêu dùng phải đưa ra quyết định sáng suốt. Hiện tại, sản phẩm sàn gỗ xuất xứ từ Thụy Sĩ - sàn gỗ công nghiệp Kronoswiss đạt tiêu chuẩn châu Âu được nhiều khách hàng đặt mua. Nó có khả năng chịu nước lên tới 72 giờ\", anh Hoàng - quản lý một showroom nội thất (Cát Linh, Hà Nội) cho biết.</p>\r\n\r\n<p><img alt=\"uu-diem-cua-san-go-cong-nghiep-2\" data-was-processed=\"true\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/Image-494433549-ExtractWord-2-3370-2555-1512113173.png\" /></p>\r\n\r\n<p>Ngoài khả năng chịu nước tốt, sàn gỗ Thụy Sĩ có gần 50 màu sắc với nhiều loại vân gỗ: màu truyền thống mang lại nét sang trọng, cổ điển đến những màu sáng cho không gian hiện đại. Đặc biệt, bề mặt sàn gỗ đa dạng với loại SA bề mặt Satin, WG sần thường... mang đến cho khách hàng nhiều lựa chọn.</p>\r\n\r\n<p>Điểm đặt biệt nữa là cốt gỗ sạch, không chứa chất độc hại, an toàn cho sức khỏe người sử dụng.</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Thế Đan</strong></p>\r\n','','no','[\"Kiến trúc\",\"Nhà ở\",\"Đà Nẵng\"]','[\"kien-truc\",\"nha-o\",\"da-nang\"]','1','0','0','7','1511714280','1513670502','1');
INSERT INTO olala3w_article VALUES('893','429','Nhà Sài Gòn 42 m2 như rộng gấp đôi nhờ dùng tông trắng','nha-sai-gon-42-m2-nhu-rong-gap-doi-nho-dung-tong-trang','','','','nha-sai-gon-42-m2-nhu-rong-gap-doi-nho-dung-tong-trang-1512405644.jpg','','','0','0','0','0','0','1886','Toàn bộ tường, trần, sàn... đều có màu trắng giúp không gian thoáng đãng và ánh sáng lan tỏa tốt.','<p><img alt=\"Nhà Sài Gòn 42 m2 như rộng gấp đôi nhờ dùng tông trắng\" data-component-caption=\"&lt;p&gt;\r\n	Căn nhà của cặp vợ chồng ở quận Bình Thạnh (TP HCM) nằm trên một mảnh đất dạng ống.&lt;/p&gt;\" data-reference-id=\"25253748\" data-src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-1-1512118808_680x0.jpg\" data-was-processed=\"true\" id=\"vne_slide_image_0\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-1-1512118808_680x0.jpg\" /></p>\r\n\r\n<p>Căn nhà của cặp vợ chồng ở quận Bình Thạnh (TP HCM) nằm trên một mảnh đất dạng ống.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt=\"Nhà Sài Gòn 42 m2 như rộng gấp đôi nhờ dùng tông trắng\" data-component-caption=\"&lt;p&gt;\r\n	Khu đất có diện tích 42 m2 nằm giữa một khu dân cư nhà cửa san sát với mặt thoáng duy nhất khá hẹp (3,5m) nhìn ra đường. Bởi vậy, gia chủ mong muốn có một không gian sống kín đáo, an toàn nhưng vẫn phải có nhiều ánh sáng tự nhiên, thông gió tốt.&lt;/p&gt;\" data-reference-id=\"25253749\" data-src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-2-1512118809_680x0.jpg\" data-was-processed=\"true\" id=\"vne_slide_image_1\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-2-1512118809_680x0.jpg\" /></p>\r\n\r\n<p>Khu đất có diện tích 42 m2 nằm giữa một khu dân cư nhà cửa san sát với mặt thoáng duy nhất khá hẹp (3,5m) nhìn ra đường. Bởi vậy, gia chủ mong muốn có một không gian sống kín đáo, an toàn nhưng vẫn phải có nhiều ánh sáng tự nhiên, thông gió tốt.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt=\"Nhà Sài Gòn 42 m2 như rộng gấp đôi nhờ dùng tông trắng\" data-component-caption=\"&lt;p&gt;\r\n	Mặt tiền của nhà sử dụng khung thép lưới giúp cho không khí lưu thông được nhưng vẫn đảm bảo riêng tư.&lt;/p&gt;\r\n&lt;p&gt;\r\n	 &lt;/p&gt;\" data-reference-id=\"25253750\" data-src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-3-1512118810_680x0.jpg\" data-was-processed=\"true\" id=\"vne_slide_image_2\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-3-1512118810_680x0.jpg\" /></p>\r\n\r\n<p>Mặt tiền của nhà sử dụng khung thép lưới giúp cho không khí lưu thông được nhưng vẫn đảm bảo riêng tư.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt=\"Nhà Sài Gòn 42 m2 như rộng gấp đôi nhờ dùng tông trắng\" data-component-caption=\"&lt;p&gt;\r\n	Đội thiết kế của công ty Kientruc O đưa ra giải pháp lấy sáng chính cho nhà từ khoảng giếng trời lớn, khơi gợi cảm giác rộng mở từ tầng một lên cao.&lt;/p&gt;\" data-reference-id=\"25253751\" data-src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-5-1512118812_680x0.jpg\" data-was-processed=\"true\" id=\"vne_slide_image_3\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-5-1512118812_680x0.jpg\" /></p>\r\n\r\n<p>Đội thiết kế của công ty Kientruc O đưa ra giải pháp lấy sáng chính cho nhà từ khoảng giếng trời lớn, khơi gợi cảm giác rộng mở từ tầng một lên cao.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt=\"Nhà Sài Gòn 42 m2 như rộng gấp đôi nhờ dùng tông trắng\" data-component-caption=\"&lt;p&gt;\r\n	Các khu vực chức năng được bố trí gọn gàng, có sự chuyển tiếp tự nhiên, nhẹ nhàng. &lt;/p&gt;\r\n&lt;p&gt;\r\n	 &lt;/p&gt;\" data-reference-id=\"25253752\" data-src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-6-1512118812_680x0.jpg\" data-was-processed=\"true\" id=\"vne_slide_image_4\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-6-1512118812_680x0.jpg\" /></p>\r\n\r\n<p>Các khu vực chức năng được bố trí gọn gàng, có sự chuyển tiếp tự nhiên, nhẹ nhàng.&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt=\"Nhà Sài Gòn 42 m2 như rộng gấp đôi nhờ dùng tông trắng\" data-component-caption=\"&lt;p&gt;\r\n	Khoảng giếng trời cũng là điểm liên kết chính giữa bố mẹ và hai con nhỏ.&lt;/p&gt;\" data-reference-id=\"25253753\" data-src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-7-1512118813_680x0.jpg\" data-was-processed=\"true\" id=\"vne_slide_image_5\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-7-1512118813_680x0.jpg\" /></p>\r\n\r\n<p>Khoảng giếng trời cũng là điểm liên kết chính giữa bố mẹ và hai con nhỏ.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt=\"Nhà Sài Gòn 42 m2 như rộng gấp đôi nhờ dùng tông trắng\" data-component-caption=\"&lt;p&gt;\r\n	Ngôi nhà sử dụng rất nhiều màu trắng từ sàn, trần, cầu thang, lan can giúp cho ánh sáng lan tỏa, phản chiếu tốt hơn. Cây xanh được bố trí ở khắp nơi giúp cho không gian màu trắng không có cảm giác lạnh lẽo.&lt;/p&gt;\" data-reference-id=\"25253754\" data-src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-8-1512118813_680x0.jpg\" data-was-processed=\"true\" id=\"vne_slide_image_6\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-8-1512118813_680x0.jpg\" /></p>\r\n\r\n<p>Ngôi nhà sử dụng rất nhiều màu trắng từ sàn, trần, cầu thang, lan can giúp cho ánh sáng lan tỏa, phản chiếu tốt hơn.&nbsp;Cây xanh được bố trí ở khắp nơi giúp cho không gian màu trắng không có cảm giác lạnh lẽo.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt=\"Nhà Sài Gòn 42 m2 như rộng gấp đôi nhờ dùng tông trắng\" data-component-caption=\"&lt;p&gt;\r\n	Kiến trúc sư cũng sử dụng nhiều cửa kính nên các phòng có nhiều ánh sáng và trông rộng rãi hơn.&lt;/p&gt;\" data-reference-id=\"25253755\" data-src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-10-1512118814_680x0.jpg\" data-was-processed=\"true\" id=\"vne_slide_image_7\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-10-1512118814_680x0.jpg\" /></p>\r\n\r\n<p>Kiến trúc sư cũng sử dụng nhiều cửa kính nên các phòng có nhiều ánh sáng và trông rộng rãi hơn.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt=\"Nhà Sài Gòn 42 m2 như rộng gấp đôi nhờ dùng tông trắng\" data-component-caption=\"&lt;p&gt;\r\n	Nội thất gỗ có tông màu trầm, kết hợp với màu trắng nên không bị già cỗi. Thay vào đó. ngôi nhà mới trở nên ấm cúng và thân thuộc hơn.&lt;/p&gt;\" data-reference-id=\"25253756\" data-src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-11-1512118815_680x0.jpg\" data-was-processed=\"true\" id=\"vne_slide_image_8\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-11-1512118815_680x0.jpg\" /></p>\r\n\r\n<p>Nội thất gỗ có tông màu trầm, kết hợp với màu trắng nên không bị già cỗi. Thay vào đó. ngôi nhà mới trở nên ấm cúng và thân thuộc hơn.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt=\"Nhà Sài Gòn 42 m2 như rộng gấp đôi nhờ dùng tông trắng\" data-component-caption=\"&lt;p&gt;\r\n	Phòng ngủ chính với hai nguồn sáng từ mặt tiền và giếng trời, không cần dùng đèn vào ban ngày.&lt;/p&gt;\" data-reference-id=\"25253757\" data-src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-12-1512118815_680x0.jpg\" data-was-processed=\"true\" id=\"vne_slide_image_9\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/nha-304-12-1512118815_680x0.jpg\" /></p>\r\n\r\n<p>Phòng ngủ chính với hai nguồn sáng từ mặt tiền và giếng trời, không cần dùng đèn vào ban ngày.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Ban Mai</strong><br />\r\nẢnh:&nbsp;<em>Oki Hiroyuki</em></p>\r\n','','no','[\"Kiến trúc\",\"Nhà ở\",\"Đà Nẵng\"]','[\"kien-truc\",\"nha-o\",\"da-nang\"]','1','0','0','7','1511714340','1513759379','1');
INSERT INTO olala3w_article VALUES('894','429','Căn bếp Sài Gòn vừa làm đã phải phá để sửa lại','can-bep-sai-gon-vua-lam-da-phai-pha-de-sua-lai','','','','can-bep-sai-gon-vua-lam-da-phai-pha-de-sua-lai-1512405943.jpg','','','0','0','0','0','0','1887','Chủ nhà mua thêm máy rửa bát làm quà sinh nhật cho vợ mà không tính chỗ đặt thiết bị trong bếp.','<p>Trước khi xây sửa nhà, các kiến trúc sư thường tìm hiểu kỹ nhu cầu, thói quen của gia chủ. Đặc biệt với khu bếp, người thiết kế sẽ phải hỏi cặn kẽ về người nội trợ chính trong gia đình, các yêu cầu về thiết bị gia dụng... để từ đó có cách bố trí phù hợp.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"can-bep-sai-gon-vua-lam-da-phai-pha-de-sua-lai\" data-natural-width=\"500\" data-pwidth=\"500\" data-was-processed=\"true\" data-width=\"500\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/may-rua-bat-5539-1512102454.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Mỗi gia đình có nhiều thiết bị khác nhau nên cần tính toán kỹ khi thiết kế bếp. Ảnh minh họa:&nbsp;<em>SKB.</em></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Tuy nhiên, một số chủ nhà có thể thay đổi nhu cầu bất ngờ hoặc do thi công không chuẩn nên các căn bếp dù mới vẫn phải sửa lại để phù hợp hơn.&nbsp;<strong>KTS Phạm Thanh Truyền chia sẻ một số trường hợp mà anh đã gặp phải:</strong></p>\r\n\r\n<p>Năm 2015, tôi nhận thiết kế nội thất căn hộ cao cấp cho gia đình ở Sài Gòn. Tôi dặn anh chị chủ nhà có nhu cầu gì thì liệt kê ra hết, nhất là các thiết bị sẽ dùng sau này. Người chồng rất yêu vợ con nên anh âm thầm mua máy rửa bát để tặng nhân dịp sinh nhật chị. Anh im lặng và không hề cung cấp thông tin cho ai, kể cả kiến trúc sư. Bởi anh nghĩ việc bổ sung thêm một thiết bị cũng không quá phức tạp.</p>\r\n\r\n<p>Khi gian bếp đã được thi công hoàn chỉnh cũng đến ngày sinh nhật người vợ, chị hạnh phúc và bất ngờ khi nhận được món quà của chồng. Hôm sau, hai vợ chồng mới báo cho kiến trúc sư: \"Nhà anh chị có thêm máy rửa bát nhé!\".</p>\r\n\r\n<p>Để lắp chiếc máy này phải có đủ không gian chiều ngang 60 cm, dọc 60 cm, cao 80 cm. Ngoài ra còn cần nguồn cung cấp điện, nước, kết nối thu hồi nước thải. Bởi vậy, đội thi công buộc phải phá một phần tủ bếp dưới ra để làm lại, gây tốn kém và lộn xộn.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"can-bep-sai-gon-vua-lam-da-phai-pha-de-sua-lai-1\" data-natural-width=\"500\" data-pwidth=\"500\" data-was-processed=\"true\" data-width=\"500\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/top-ne-5369-1512101613.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Kính cường lực dán tường bếp dễ vệ sinh nhưng không thể khoan, đục treo thêm kệ. Ảnh minh họa: LWK.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p><strong>Năm 2016, một khu bếp do tôi thiết kế gặp vấn đề do trình độ tay nghề của người thợ.&nbsp;</strong>Cặp vợ chồng ở Đà Lạt rất tâm huyết và chăm chút cho khu nấu nướng của gia đình. Tuy nhiên, khi thi công xong, kiến trúc sư lên nghiệm thu thì phát hiện một số lỗi ảnh hưởng đến sử dụng.</p>\r\n\r\n<p>Tủ bếp có bề mặt đổ bê tông, lắp cánh cửa gỗ vào để bền chắc và tiết kiệm. Người thợ đổ bê tông cho mặt bếp quá dày, sau đó lại đôn nền phía bên trong tủ quá cao. Bởi vậy, khoảng không gian còn lại trong tủ không đủ để lọt bình ga. Do đó, gia chủ phải tiến hành đục bớt bê tông.</p>\r\n\r\n<p>Thêm vào đó, theo thiết kế ban đầu, xung quanh bếp sẽ ốp gạch nhưng đội thợ tư vấn dán kính cường lực cho dễ lau chùi. Đến khi lắp kính xong, gia chủ mới thông báo họ thích làm kệ để các lọ gia vị gắn trên tường bếp. Nhưng vì không thể khoan kính cường lực được, nên lớp kính mới toanh bị bóc ra để sửa lại cho đúng sở thích.</p>\r\n\r\n<p><strong>Ngoài các trường hợp trên, tôi còn gặp một số lỗi thiết kế phổ biến như:</strong></p>\r\n\r\n<p>- Không đủ ổ cắm điện cho khu vực bếp, phải kéo dây nối khi có nhiều nhu cầu cùng lúc.</p>\r\n\r\n<p>- Không thiết kế ống thoát khí thải cho máy hút mùi.</p>\r\n\r\n<p>- Không thiết kế nguồn sáng cho đáy tủ treo, gây bất tiện cho việc làm bếp vào ban đêm.</p>\r\n\r\n<p>- Không liệt kê và dự trù đủ chỗ cho các vật dụng sẽ sử dụng. Khi muốn lắp thêm thì phải sửa bếp, nhất là khi ngày càng có thêm nhiều thiết bị tiện lợi như lò nướng, máy rửa bát...</p>\r\n\r\n<p>- Bố trí 3 thiết bị chính sai nguyên lý nên người làm bếp phải di chuyển nhiều hơn. Cách bố trí đúng là: tủ lạnh - chậu rửa - bếp.</p>\r\n\r\n<p>- Để lò vi sóng trên tủ lạnh có thể gây rơi vỡ, nguy hiểm hơn cho trẻ nhỏ.</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Phạm Thanh Truyền</strong></p>\r\n','','no','[\"Kiến trúc\",\"Nhà ở\",\"Sài Gòn\"]','[\"kien-truc\",\"nha-o\",\"sai-gon\"]','1','0','1','17','1511714700','1514617533','1');
INSERT INTO olala3w_article VALUES('895','429','Giường siêu rộng - giải pháp cho gia đình muốn con ngủ chung','giuong-sieu-rong-giai-phap-cho-gia-dinh-muon-con-ngu-chung','','','','giuong-sieu-rong-giai-phap-cho-gia-dinh-muon-con-ngu-chung-1512406015.jpg','','','0','0','0','0','0','1888','Một số bố mẹ thích ngủ chung với con nhỏ, trong khi nhiều người cho rằng con nên ngủ riêng càng sớm càng tốt.','<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"giuong-sieu-rong-giai-phap-cho-gia-dinh-muon-con-ngu-chung\" data-natural-width=\"450\" data-pwidth=\"500\" data-was-processed=\"true\" data-width=\"450\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/giupng-1831-1512095015.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Mẫu giường cực đại giúp cho cả gia đình đông người nằm thoải mái. Ảnh: ACE.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Có vô số những cuộc tranh luận không hồi kết trên mạng về việc bố mẹ ngủ cùng con cái. Và giờ đây, một mẫu giường cỡ đại còn khiến cuộc tranh luận này sôi nổi hơn.</p>\r\n\r\n<p>Một hãng nội thất ở Los Angeles (Mỹ) đưa ra ý tưởng làm những chiếc giường ngoại cỡ đủ cho cả đại gia đình. Giường có chiều rộng 3,6m, gần gấp đôi những chiếc giường thông thường.</p>\r\n\r\n<p>Bởi vậy, nếu khéo thu xếp, bốn người lớn sẽ nằm vừa trên giường. Do đó, các cặp vợ chồng có thể ngủ cùng ba đứa trẻ nhỏ. Đi kèm với giường siêu rộng, hãng nội thất cũng cung cấp đầy đủ ga, chăn có cỡ lớn.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"giuong-sieu-rong-giai-phap-cho-gia-dinh-muon-con-ngu-chung-1\" data-natural-width=\"450\" data-pwidth=\"500\" data-was-processed=\"true\" data-width=\"450\" src=\"https://i-giadinh.vnecdn.net/2017/12/01/Untitled-4-7483-1512095015.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Nhiều người không muốn con phải ngủ độc lập từ khi quá nhỏ. Ảnh:&nbsp;<em>The Sun.</em></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Theo<em>&nbsp;The Sun</em>, giường chỉ được phân phối ở Mỹ nhưng đã có rất nhiều ý kiến trái chiều của các bố mẹ trên khắp thế giới. Những người ủng hộ cho rằng, đó là thiết kế thông minh khi giải quyết được tình hình chật chội của các gia đình thích ngủ cùng con.</p>\r\n\r\n<p>Trong khi đó, những người phản đối cho rằng, giường có rộng cũng chỉ nên dùng cho bố mẹ nằm ngủ nghỉ thoải mái hơn. Ngoài ra, ý tưởng làm giường siêu rộng bắt nguồn từ nhu cầu của một khách hàng nữ. Cô muốn các con có thể ở quanh mình khi nghe truyện trước giờ đi ngủ chứ không phải ngủ cùng.</p>\r\n\r\n<p>Theo nghiên cứu của Bộ Y tế Anh, nơi ngủ an toàn nhất cho trẻ dưới 6 tháng là trong cũi nhỏ đặt ở phòng của bố mẹ. Thêm vào đó, giường có giá khá cao, từ 2.000 USD trở lên nên không phải gia đình nào cũng sẵn sàng bỏ tiền ra sắm.</p>\r\n\r\n<p style=\"text-align: right;\"><strong>An Yên</strong></p>\r\n','','no','[\"Kiến trúc\",\"Nhà ở\"]','[\"kien-truc\",\"nha-o\"]','0','0','1','155','1511714760','1514617535','1');
INSERT INTO olala3w_article VALUES('896','439','Nhà tôi bỏ phí giường tầng từ khi mua 2 năm trước','nha-toi-bo-phi-giuong-tang-tu-khi-mua-2-nam-truoc','','','','nha-toi-bo-phi-giuong-tang-tu-khi-mua-2-nam-truoc-1512409993.jpg','','','0','0','0','0','0','1889','Khi mới có giường, các con rất háo hức đi chọn mua gối, chăn cùng bố mẹ rồi leo trèo suốt cả ngày.','<p><em>Dưới đây là chia sẻ của chị Nguyễn Thị Hòa (quận Cầu Giấy, Hà Nội) về việc phải bỏ phí chiếc giường tầng còn mới nguyên do không tính hết các bất hợp lý của nó:</em></p>\r\n\r\n<p>Cách đây 2 năm, gia đình tôi làm thêm một phòng trên tầng 4 cho hai cậu con trai nhỏ ngủ riêng. Khi đó, một cháu 8 tuổi, một cháu 4 tuổi. Căn phòng có diện tích 24 m2 (4x6m) khá rộng nên hai vợ chồng định bố trí hai giường đơn. Tuy nhiên, hai cháu lại thích có giường tầng giống như trong các bộ phim xem trên tivi và ở nhà các bạn cùng lớp.</p>\r\n\r\n<p>Thấy các con thích quá, tôi quyết định bỏ ra 12 triệu để mua một chiếc giường tầng bằng gỗ khá chắc chắn. Hôm đó, ngay sau khi lắp giường xong, tôi chở hai con đi chọn mua ga gối hình Doraemon đúng ý các con. Hai bé cũng háo hức không kém, thức tới khuya để xếp những bộ truyện yêu thích nhất lên các ngăn trên giường.</p>\r\n\r\n<p>Tôi cũng thấy ưng ý vì giường có các bậc thang đồng thời là ngăn kéo. Nhờ đó, tôi cất gọn được nhiều đồ chơi, quần áo trái mùa của các con. Ngoài ra, căn phòng trông cũng khá thoáng rộng vì kê hai giường mà chỉ tốn diện tích của một chiếc.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"nha-co-giuong-tang-nhung-con-toi-van-nam-tren-san\" data-natural-width=\"500\" data-pwidth=\"500\" data-was-processed=\"true\" data-width=\"500\" src=\"https://i-giadinh.vnecdn.net/2017/11/30/toplevel-6589-1512017653.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Giường tầng giúp tiết kiệm diện tích nhưng không phải lúc nào cũng hợp với mọi nhà. Ảnh minh họa:&nbsp;<em>Jtday.</em></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p><strong>Tuy nhiên, được ít ngày, chúng tôi mới thấy nhiều điều bất hợp lý khi giường cao 1,75m gần tới sát trần.&nbsp;</strong>Trần nhà tôi khá thấp (2,8m) trong khi gia đình tôi lại thích sử dụng quạt trần treo giữa nhà để làm mát đều toàn bộ phòng.</p>\r\n\r\n<p>Ban đầu, tôi không để ý tới chi tiết này nên kê giường sát bức tường dài 6m. Tuy nhiên, vào ngày nóng bức, tôi phát hoảng khi thấy con trai leo trèo đầu gần chạm vào quạt đang quay. Hai vợ chồng lại hì hụi quay ngang giường sát bức tường ngang 4m cũng là nơi đặt cửa ra vào.</p>\r\n\r\n<p>Không bị vướng quạt trần nữa nhưng giường dài 2,5m lại gần như sát cửa ra vào. Mỗi lần mở cửa, chúng tôi lại có cảm giác khó chịu, vướng víu khi có một khối đồ sộ liền kề.</p>\r\n\r\n<p>Thêm vào đó, khu nhà tôi sát bờ sông nên khá ẩm ướt, nhất là khi trời nồm. Tuy nhiên, kiểu giường tầng cũng khó mắc màn chống muỗi.</p>\r\n\r\n<p><strong>Nhưng điều khiến tôi tiếc nuối nhất là từ khi mua, giường không được sử dụng nhiều như mong muốn.&nbsp;</strong>Thời gian đầu, các con leo trèo, chạy nhảy suốt ngày quanh giường. Bé út 4 tuổi còn khiến tôi nhiều phen \"thót tim\" vì trèo thoăn thoắt đuổi theo anh.</p>\r\n\r\n<p>Tôi để con lớn ngủ ở tầng trên còn con út nằm ở tầng dưới. Nhưng được mấy hôm, cậu cả cũng không chịu vì phần giường tầng trên ngay cạnh một ô cửa sổ nhỏ sát trần. Con bảo: \"Con không ngủ được vì sợ ma ngoài cửa sổ\".</p>\r\n\r\n<p>Phần lớn thời gian bé út lại sang ngủ cùng bố mẹ còn cậu cả xuống tầng dưới ngủ cùng ông bà. Đôi lúc, vợ chồng tôi muốn siết kỷ luật để hai cháu tự lập hơn nên bắt ngủ phòng riêng. Tuy nhiên, con út còn bé vẫn còn sợ ngủ một mình. Cậu anh thì thà nằm trên sàn nhà còn hơn leo lên tầng 2 của giường.&nbsp;</p>\r\n\r\n<p>Kể từ khi mua tới giờ, số lần giường tầng 2 được sử dụng chỉ đếm trên đầu ngón tay. Mang tiếng phòng riêng rộng rãi mà các con không được ngủ thoải mái, có thể gặp nguy hiểm.</p>\r\n\r\n<p>Sau 2 năm, tôi đã cảm thấy chán ngán với kiểu giường này và muốn thanh lý lại để sắm hai chiếc giường đơn. Dù thiệt một ít tiền nhưng tôi nghĩ mình sẽ biết cân nhắc kỹ hơn trước khi mua bất cứ đồ gì.</p>\r\n\r\n<table align=\"center\" border=\"1\" cellpadding=\"1\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<p>KTS Ngọc Anh cho biết, hiện rất nhiều gia đình lựa chọn giường tầng cho trẻ nhỏ. Đây là giải pháp hợp lý với những gia đình có diện tích nhỏ hẹp mà&nbsp;có từ 2 trẻ trở lên. Các em bé thích leo trèo nên rất mê kiểu giường này. Hiện tại, mẫu giường này cũng có nhiều kiểu dáng, màu sắc bắt mắt, phù hợp với bé trai hoặc bé gái.</p>\r\n\r\n			<p>Tuy nhiên, trước khi mua giường, bố mẹ cần phải tính tới hai yếu tố. Đầu tiên là độ tuổi, tính cách của các con. Các bé phải đủ lớn (trên 6 tuổi) để đảm bảo an toàn khi ngủ giường tầng. Bố mẹ cũng cần cân nhắc làm giường chắc chắn, thành giường cao, cầu thang lên xuống dạng bậc. Với các bé quá hiếu động, bố mẹ nên cân nhắc chọn hai giường đơn nhỏ hoặc giường đôi.</p>\r\n\r\n			<p>Thứ hai là bố mẹ cũng cần đo đạc kích thước nhà (ngang, dọc, chiều cao...) và tính toán để kê giường không bị vướng víu đồ đạc trong nhà.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p style=\"text-align: right;\"><strong>Nguyễn Thị Hòa</strong></p>\r\n','','no','[\"Nội thất\",\"Nhà ở\"]','[\"noi-that\",\"nha-o\"]','1','0','0','11','1511632320','1513670583','1');
INSERT INTO olala3w_article VALUES('897','439','Xây nhà 2 tầng diện tích sử dụng 130m2 hết bao nhiêu tiền?','xay-nha-2-tang-dien-tich-su-dung-130m2-het-bao-nhieu-tien','','','','xay-nha-2-tang-dien-tich-su-dung-130m2-het-bao-nhieu-tien-1512410083.jpg','','','0','0','0','0','0','1890','Tôi muốn làm nhà có nội thất đơn giản, hiện đại với 2 phòng ngủ.','<p>Khu đất nhà có tôn có diện tích 66 m2 (5,5x12m). Tôi định làm nhà có phòng khách, bếp, phòng thờ nhỏ, 2 phòng ngủ.</p>\r\n\r\n<p>Hiện tại, tôi có khoảng 700 triệu đồng, không biết có đủ xây dựng nhà hiện đại, nội thất trung bình không. Nếu thiếu, tôi cần chuẩn bị thêm bao nhiêu tiền. Tôi xin cảm ơn.</p>\r\n','','no','[\"Nội thất\",\"Nhà ở\"]','[\"noi-that\",\"nha-o\"]','1','0','0','7','1511632380','1513670570','1');
INSERT INTO olala3w_article VALUES('898','439','Phòng khách tông xanh nên chọn gạch lát màu gì?','phong-khach-tong-xanh-nen-chon-gach-lat-mau-gi','','','','phong-khach-tong-xanh-nen-chon-gach-lat-mau-gi-1512410611.jpg','','','0','0','0','0','0','1891','Tôi dự định lát gạch cho phòng khách nhưng chưa biết chọn màu sắc, họa tiết như thế nào cho phù hợp.','<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"phong-khach-tong-xanh-nen-chon-gach-lat-mau-gi\" data-natural-width=\"500\" data-pwidth=\"500\" data-was-processed=\"true\" data-width=\"500\" src=\"https://i-giadinh.vnecdn.net/2017/11/30/anh-minh-hoa-3166-1512026479.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Ảnh minh họa:&nbsp;<em>FI.</em></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Tôi đang tiến hành cải tạo phòng khách và đã quyết định sơn một mảng tường, mua một số nội thất lớn như sofa, đôn có màu xanh lam. Tôi định lát gạch cho sàn nhà và định chọn loại có hoa văn rực rỡ.</p>\r\n\r\n<p>Tuy nhiên, nhiều người khuyên tôi nên chọn gạch màu trắng hoặc họa tiết màu nhạt. Các anh chị tư vấn giúp nếu tôi chọn gạch hoa nhiều màu thì nhìn nhà có bị lộn xộn lắm không? Tôi xin cảm ơn.</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Tùng</strong></p>\r\n','','no','[\"Nội thất\",\"Nhà ở\"]','[\"noi-that\",\"nha-o\"]','1','0','0','8','1511632920','1513670558','1');
INSERT INTO olala3w_article VALUES('899','439','Độc giả nhận giải tuần 5, 6 cuộc thi thiết kế \'Ý tưởng cho phòng khách thượng lưu\'','doc-gia-nhan-giai-tuan-5-6-cuoc-thi-thiet-ke-y-tuong-cho-phong-khach-thuong-luu','','','','.jpg','','','0','0','0','0','0','1892','Bài dự thi “Phòng khách sang trọng kết nối không gian” và “Phòng khách sang trọng kết nối với thiên nhiên” đã xuất sắc dành giải tuần 5, 6. Bài dự thi “Phòng khách sang trọng kết nối không gian” và “Phòng khách sang trọng kết nối với thiên nhiên” đã xuất sắc dành giải tuần 5, 6.','<p>Cuộc thi thiết kế \"Ý tưởng cho phòng khách thượng lưu\" do VnExpress phối hợp với Công ty LG Electronics Việt Nam tổ chức vừa tìm ra người thắng giải trong hai tuần cuối cuộc thi.</p>\r\n\r\n<p>Căn cứ vào lượng bình chọn trên trang và kết quả chấm điểm theo các tiêu chí của Ban giám khảo, tác phẩm “Phòng khách sang trọng kết nối không gian” của kiến trúc sư Hoàng Linh Lưu và “Phòng khách sang trọng kết nối với thiên nhiên” của kiến trúc sư Trần Lê Duy Anh đã đạt giải nhất bình chọn tuần 5, 6.</p>\r\n\r\n<p>Ở tác phẩm “Phòng khách sang trọng kết nối không gian”, kiến trúc sư Hoàng Linh Lưu cho rằng, yêu cầu cần thiết của một không gian sống là đáp ứng tất cả nhu cầu sinh hoạt cần thiết. Thay vì đưa quá nhiều thứ vào bản thiết kế, kiến trúc sư đã tiết chế về số lượng để tập trung vào chi tiết, giúp nâng tầm không gian.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"polyad\" data-natural-width=\"500\" data-pwidth=\"500\" data-was-processed=\"true\" data-width=\"500\" src=\"https://i-giadinh.vnecdn.net/2017/11/30/29-11-201759-409989160-5258-1512012847.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Tác phẩm “Phòng khách sang trọng kết nối không gian”, kiến trúc sư Hoàng Linh Lưu.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Bề mặt vật liệu trong căn phòng tạo hiệu ứng giúp các sắc màu hòa quyện tự nhiên. Màu của kim loại ánh vàng cùng kính thủy trà giúp kéo không gian trở nên ấm cúng và rộng rãi vì độ phản chiếu.&nbsp;</p>\r\n\r\n<p>Trong tác phẩm “Phòng khách sang trọng kết nối với thiên nhiên” của kiến trúc sư Trần Lê Duy Anh, không gian sống được biến hóa giống như một câu chuyện mà gia chủ muốn kể cho những vị khách ghé thăm. Với căn hộ rộng ba phòng ngủ, mong muốn của chủ nhà là được tận hưởng một không gian sống đúng nghĩa, thoả mãn niềm yêu thích và đam mê cái đẹp.</p>\r\n\r\n<p>Tông màu chính trung tính, kết hợp hài hoà với màu champage và nhấn nhá thêm chút nâu sẫm giúp không gian trở nên gần gũi trong sự lộng lẫy nhẹ nhàng.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"polyad\" data-natural-width=\"500\" data-pwidth=\"500\" data-was-processed=\"true\" data-width=\"500\" src=\"https://i-giadinh.vnecdn.net/2017/11/30/29-11-201711-531425161-7394-1512012847.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Tác phẩm “Phòng khách sang trọng kết nối với thiên nhiên” của kiến trúc sư Trần Lê Duy Anh.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Mỗi món đồ trang trí đều mang vẻ đẹp riêng, từ chiếc đôn, tủ rượu cho đến đèn trang trí, tạo nên một không gian thư thái trong sự kết nối với thiên nhiên qua hệ thống cửa sổ thông thoáng. Bên cạnh đó, mảng xanh nhỏ cùng quầy bar ngoài ban công giúp gia chủ thư giãn sau một ngày làm việc.&nbsp;</p>\r\n\r\n<p>Đạt giải nhất bình chọn tuần, kiến trúc sư Hoàng Linh Lưu và kiến trúc sư Trần Lê Duy Anh sẽ nhận phần quà từ Ban tổ chức là một chiếc TV LG 4K UJ633 43 inch trị giá 11,2 triệu đồng.</p>\r\n\r\n<p>Hai tuần cuối của cuộc thi, ban tổ chức nhận được nhiều thiết kế ấn tượng, có tính ứng dụng cao từ các kiến trúc sư tài năng. Xem chi tiết các thiết kế&nbsp;<a href=\"https://giadinh.vnexpress.net/tin-tuc/y-tuong-cho-phong-khach-thuong-luu/?like_order=0&amp;page=2\" target=\"_blank\">tại đây.</a></p>\r\n\r\n<p style=\"text-align: right;\"><strong>Thế Đan</strong></p>\r\n','','no','[\"Nội thất\",\"Nhà ở\",\"Hà Nội\"]','[\"noi-that\",\"nha-o\",\"ha-noi\"]','1','0','0','65','1511632980','1513670539','1');
INSERT INTO olala3w_article VALUES('905','436','Sai lầm khiến bạn đắp nhiều tiền cho nhà mà vẫn xấu','sai-lam-khien-ban-dap-nhieu-tien-cho-nha-ma-van-xau','','','','sai-lam-khien-ban-dap-nhieu-tien-cho-nha-ma-van-xau-1513651730.jpg','','','0','0','0','0','0','1908','Thích tự trang trí nhà nhưng nhiều người biến nơi ở thành lộn xộn khi chọn màu sắc tùy hứng, bày quá nhiều tranh...','<p>Việc làm đẹp không gian nội thất mang tính chuyên môn, không phải công việc nội trợ hàng ngày. Để việc trang trí hiệu quả, tiết kiệm thời gian, tiền bạc, bạn nên tránh các lỗi sau:</p>\r\n\r\n<p>1. Thiếu sự tư vấn, tham khảo</p>\r\n\r\n<p>Công việc trang trí nhà không nhất thiết cần bản vẽ thiết kế nhưng những người có chuyên môn, kinh nghiệm sẽ có những lời khuyên hữu ích dành cho bạn. Nhờ vậy, bạn sẽ có một kết quả tốt và tiết kiệm chi phí. Bởi vậy, đây là nguyên tắc đầu tiên và quan trọng nhất khi bắt tay vào trang trí nhà.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"9-dieu-can-lam-de-tranh-ton-tien-ma-nha-van-xau\" data-natural-width=\"500\" data-pwidth=\"500\" data-was-processed=\"true\" data-width=\"500\" src=\"https://i-giadinh.vnecdn.net/2017/12/18/top1-9651-1513583765.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Các phòng cần có sự cân bằng màu sắc để không gian sống thư thái. Ảnh:&nbsp;<em>Hà Thành.</em></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>2. Không liệt kê những việc cần làm</p>\r\n\r\n<p>Hãy liệt kê những công việc dự kiến thực hiện trước khi bắt tay vào làm. Điều này sẽ giúp bạn biết việc nào làm trước, việc nào làm sau. Nhờ đó, bạn tránh được việc kê đi kê lại bàn ghế hoặc phát hiện thiếu đồ gì đó dù đã ra cửa hàng nhiều lần.</p>\r\n\r\n<p>3. Không lựa chọn phong cách thống nhất</p>\r\n\r\n<p>Nếu làm tùy hứng, bạn sẽ biến nơi ở thành một \"nồi lẩu thập cẩm\" pha trộn đủ các phong cách. Bạn có thể chọn phong cách trang trí các phòng dựa trên kiến trúc tổng thể của ngôi nhà và lối sống của gia đình. Một phong cách phù hợp sẽ làm tôn giá trị thẩm mỹ của không gian và tạo cảm giác hạnh phúc cho người sống trong đó.</p>\r\n\r\n<p>4. Thiếu sự cân bằng màu sắc</p>\r\n\r\n<p>Bạn nên chú ý đến sự cân bằng giữa gam màu nóng và lạnh, sáng và tối. Chẳng hạn, phòng khách với sơn tường trắng chủ đạo có thể chọn sofa màu trung tính, kết hợp với món đồ trang trí màu nóng tạo điểm nhấn. Bạn không nên phối quá nhiều màu cùng gam nóng hoặc cùng gam lạnh.</p>\r\n\r\n<p>5. Bày quá nhiều đồ ở phòng khách</p>\r\n\r\n<p>Phòng khách là nơi thường bày đồ trang trí. Tuy nhiên, quá nhiều tranh ảnh, đồ lưu niệm sẽ khiến không gian trở nên nhàm chán rối mắt, thiếu điểm nhấn. Bên cạnh đó, bạn cũng gặp khó khăn mỗi khi cần di chuyển đồ hay dọn vệ sinh.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"9-dieu-can-lam-de-tranh-ton-tien-ma-nha-van-xau-1\" data-natural-width=\"500\" data-pwidth=\"500\" data-was-processed=\"true\" data-width=\"500\" src=\"https://i-giadinh.vnecdn.net/2017/12/18/top2-2834-1513583765.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Đồ đạc cần có kích thước tương xứng với diện tích phòng. Ảnh:&nbsp;<em>Hà Thành.</em></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>6. Lạm dụng nhiều điểm nhấn</p>\r\n\r\n<p>Mỗi không gian chỉ cần một điểm nhấn bằng màu sắc, chất liệu để gây ấn tượng. Chẳng hạn, phòng khách chỉ cần điểm thu hút ở khu vực sofa, bàn trà, kệ tivi. Ở phòng ngủ, bạn nên chọn đầu giường còn phòng tắm là bồn rửa và gương.</p>\r\n\r\n<p>7. Chọn đồ có kích thước không phù hợp với diện tích, không gian</p>\r\n\r\n<p>Một trong những nguyên tắc của mỹ học kiến trúc là tỷ lệ. Đồ quá to trong phòng nhỏ hoặc ngược lại, đồ nhỏ trong phòng to đều không đẹp. Vì vậy, bạn cần căn cứ vào hiện trạng và không gian phòng để chọn những món đồ có kích thước tương xứng.</p>\r\n\r\n<p>8. Chọn nhiều đồ nội thất cùng chất liệu</p>\r\n\r\n<p>Nội thất cùng chất liệu sẽ gây sự đơn điệu và nhàm chán. Toàn bộ đồ nội thất làm bằng gỗ dễ gây hiệu ứng này. Hãy khéo léo kết hợp nhiều chất liệu khác của các món đồ trang trí để căn phòng trở nên sống động hơn.</p>\r\n\r\n<p>9. Treo tranh ảnh ngang quá cao hoặc quá thấp</p>\r\n\r\n<p>Tranh ảnh cần treo đúng chỗ, đúng độ cao, phù hợp với không gian để có thể nhìn ngắm - nhất là đối với tranh ảnh nghệ thuật có khổ lớn. Chiếu sáng cho tranh ảnh cũng cần được chú trọng để tác phẩm có thể hiện diện với màu sắc chuẩn. Thông thường, tâm của tranh treo ngang tầm mắt hoặc cao hơn chừng 20-30 cm.</p>\r\n\r\n<p style=\"text-align: right;\"><strong>KTS Đức Anh</strong></p>\r\n','','no','[\"Tin tức\",\"Thông tin thị trường\"]','[\"tin-tuc\",\"thong-tin-thi-truong\"]','1','0','0','1','1513651620','1513651730','1');
INSERT INTO olala3w_article VALUES('906','436','Bí mật trong chiếc chiếu \'hè mát, đông ấm\' của người Nhật','bi-mat-trong-chiec-chieu-he-mat-dong-am-cua-nguoi-nhat','','','','bi-mat-trong-chiec-chieu-he-mat-dong-am-cua-nguoi-nhat-1513651799.jpg','','','0','0','0','0','0','1909','Phần lõi chiếu dày 5,5-6 cm được làm cẩn thận có khả năng đàn hồi tốt, tạo cảm giác êm ái. Phần lõi chiếu dày 5,5-6 cm được làm cẩn thận có khả năng đàn hồi tốt, tạo cảm giác êm ái. Phần lõi chiếu dày 5,5-6 cm được làm cẩn thận có khả năng đàn hồi tốt, tạo cảm giác êm ái.','<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"bi-mat-trong-chiec-chieu-he-mat-dong-am-cua-nguoi-nhat\" data-natural-width=\"500\" data-pwidth=\"500\" data-was-processed=\"true\" data-width=\"500\" src=\"https://i-giadinh.vnecdn.net/2017/12/16/tatami2-6147-1513390232.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Nhiều ngôi nhà hiện đại vẫn có riêng các căn phòng để nằm trên sàn. Ảnh:&nbsp;<em>Vrbo.</em></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Cũng như người Việt Nam, người dân Nhật có truyền thống sử dụng chiếu để nằm nghỉ ngơi. Mỗi khi nghĩ tới những ngôi nhà Nhật, nhiều người sẽ liên tưởng tới những căn phòng trải chiếu tatami cùng cửa kéo shoji... Nơi này có thể là chỗ ngủ, phòng trà, phòng khách.</p>\r\n\r\n<p>Những chiếc chiếu Nhật được gọi tên là tatami bắt nguồn từ động từ tatamu, có nghĩa là \"gập, gấp\". Hơn một nghìn năm trước, những gia đình quý tộc ở Nhật đã bắt đầu dùng chiếu làm thảm ngồi. Sau đó, họ làm những chiếc chiếu khổ lớn để ghép lại với nhau và trải cả phòng. Dần dần, tatami được phổ biến trong cả tầng lớp bình dân.</p>\r\n\r\n<p>Người Nhật cũng có những căn phòng truyền thống trải toàn bộ tatami. Chiều rộng bằng một nửa chiều dài với kích thước&nbsp;91x182 cm.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"bi-mat-trong-chiec-chieu-he-mat-dong-am-cua-nguoi-nhat-1\" data-pwidth=\"500\" data-was-processed=\"true\" data-width=\"450\" src=\"https://i-giadinh.vnecdn.net/2017/12/16/tatami1-5603-1513390232.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Phần lõi là yếu tố chủ chốt đem lại các ưu điểm&nbsp;cho chiếu Nhật. Ảnh:&nbsp;<em>Casadecor.</em></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Nếu lần đầu vào một phòng truyền thống của Nhật, bạn sẽ có cảm giác êm ái khi đi trên lớp chiếu. Mùa hè, bàn chân sẽ cảm thấy mát còn mùa đông cũng bớt đi lạnh lẽo. Lý do chính là do thiết kế cẩn thận, tỉ mỉ của chiếu. Mỗi chiếc gồm 3 phần: Lõi làm từ rơm khô hoặc sợi hóa học; lớp ngoài là chiếu cói; viền&nbsp;bằng vải.</p>\r\n\r\n<p>Lớp lõi đặc biệt dày hơn 5 cm giúp cho chiếu có khả năng đàn hồi tốt, cách nhiệt, thích hợp để bạn đi chân trần, ngồi, hay nằm. Vào mùa hè, chủ nhà có thể nằm, ngồi trực tiếp trên chiếu. Sang đông, gia chủ chỉ cần trải một lớp đệm mỏng là đủ êm ái, đảm bảo sức khỏe.&nbsp;</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"bi-mat-trong-chiec-chieu-he-mat-dong-am-cua-nguoi-nhat-2\" data-natural-width=\"500\" data-pwidth=\"500\" data-was-processed=\"true\" data-width=\"500\" src=\"https://i-giadinh.vnecdn.net/2017/12/16/tatami3-1443-1513390232.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Không gian phòng khách, phòng trà truyền thống. Ảnh minh họa:&nbsp;<em>Decolover.</em></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Tuy nhiên, theo&nbsp;<em>Sora News 24</em>, trong 20 năm qua, nhu cầu sử dụng chiếu tatami ở Nhật giảm còn 2/3, nhiều nghệ nhân không có người kế nghiệp. Lý do là việc bảo quản chiếu không dễ dàng. Người&nbsp;sử dụng phải thay chiếu sau một thời gian sử dụng. Chiếu sẽ bị xước, hư hỏng, khó làm sạch khi bị dính bẩn. Theo thời gian, màu sắc của chiếu sẽ bị bạc đi, trông không còn đẹp mắt như ban đầu. Ngoài ra, với các chủ nhà bận rộn, không vệ sinh chiếu thường xuyên có thể tạo ra sự ẩm mốc.</p>\r\n\r\n<p>Mặc dù vậy, nhiều người Nhật vẫn muốn lưu giữ nét truyền thống này. Những người trong ngành sản xuất chiếu cũng đề xuất làm thêm những căn phòng trải chiếu tatami&nbsp;trong làng Olympic ở Tokyo vào năm 2020.</p>\r\n\r\n<p style=\"text-align: right;\"><strong>An Yên</strong></p>\r\n','','no','[\"Tin tức\",\"Thông tin thị trường\",\"Nhật Bản\",\"Nhà ở\"]','[\"tin-tuc\",\"thong-tin-thi-truong\",\"nhat-ban\",\"nha-o\"]','1','0','0','1','1513651740','1513673615','1');
INSERT INTO olala3w_article VALUES('907','437','Cách tạo khoảng tường nhà bếp thông minh','cach-tao-khoang-tuong-nha-bep-thong-minh','','','','cach-tao-khoang-tuong-nha-bep-thong-minh-1513651980.jpg','','','0','0','0','0','0','1910','Chỉ với một chút khéo léo, bức tường nhà bếp sẽ trở thành nơi lưu trữ đồ thông minh, giúp chị em nội trợ nấu nướng thuận tiện hơn.','<p><strong>Tối ưu hoá không gian lưu trữ</strong></p>\r\n\r\n<p>Không ít chị em nội trợ có thói quen tích trữ đồ đạc, trong khi diện tích sử dụng của căn bếp thường nhỏ, chật hẹp. Để giải quyết vấn đề này, bạn nên nhờ đến sự hỗ trợ của các phụ kiện trữ đồ thông minh.</p>\r\n\r\n<p>Theo đó, bạn có thể biến bức tường bếp thành nơi đựng các loại vật dụng khác nhau như kệ úp chén, khay để chai lọ, giá để dao... Cách này vừa làm tăng không gian lưu trữ, bếp vẫn thoáng, gọn gàng.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"4-loi-ich-tu-khoang-tuong-nha-bep\" data-natural-width=\"500\" data-pwidth=\"500\" data-was-processed=\"true\" data-width=\"500\" src=\"https://i-giadinh.vnecdn.net/2017/12/14/14-12-201758-2841-1513237689.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Bộ phụ kiện treo tường được sản xuất tại Đức của Kesseböhmer do Häfele phân phối tại Việt Nam.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p><strong>Thao tác nấu nướng thuận tiện</strong></p>\r\n\r\n<p>Việc tận dụng thông minh khoảng tường bếp cũng góp phần đơn giản hoá quy trình nấu nướng. Chỉ cần với tay, bạn có thể lấy dao, thớt hay hũ gia vị để cắt gọt, sơ chế thực phẩm. Ngay cả việc sử dụng các cuộn giấy bạc, màng bọc thực phẩm cũng nhanh hơn khi bạn chỉ cần kéo nhẹ và cắt nhờ các giá treo chuyên dụng. Tương tự, bạn sẽ tiết kiệm được thời gian và công sức trong việc dọn dẹp, cất đồ sau khi dùng.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"4-loi-ich-tu-khoang-tuong-nha-bep-1\" data-natural-width=\"500\" data-pwidth=\"500\" data-was-processed=\"true\" data-width=\"500\" src=\"https://i-giadinh.vnecdn.net/2017/12/14/14-12-20177-951957156-1588-1513237689.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Giá treo màng bọc thực phẩm, khăn...&nbsp;sản xuất tại Đức của Kesseböhmer do Häfele phân phối tại Việt Nam.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p><strong>Không gian bếp gọn gàng, sáng tạo</strong></p>\r\n\r\n<p>Ngoài việc tối ưu hóa không gian tích trữ, bức tường bếp có thể tận dụng để treo tranh ảnh, trưng bày các món đồ trang trí nhỏ xinh, giúp cho không gian căn phòng trở nên sinh động, bắt mắt.</p>\r\n\r\n<p>Bạn có thể treo chậu cây gia vị trên tường để mang lại mảng xanh tươi mát cho căn phòng, đồng thời tạo nguồn thực phẩm homemade, bổ sung cho bữa ăn gia đình.</p>\r\n\r\n<p>Thậm chí, nếu bạn muốn thay đổi cả không gian bếp, hãy thử dùng các tấm ốp tường, giấy dán tường đa dạng về họa tiết, màu sắc để căn bếp thêm sinh động, ấm cúng.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"2\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"4-loi-ich-tu-khoang-tuong-nha-bep-2\" data-natural-width=\"500\" data-pwidth=\"500\" data-was-processed=\"true\" data-width=\"500\" src=\"https://i-giadinh.vnecdn.net/2017/12/14/14-12-201716-3999-1513237689.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Giấy dán tường với hoạ tiết tươi sáng giúp căn bếp nhà bạn thêm phong cách.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p style=\"text-align: right;\"><strong>Thế Đan</strong></p>\r\n','','no','[\"Tin tức\",\"Kiến thực và kinh nghiệm\"]','[\"tin-tuc\",\"kien-thuc-va-kinh-nghiem\"]','1','0','0','8','1513651860','1513651980','1');
INSERT INTO olala3w_article VALUES('909','428','Demo 124xkad','demo-124xkad','','','','no','','','0','0','0','0','0','1912','Chỉ với một chút khéo léo, bức tường nhà bếp sẽ trở thành nơi lưu trữ đồ thông minh, giúp chị em nội trợ nấu nướng thuận tiện hơn.','','','no','[\"Giới thiệu\",\"Về chúng tôi\"]','[\"gioi-thieu\",\"ve-chung-toi\"]','1','0','0','2','1513653540','1513653607','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_article_menu` (
  `article_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `comment` text NOT NULL,
  `icon` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`article_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=450 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_article_menu VALUES('443','94','Nguồn nhân lực','nguon-nhan-luc','','','','0','3','','','1','0','no','1512312745','1512408681','25');
INSERT INTO olala3w_article_menu VALUES('439','96','Nhà ở','noi-that-nha-o','','','','0','1','','','1','0','no','1512182715','1513524402','25');
INSERT INTO olala3w_article_menu VALUES('440','96','Căn hộ dịch vụ','noi-that-can-ho-dich-vu','','','','0','2','','','1','0','no','1512182725','1513524421','25');
INSERT INTO olala3w_article_menu VALUES('441','96','Công trình công cộng','noi-that-cong-trinh-cong-cong','','','','0','3','','','1','0','no','1512182953','1513524442','25');
INSERT INTO olala3w_article_menu VALUES('442','94','Sản phẩm dịch vụ','san-pham-dich-vu','','','','0','2','','','1','0','no','1512312725','1512408680','25');
INSERT INTO olala3w_article_menu VALUES('438','90','Không gian đẹp','khong-gian-dep','','','','0','3','','','1','0','no','1512182612','1512182612','1');
INSERT INTO olala3w_article_menu VALUES('437','90','Kiến thực và kinh nghiệm','kien-thuc-va-kinh-nghiem','','','','0','2','','','1','0','no','1512182604','1512182604','1');
INSERT INTO olala3w_article_menu VALUES('447','98','Dự án đã hoàn thành','du-an-da-hoan-thanh','','','','0','1','','','1','0','no','1513524483','1513611427','25');
INSERT INTO olala3w_article_menu VALUES('436','90','Thông tin thị trường','thong-tin-thi-truong','','','','0','1','','','1','0','no','1512182589','1512182589','1');
INSERT INTO olala3w_article_menu VALUES('434','97','Khu dân cư','khu-dan-cu','','','','0','3','','Concept','1','0','no','1512182539','1513524322','25');
INSERT INTO olala3w_article_menu VALUES('433','97','Cảnh quan','canh-quan','','','','0','2','','Nội thất','1','0','no','1512182527','1513524310','25');
INSERT INTO olala3w_article_menu VALUES('428','94','Về chúng tôi','ve-chung-toi','','','','0','1','','','1','0','no','1512182375','1512313435','25');
INSERT INTO olala3w_article_menu VALUES('449','98','Công trình cải tạo','cong-trinh-cai-tao','','','','0','3','','','1','0','no','1513524523','1513611443','25');
INSERT INTO olala3w_article_menu VALUES('429','89','Nhà ở','kien-truc-nha-o','','','','0','1','','','1','0','no','1512182413','1513524595','25');
INSERT INTO olala3w_article_menu VALUES('430','89','Căn hộ dịch vụ','kien-truc-can-ho-dich-vu','','','','0','2','','','1','0','no','1512182434','1513524604','25');
INSERT INTO olala3w_article_menu VALUES('431','89','Công trình công cộng','kien-truc-cong-trinh-cong-cong','','','','0','3','','','1','0','no','1512182447','1513524612','25');
INSERT INTO olala3w_article_menu VALUES('432','97','Toà nhà','toa-nha','','','','0','1','','Kiến trúc','1','0','no','1512182514','1514791780','1');
INSERT INTO olala3w_article_menu VALUES('444','94','Liên hệ','lien-he','','','','0','4','','','1','0','no','1512312831','1512408681','25');
INSERT INTO olala3w_article_menu VALUES('448','98','Dự án đang thi công','du-an-dang-thi-cong','','','','0','2','','','1','0','no','1513524499','1513611437','25');

-- --------------------------------------------------------

CREATE TABLE `olala3w_car` (
  `car_id` int(11) NOT NULL AUTO_INCREMENT,
  `car_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `upload_id` bigint(20) NOT NULL,
  `model` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `seat` varchar(255) NOT NULL,
  `seat_sort` int(11) NOT NULL DEFAULT '0',
  `color` varchar(255) NOT NULL,
  `price` bigint(15) NOT NULL,
  `sale` int(3) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `content` longtext NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`car_id`)
) ENGINE=MyISAM AUTO_INCREMENT=312 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_car_menu` (
  `car_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `comment` text NOT NULL,
  `icon` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`car_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=188 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(30) NOT NULL,
  `plus` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `comment` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `menu_main` int(1) NOT NULL DEFAULT '0',
  `sort_hide` int(11) NOT NULL DEFAULT '1',
  `menu_sm` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `icon` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=99 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_category VALUES('89','1','Kiến trúc','kien-truc','','','','','','1','1','2','1','2','1','no','','0','1513527223','25');
INSERT INTO olala3w_category VALUES('90','1','Tin tức','tin-tuc','','','','','','1','0','6','1','5','1','no','','0','1513527261','25');
INSERT INTO olala3w_category VALUES('91','2','Slider','slider','','','','','','1','0','1','0','0','0','no','','0','0','0');
INSERT INTO olala3w_category VALUES('98','1','Xây dựng','xay-dung','','','','','','1','1','4','1','1','0','no','','0','1513527239','25');
INSERT INTO olala3w_category VALUES('95','15','Thành phố','city','','','','','','1','0','1','0','0','0','no','','0','1494961394','1');
INSERT INTO olala3w_category VALUES('94','1','Giới thiệu','gioi-thieu','','','','','','1','0','5','1','1','1','no','','0','1513527252','25');
INSERT INTO olala3w_category VALUES('97','1','Ý tưởng','y-tuong','','','','','','1','1','1','1','1','0','no','','0','1513527215','25');
INSERT INTO olala3w_category VALUES('96','1','Nội thất','noi-that','','','','','','1','1','3','1','6','1','no','','0','1513527231','25');

-- --------------------------------------------------------

CREATE TABLE `olala3w_category_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(30) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_category_type VALUES('1','Bài viết','article_manager','1','1');
INSERT INTO olala3w_category_type VALUES('2','Hình ảnh','gallery_manager','2','1');
INSERT INTO olala3w_category_type VALUES('7','Đăng ký email','register_email','9','0');
INSERT INTO olala3w_category_type VALUES('6','Sản phẩm','product_manager','3','0');
INSERT INTO olala3w_category_type VALUES('8','Booking online','order_list','7','0');
INSERT INTO olala3w_category_type VALUES('9','Tour du lịch','tour_manager','5','0');
INSERT INTO olala3w_category_type VALUES('10','Đồ lưu niệm','gift_manager','0','0');
INSERT INTO olala3w_category_type VALUES('11','Thuê xe','car_manager','6','0');
INSERT INTO olala3w_category_type VALUES('12','Vị trí địa lý','location_manager','0','0');
INSERT INTO olala3w_category_type VALUES('13','Dữ liệu đường phố','street_manager','0','0');
INSERT INTO olala3w_category_type VALUES('14','Dữ liệu phương hướng','direction_manager','0','0');
INSERT INTO olala3w_category_type VALUES('15','Dữ liệu khác','others_manager','4','0');
INSERT INTO olala3w_category_type VALUES('16','Chiều rộng đường','road_manager','0','0');
INSERT INTO olala3w_category_type VALUES('17','Dự án','project_manager','0','0');
INSERT INTO olala3w_category_type VALUES('18','BĐS kinh doanh','bds_business_manager','0','0');
INSERT INTO olala3w_category_type VALUES('19','Dữ liệu tên dự án','prjname_manager','0','0');
INSERT INTO olala3w_category_type VALUES('20','Thư liên hệ','contact_list','8','1');
INSERT INTO olala3w_category_type VALUES('21','Văn bản / Tài liệu','document_manager','3','0');
INSERT INTO olala3w_category_type VALUES('22','Khách hàng','customer_list','10','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_constant` (
  `constant_id` int(11) NOT NULL AUTO_INCREMENT,
  `constant` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` int(2) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`constant_id`)
) ENGINE=MyISAM AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_constant VALUES('1','date','d/m/Y','Kiểu hiển thị ngày tháng năm','3','1');
INSERT INTO olala3w_constant VALUES('2','time','H:i','Kiểu hiển thị giờ phút','3','2');
INSERT INTO olala3w_constant VALUES('3','timezone','Asia/Bangkok','Múi giờ','3','4');
INSERT INTO olala3w_constant VALUES('4','title','S-Home | Home Solution | Giải pháp nhà ở | Thiết kế kiến trúc & nội thất tại Đà Nẵng','Title (trang chủ)','0','1');
INSERT INTO olala3w_constant VALUES('5','description','S-Home chuyên lĩnh vực xây dựng: Thiết kế nội thất, Thiết kế concept, Thi công nội thất & lĩnh vực bất động sản: Địa ốc, Tư vấn giải pháp nhà ở, Kinh doanh nhà ở.','Description (trang chủ)','0','2');
INSERT INTO olala3w_constant VALUES('6','keywords','S-homes.vn,Home solution,Thiết kế nội thất,Thiết kế concept,Thi công nội thất,kinh doanh bất động sản,Địa ốc,Tư vấn giải pháp nhà ở,Kinh doanh nhà ở,bất động sản,đà nẵng,danang,thiết kế nhà ở,tư vấn nhà đất,thiết kế xây dựng,thiết kế kiến trúc,nhà đất đà nẵng,căn hộ cho thuê','Keywords (trang chủ)','0','3');
INSERT INTO olala3w_constant VALUES('74','script_body','<div id=\"fb-root\"></div>\r\n<script>(function(d, s, id) {\r\n  var js, fjs = d.getElementsByTagName(s)[0];\r\n  if (d.getElementById(id)) return;\r\n  js = d.createElement(s); js.id = id;\r\n  js.src = \"//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.5\";\r\n  fjs.parentNode.insertBefore(js, fjs);\r\n}(document, \'script\', \'facebook-jssdk\'));</script>\r\n','Script sau body','4','6');
INSERT INTO olala3w_constant VALUES('76','link_linkedin','','LinkedIn','5','5');
INSERT INTO olala3w_constant VALUES('7','email_contact','info@s-homes.vn','Email','0','8');
INSERT INTO olala3w_constant VALUES('8','tell_contact','0974 779 085','Điện thoại','0','9');
INSERT INTO olala3w_constant VALUES('9','fulldate','D, d/m/Y','Kiểu hiển ngày đầy đủ','3','3');
INSERT INTO olala3w_constant VALUES('10','SMTP_username','olala.3w@gmail.com','Tài khoản email','1','0');
INSERT INTO olala3w_constant VALUES('11','SMTP_password','cdreodvwrbpbugso','Mật khẩu email','1','0');
INSERT INTO olala3w_constant VALUES('12','error_page','<p>Vì lý do kỹ&nbsp;thuật website tạm ngưng&nbsp;hoạt động. Thành thật xin lỗi các bạn&nbsp;vì sự bất tiện này!</p>\r\n','Thông báo ngừng hoạt động','0','19');
INSERT INTO olala3w_constant VALUES('13','file_logo','/uploads/images/site/logo.png','Logo front-end','0','4');
INSERT INTO olala3w_constant VALUES('14','SMTP_secure','ssl','Sử dụng xác thực','1','0');
INSERT INTO olala3w_constant VALUES('15','SMTP_host','smtp.gmail.com','Máy chủ (SMTP) Thư gửi đi','1','0');
INSERT INTO olala3w_constant VALUES('16','SMTP_port','465','Cổng gửi mail','1','0');
INSERT INTO olala3w_constant VALUES('17','backup_auto','','Tự động sao lưu','2','0');
INSERT INTO olala3w_constant VALUES('18','backup_filetype','sql.gz','Định dạng lưu file CSDL','2','0');
INSERT INTO olala3w_constant VALUES('19','backup_filecount','5','Số file CSDL lưu lại','2','0');
INSERT INTO olala3w_constant VALUES('20','backup_email','olala.3w@gmail.com','Email nhận thông báo và file','2','0');
INSERT INTO olala3w_constant VALUES('21','SMTP_mailname','S-Home | Home Solution','Tên tài khoản email','1','0');
INSERT INTO olala3w_constant VALUES('22','link_facebook','https://www.facebook.com','Facebook','5','1');
INSERT INTO olala3w_constant VALUES('23','link_googleplus','https://plus.google.com','Google+','5','2');
INSERT INTO olala3w_constant VALUES('24','link_twitter','https://twitter.com','Twitter','5','3');
INSERT INTO olala3w_constant VALUES('25','address_contact','Đà Nẵng, Việt Nam','Địa chỉ','0','11');
INSERT INTO olala3w_constant VALUES('73','script_bottom','<script type=\"text/javascript\" async defer  src=\"//assets.pinterest.com/js/pinit.js\"></script>\r\n','Script cuối trang','4','7');
INSERT INTO olala3w_constant VALUES('26','content_registertry','','Email đăng ký học thử','13','17');
INSERT INTO olala3w_constant VALUES('27','author_google','','ID profile Google+','4','1');
INSERT INTO olala3w_constant VALUES('28','google_analytics','<!-- GENERAL GOOGLE SEARCH META -->\r\n<script data-schema=\"Organization\" type=\"application/ld+json\">\r\n{\r\n	\"name\":\"S-Home | Home Solution | Giải pháp nhà ở | Thiết kế kiến trúc & nội thất tại Đà Nẵng\",\r\n	\"url\":\"http://s-homes.vn\",\r\n	\"logo\":\"http://vr2.s-homes.vn/uploads/images/site/Tu-van-Thiet-ke-Thi-cong-(S-Home).jpg\",\r\n	\"alternateName\" : \"S-Home chuyên lĩnh vực xây dựng: Thiết kế nội thất, Thiết kế concept, Thi công nội thất & lĩnh vực bất động sản: Địa ốc, Tư vấn giải pháp nhà ở, Kinh doanh nhà ở.\",\r\n	\"sameAs\":[\r\n		\"https://www.facebook.com/S.HomeSolution\",\r\n		\"https://www.youtube.com/channel/UC05lwRAsXwwO7cQbbq4y4oA/videos\"\r\n	],\r\n	\"@type\":\"Organization\",\r\n	\"@context\":\"http://schema.org\",\r\n	\"contactPoint\": [{\r\n		\"@type\": \"ContactPoint\",\r\n		\"telephone\": \"+84905566626\",\r\n		\"name\": \"Đinh Ngọc Sinh\",\r\n		\"contactType\": \"Sales Manager\",\r\n		\"sameAs\":[\r\n			\"https://www.facebook.com/sinhbds\"\r\n		]\r\n	}]\r\n}\r\n</script>\r\n<!-- End GENERAL GOOGLE SEARCH META -->\r\n','Google analytics','4','4');
INSERT INTO olala3w_constant VALUES('29','chat_online','','Script Chat Online','4','5');
INSERT INTO olala3w_constant VALUES('30','english_test','','Kiểm tra tiếng Anh của bạn','13','18');
INSERT INTO olala3w_constant VALUES('31','google_calendar','','Google Calendar (Account)','4','3');
INSERT INTO olala3w_constant VALUES('32','help_address','killlllme@gmail.com,0974.779.085,huy.to.bsn,mr.killlllme','Tư vấn - Địa chỉ','13','8');
INSERT INTO olala3w_constant VALUES('33','help_icon','fa-envelope-o,fa-phone,fa-skype,fa-facebook','Tư vấn - Icon','13','9');
INSERT INTO olala3w_constant VALUES('34','link_youtube','','Youtube','5','4');
INSERT INTO olala3w_constant VALUES('35','search_destination','Hà Nội,Đà Nẵng,Hồ Chí Minh,Phú Quốc,Nha Trang,Hạ Long,Đà Lạt,Phong Nha Kẻ Bàng,Côn đảo Vũng Tàu,Thái Lan,Singapore,Malaysia,Campuchia,Trung Quốc,Nhật Bản,Hàn Quốc,Hà Lan,Myanmar,Úc,Hong Kong,Philippines,Indonesia,Đài Loan,Châu Á,Châu Âu,Châu Mỹ,Châu Phi,Châu Úc','Điểm đến (Tìm kiếm tour)','13','8');
INSERT INTO olala3w_constant VALUES('36','search_day','1 Ngày,1 Ngày 1 Đêm,2 Ngày,2 Ngày 1 Đêm,3 Ngày,3 Ngày 2 Đêm,4 Ngày,4 Ngày 3 Đêm,5 Ngày,5 Ngày 4 Đêm,6 Ngày,6 Ngày 5 Đêm,7 Ngày,7 Ngày 6 Đêm,8 Ngày,8 Ngày 7 Đêm,9 Ngày,9 Ngày 8 Đêm,10 Ngày,10 Ngày 9 Đêm,11 Ngày,11 Ngày 10 Đêm,12 Ngày,12 Ngày 11 Đêm,1 Tuần,2 Tuần,3 Tuần,1 Tháng,2 Tháng,3 Tháng','Thời gian (Tìm kiếm tour)','13','9');
INSERT INTO olala3w_constant VALUES('75','fb_app_id','','Facebook App ID','4','2');
INSERT INTO olala3w_constant VALUES('77','upload_img_max_w','1900','Kích thước ảnh tối đa','6','1');
INSERT INTO olala3w_constant VALUES('78','upload_max_size','52428800','Dung lượng tối đa','6','2');
INSERT INTO olala3w_constant VALUES('79','upload_checking_mode','mild','Kiểu kiểm tra file tải lên','6','3');
INSERT INTO olala3w_constant VALUES('80','upload_type','1,4,5,6,7,8,9,10,11','Loại files cho phép','6','4');
INSERT INTO olala3w_constant VALUES('81','upload_ext','','Phần mở rộng bị cấm','6','5');
INSERT INTO olala3w_constant VALUES('82','upload_mime','','Loại mime bị cấm','6','6');
INSERT INTO olala3w_constant VALUES('83','upload_img_max_h','594','Kích thước ảnh tối đa','6','1');
INSERT INTO olala3w_constant VALUES('84','upload_auto_resize','1','Tự động resize ảnh','6','1');
INSERT INTO olala3w_constant VALUES('85','article_author','','Property = article:author','4','2');
INSERT INTO olala3w_constant VALUES('86','meta_author','S-Homes.vn','Meta author','0','4');
INSERT INTO olala3w_constant VALUES('88','meta_site_name','S-Home | Home Solution','Meta site name','0','5');
INSERT INTO olala3w_constant VALUES('89','meta_copyright','Copyright © 2017 S-Homes.vn','Meta copyright','0','6');
INSERT INTO olala3w_constant VALUES('90','image_thumbnailUrl','/uploads/images/site/Tu-van-Thiet-ke-Thi-cong-(S-Home).jpg','Image : thumbnailUrl','0','7');
INSERT INTO olala3w_constant VALUES('91','skype_contact','skype_shome','Skype','0','10');
INSERT INTO olala3w_constant VALUES('92','link_instagram','','Instagram','5','6');

-- --------------------------------------------------------

CREATE TABLE `olala3w_contact` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `content` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `ip` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL DEFAULT 'fa-send-o',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_core_privilege` (
  `privilege_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(30) NOT NULL,
  `privilege_slug` varchar(50) NOT NULL,
  PRIMARY KEY (`privilege_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4821 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_core_privilege VALUES('2250','1','direction','direction_del');
INSERT INTO olala3w_core_privilege VALUES('2249','1','direction','direction_edit');
INSERT INTO olala3w_core_privilege VALUES('2248','1','direction','direction_add');
INSERT INTO olala3w_core_privilege VALUES('2255','1','pages','plugin_page_edit');
INSERT INTO olala3w_core_privilege VALUES('1071','1','backup','backup_config');
INSERT INTO olala3w_core_privilege VALUES('1545','1','config','config_search');
INSERT INTO olala3w_core_privilege VALUES('1531','1','tool','tool_ipdie');
INSERT INTO olala3w_core_privilege VALUES('1530','1','tool','tool_keywords');
INSERT INTO olala3w_core_privilege VALUES('2656','1','bds_business','bds_business_del;50');
INSERT INTO olala3w_core_privilege VALUES('2103','2','product','product_menu_add;37');
INSERT INTO olala3w_core_privilege VALUES('2102','2','product','category_edit;37');
INSERT INTO olala3w_core_privilege VALUES('2101','2','article','article_del;13');
INSERT INTO olala3w_core_privilege VALUES('2100','2','article','article_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2099','2','article','article_add;13');
INSERT INTO olala3w_core_privilege VALUES('2098','2','article','article_list;13');
INSERT INTO olala3w_core_privilege VALUES('2097','2','article','article_menu_del;13');
INSERT INTO olala3w_core_privilege VALUES('2096','2','article','article_menu_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2095','2','article','article_menu_add;13');
INSERT INTO olala3w_core_privilege VALUES('2094','2','article','category_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2093','2','article','article_del;9');
INSERT INTO olala3w_core_privilege VALUES('2092','2','article','article_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2091','2','article','article_add;9');
INSERT INTO olala3w_core_privilege VALUES('2090','2','article','article_list;9');
INSERT INTO olala3w_core_privilege VALUES('2089','2','article','article_menu_del;9');
INSERT INTO olala3w_core_privilege VALUES('2088','2','article','article_menu_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2087','2','article','article_menu_add;9');
INSERT INTO olala3w_core_privilege VALUES('2086','2','article','category_edit;9');
INSERT INTO olala3w_core_privilege VALUES('273','2','gallery','gallery_menu_add;6');
INSERT INTO olala3w_core_privilege VALUES('274','2','gallery','gallery_menu_edit;6');
INSERT INTO olala3w_core_privilege VALUES('275','2','gallery','gallery_menu_del;6');
INSERT INTO olala3w_core_privilege VALUES('276','2','gallery','gallery_add;6');
INSERT INTO olala3w_core_privilege VALUES('277','2','gallery','gallery_edit;6');
INSERT INTO olala3w_core_privilege VALUES('278','2','gallery','gallery_del;6');
INSERT INTO olala3w_core_privilege VALUES('279','2','pages','pages_add');
INSERT INTO olala3w_core_privilege VALUES('280','2','pages','pages_edit');
INSERT INTO olala3w_core_privilege VALUES('281','2','pages','pages_del');
INSERT INTO olala3w_core_privilege VALUES('287','2','backup','backup_data');
INSERT INTO olala3w_core_privilege VALUES('288','2','backup','backup_config');
INSERT INTO olala3w_core_privilege VALUES('289','2','config','config_general');
INSERT INTO olala3w_core_privilege VALUES('290','2','config','config_search');
INSERT INTO olala3w_core_privilege VALUES('291','2','config','config_ipdie');
INSERT INTO olala3w_core_privilege VALUES('292','2','config','config_upload');
INSERT INTO olala3w_core_privilege VALUES('293','2','tool','tool_delete');
INSERT INTO olala3w_core_privilege VALUES('294','2','tool','tool_site');
INSERT INTO olala3w_core_privilege VALUES('295','2','tool','tool_keywords');
INSERT INTO olala3w_core_privilege VALUES('296','2','tool','tool_update');
INSERT INTO olala3w_core_privilege VALUES('330','2','core','core_mail');
INSERT INTO olala3w_core_privilege VALUES('2655','1','bds_business','bds_business_edit;50');
INSERT INTO olala3w_core_privilege VALUES('2654','1','bds_business','bds_business_add;50');
INSERT INTO olala3w_core_privilege VALUES('1070','1','backup','backup_data');
INSERT INTO olala3w_core_privilege VALUES('1544','1','config','config_socialnetwork');
INSERT INTO olala3w_core_privilege VALUES('1529','1','tool','tool_site');
INSERT INTO olala3w_core_privilege VALUES('1528','1','tool','tool_delete');
INSERT INTO olala3w_core_privilege VALUES('3333','1','core','core_dashboard');
INSERT INTO olala3w_core_privilege VALUES('2653','1','bds_business','bds_business_list;50');
INSERT INTO olala3w_core_privilege VALUES('3331','1','core','core_role');
INSERT INTO olala3w_core_privilege VALUES('1543','1','config','config_plugins');
INSERT INTO olala3w_core_privilege VALUES('3332','1','core','core_user');
INSERT INTO olala3w_core_privilege VALUES('2254','1','pages','plugin_page_add');
INSERT INTO olala3w_core_privilege VALUES('2252','1','street','street_edit');
INSERT INTO olala3w_core_privilege VALUES('2251','1','street','street_add');
INSERT INTO olala3w_core_privilege VALUES('2208','1','location','location_del;40');
INSERT INTO olala3w_core_privilege VALUES('2207','1','location','location_edit;40');
INSERT INTO olala3w_core_privilege VALUES('2206','1','location','location_add;40');
INSERT INTO olala3w_core_privilege VALUES('2205','1','location','location_list;40');
INSERT INTO olala3w_core_privilege VALUES('2204','1','location','location_menu_del;40');
INSERT INTO olala3w_core_privilege VALUES('2203','1','location','location_menu_edit;40');
INSERT INTO olala3w_core_privilege VALUES('2202','1','location','location_menu_add;40');
INSERT INTO olala3w_core_privilege VALUES('2201','1','location','category_edit;40');
INSERT INTO olala3w_core_privilege VALUES('1532','1','tool','tool_update');
INSERT INTO olala3w_core_privilege VALUES('1542','1','config','config_datetime');
INSERT INTO olala3w_core_privilege VALUES('1541','1','config','config_smtp');
INSERT INTO olala3w_core_privilege VALUES('1540','1','config','config_general');
INSERT INTO olala3w_core_privilege VALUES('1546','1','config','config_upload');
INSERT INTO olala3w_core_privilege VALUES('2200','1','location','location_del;39');
INSERT INTO olala3w_core_privilege VALUES('2198','1','location','location_add;39');
INSERT INTO olala3w_core_privilege VALUES('2199','1','location','location_edit;39');
INSERT INTO olala3w_core_privilege VALUES('2197','1','location','location_list;39');
INSERT INTO olala3w_core_privilege VALUES('2195','1','location','location_menu_edit;39');
INSERT INTO olala3w_core_privilege VALUES('2196','1','location','location_menu_del;39');
INSERT INTO olala3w_core_privilege VALUES('2194','1','location','location_menu_add;39');
INSERT INTO olala3w_core_privilege VALUES('4800','1','article','category_edit;96');
INSERT INTO olala3w_core_privilege VALUES('3983','1','tour','tour_del;70');
INSERT INTO olala3w_core_privilege VALUES('3982','1','tour','tour_edit;70');
INSERT INTO olala3w_core_privilege VALUES('3981','1','tour','tour_add;70');
INSERT INTO olala3w_core_privilege VALUES('3980','1','tour','tour_list;70');
INSERT INTO olala3w_core_privilege VALUES('3979','1','tour','tour_menu_del;70');
INSERT INTO olala3w_core_privilege VALUES('3978','1','tour','tour_menu_edit;70');
INSERT INTO olala3w_core_privilege VALUES('3977','1','tour','tour_menu_add;70');
INSERT INTO olala3w_core_privilege VALUES('3976','1','tour','category_edit;70');
INSERT INTO olala3w_core_privilege VALUES('1712','1','gift','gift_add;22');
INSERT INTO olala3w_core_privilege VALUES('1711','1','gift','gift_list;22');
INSERT INTO olala3w_core_privilege VALUES('1710','1','gift','gift_menu_del;22');
INSERT INTO olala3w_core_privilege VALUES('1709','1','gift','gift_menu_edit;22');
INSERT INTO olala3w_core_privilege VALUES('1708','1','gift','gift_menu_add;22');
INSERT INTO olala3w_core_privilege VALUES('1707','1','gift','category_edit;22');
INSERT INTO olala3w_core_privilege VALUES('3838','1','car','car_list;67');
INSERT INTO olala3w_core_privilege VALUES('3837','1','car','car_menu_del;67');
INSERT INTO olala3w_core_privilege VALUES('3836','1','car','car_menu_edit;67');
INSERT INTO olala3w_core_privilege VALUES('3835','1','car','car_menu_add;67');
INSERT INTO olala3w_core_privilege VALUES('3834','1','car','category_edit;67');
INSERT INTO olala3w_core_privilege VALUES('1713','1','gift','gift_edit;22');
INSERT INTO olala3w_core_privilege VALUES('1714','1','gift','gift_del;22');
INSERT INTO olala3w_core_privilege VALUES('2193','1','location','category_edit;39');
INSERT INTO olala3w_core_privilege VALUES('3328','1','info','sys_info_expansion');
INSERT INTO olala3w_core_privilege VALUES('3327','1','info','sys_info_site');
INSERT INTO olala3w_core_privilege VALUES('4799','1','article','article_del;89');
INSERT INTO olala3w_core_privilege VALUES('2085','2','category','article_manager');
INSERT INTO olala3w_core_privilege VALUES('4647','1','product','product_del;9');
INSERT INTO olala3w_core_privilege VALUES('4646','1','product','product_edit;9');
INSERT INTO olala3w_core_privilege VALUES('4645','1','product','product_add;9');
INSERT INTO olala3w_core_privilege VALUES('2253','1','street','street_del');
INSERT INTO olala3w_core_privilege VALUES('2256','1','pages','plugin_page_del');
INSERT INTO olala3w_core_privilege VALUES('2290','1','road','road_add');
INSERT INTO olala3w_core_privilege VALUES('2291','1','road','road_edit');
INSERT INTO olala3w_core_privilege VALUES('2292','1','road','road_del');
INSERT INTO olala3w_core_privilege VALUES('2780','1','project','project_list;13');
INSERT INTO olala3w_core_privilege VALUES('2779','1','project','project_menu_del;13');
INSERT INTO olala3w_core_privilege VALUES('2778','1','project','project_menu_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2777','1','project','project_menu_add;13');
INSERT INTO olala3w_core_privilege VALUES('2776','1','project','category_edit;13');
INSERT INTO olala3w_core_privilege VALUES('3841','1','car','car_del;67');
INSERT INTO olala3w_core_privilege VALUES('3840','1','car','car_edit;67');
INSERT INTO olala3w_core_privilege VALUES('3839','1','car','car_add;67');
INSERT INTO olala3w_core_privilege VALUES('4027','1','document','document_add;73');
INSERT INTO olala3w_core_privilege VALUES('2652','1','bds_business','bds_business_menu_del;50');
INSERT INTO olala3w_core_privilege VALUES('2651','1','bds_business','bds_business_menu_edit;50');
INSERT INTO olala3w_core_privilege VALUES('2650','1','bds_business','bds_business_menu_add;50');
INSERT INTO olala3w_core_privilege VALUES('2649','1','bds_business','category_edit;50');
INSERT INTO olala3w_core_privilege VALUES('2781','1','project','project_add;13');
INSERT INTO olala3w_core_privilege VALUES('2782','1','project','project_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2783','1','project','project_del;13');
INSERT INTO olala3w_core_privilege VALUES('2784','1','project','category_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2785','1','project','project_menu_add;53');
INSERT INTO olala3w_core_privilege VALUES('2786','1','project','project_menu_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2787','1','project','project_menu_del;53');
INSERT INTO olala3w_core_privilege VALUES('2788','1','project','project_list;53');
INSERT INTO olala3w_core_privilege VALUES('2789','1','project','project_add;53');
INSERT INTO olala3w_core_privilege VALUES('2790','1','project','project_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2791','1','project','project_del;53');
INSERT INTO olala3w_core_privilege VALUES('2792','9','category','product_manager');
INSERT INTO olala3w_core_privilege VALUES('2793','9','product','product_list;37');
INSERT INTO olala3w_core_privilege VALUES('2794','9','product','product_add;37');
INSERT INTO olala3w_core_privilege VALUES('2795','9','product','product_edit;37');
INSERT INTO olala3w_core_privilege VALUES('2796','9','product','product_del;37');
INSERT INTO olala3w_core_privilege VALUES('2797','11','category','article_manager');
INSERT INTO olala3w_core_privilege VALUES('2798','11','category','gallery_manager');
INSERT INTO olala3w_core_privilege VALUES('2799','11','category','project_manager');
INSERT INTO olala3w_core_privilege VALUES('2800','11','category','product_manager');
INSERT INTO olala3w_core_privilege VALUES('2801','11','category','location_manager');
INSERT INTO olala3w_core_privilege VALUES('2802','11','category','street_manager');
INSERT INTO olala3w_core_privilege VALUES('2803','11','category','road_manager');
INSERT INTO olala3w_core_privilege VALUES('2804','11','category','direction_manager');
INSERT INTO olala3w_core_privilege VALUES('2805','11','category','others_manager');
INSERT INTO olala3w_core_privilege VALUES('2806','11','category','plugin_page');
INSERT INTO olala3w_core_privilege VALUES('3031','11','article','article_menu_add;9');
INSERT INTO olala3w_core_privilege VALUES('3030','11','article','category_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2809','11','config','config_socialnetwork');
INSERT INTO olala3w_core_privilege VALUES('2815','11','pages','plugin_page_del');
INSERT INTO olala3w_core_privilege VALUES('2814','11','pages','plugin_page_edit');
INSERT INTO olala3w_core_privilege VALUES('2813','11','pages','plugin_page_add');
INSERT INTO olala3w_core_privilege VALUES('2816','1','prjname','prjname_add');
INSERT INTO olala3w_core_privilege VALUES('2817','1','prjname','prjname_edit');
INSERT INTO olala3w_core_privilege VALUES('2818','1','prjname','prjname_del');
INSERT INTO olala3w_core_privilege VALUES('2830','12','category','article_manager');
INSERT INTO olala3w_core_privilege VALUES('2831','12','category','gallery_manager');
INSERT INTO olala3w_core_privilege VALUES('2832','12','category','project_manager');
INSERT INTO olala3w_core_privilege VALUES('2833','12','category','product_manager');
INSERT INTO olala3w_core_privilege VALUES('2834','12','category','location_manager');
INSERT INTO olala3w_core_privilege VALUES('2835','12','category','road_manager');
INSERT INTO olala3w_core_privilege VALUES('2836','12','category','street_manager');
INSERT INTO olala3w_core_privilege VALUES('2837','12','category','direction_manager');
INSERT INTO olala3w_core_privilege VALUES('2838','12','category','prjname_manager');
INSERT INTO olala3w_core_privilege VALUES('2839','12','category','others_manager');
INSERT INTO olala3w_core_privilege VALUES('2840','12','category','plugin_page');
INSERT INTO olala3w_core_privilege VALUES('2841','12','pages','plugin_page_add');
INSERT INTO olala3w_core_privilege VALUES('2842','12','pages','plugin_page_edit');
INSERT INTO olala3w_core_privilege VALUES('2843','12','pages','plugin_page_del');
INSERT INTO olala3w_core_privilege VALUES('4798','1','article','article_edit;89');
INSERT INTO olala3w_core_privilege VALUES('2908','12','article','category_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2909','12','article','article_menu_add;9');
INSERT INTO olala3w_core_privilege VALUES('2910','12','article','article_menu_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2911','12','article','article_menu_del;9');
INSERT INTO olala3w_core_privilege VALUES('2912','12','article','article_list;9');
INSERT INTO olala3w_core_privilege VALUES('2913','12','article','article_add;9');
INSERT INTO olala3w_core_privilege VALUES('2914','12','article','article_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2915','12','article','article_del;9');
INSERT INTO olala3w_core_privilege VALUES('2916','12','article','category_edit;51');
INSERT INTO olala3w_core_privilege VALUES('2917','12','article','article_menu_add;51');
INSERT INTO olala3w_core_privilege VALUES('2918','12','article','article_menu_edit;51');
INSERT INTO olala3w_core_privilege VALUES('2919','12','article','article_menu_del;51');
INSERT INTO olala3w_core_privilege VALUES('2920','12','article','article_list;51');
INSERT INTO olala3w_core_privilege VALUES('2921','12','article','article_add;51');
INSERT INTO olala3w_core_privilege VALUES('2922','12','article','article_edit;51');
INSERT INTO olala3w_core_privilege VALUES('2923','12','article','article_del;51');
INSERT INTO olala3w_core_privilege VALUES('2924','12','article','category_edit;7');
INSERT INTO olala3w_core_privilege VALUES('2925','12','article','article_menu_add;7');
INSERT INTO olala3w_core_privilege VALUES('2926','12','article','article_menu_edit;7');
INSERT INTO olala3w_core_privilege VALUES('2927','12','article','article_menu_del;7');
INSERT INTO olala3w_core_privilege VALUES('2928','12','article','article_list;7');
INSERT INTO olala3w_core_privilege VALUES('2929','12','article','article_add;7');
INSERT INTO olala3w_core_privilege VALUES('2930','12','article','article_edit;7');
INSERT INTO olala3w_core_privilege VALUES('2931','12','article','article_del;7');
INSERT INTO olala3w_core_privilege VALUES('2932','12','project','category_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2933','12','project','project_menu_add;13');
INSERT INTO olala3w_core_privilege VALUES('2934','12','project','project_menu_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2935','12','project','project_menu_del;13');
INSERT INTO olala3w_core_privilege VALUES('2936','12','project','project_list;13');
INSERT INTO olala3w_core_privilege VALUES('2937','12','project','project_add;13');
INSERT INTO olala3w_core_privilege VALUES('2938','12','project','project_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2939','12','project','project_del;13');
INSERT INTO olala3w_core_privilege VALUES('2940','12','project','category_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2941','12','project','project_menu_add;53');
INSERT INTO olala3w_core_privilege VALUES('2942','12','project','project_menu_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2943','12','project','project_menu_del;53');
INSERT INTO olala3w_core_privilege VALUES('2944','12','project','project_list;53');
INSERT INTO olala3w_core_privilege VALUES('2945','12','project','project_add;53');
INSERT INTO olala3w_core_privilege VALUES('2946','12','project','project_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2947','12','project','project_del;53');
INSERT INTO olala3w_core_privilege VALUES('2948','12','gallery','category_edit;4');
INSERT INTO olala3w_core_privilege VALUES('2949','12','gallery','gallery_menu_add;4');
INSERT INTO olala3w_core_privilege VALUES('2950','12','gallery','gallery_menu_edit;4');
INSERT INTO olala3w_core_privilege VALUES('2951','12','gallery','gallery_menu_del;4');
INSERT INTO olala3w_core_privilege VALUES('2952','12','gallery','gallery_list;4');
INSERT INTO olala3w_core_privilege VALUES('2953','12','gallery','gallery_add;4');
INSERT INTO olala3w_core_privilege VALUES('2954','12','gallery','gallery_edit;4');
INSERT INTO olala3w_core_privilege VALUES('2955','12','gallery','gallery_del;4');
INSERT INTO olala3w_core_privilege VALUES('2956','12','gallery','category_edit;52');
INSERT INTO olala3w_core_privilege VALUES('2957','12','gallery','gallery_menu_add;52');
INSERT INTO olala3w_core_privilege VALUES('2958','12','gallery','gallery_menu_edit;52');
INSERT INTO olala3w_core_privilege VALUES('2959','12','gallery','gallery_menu_del;52');
INSERT INTO olala3w_core_privilege VALUES('2960','12','gallery','gallery_list;52');
INSERT INTO olala3w_core_privilege VALUES('2961','12','gallery','gallery_add;52');
INSERT INTO olala3w_core_privilege VALUES('2962','12','gallery','gallery_edit;52');
INSERT INTO olala3w_core_privilege VALUES('2963','12','gallery','gallery_del;52');
INSERT INTO olala3w_core_privilege VALUES('2964','12','product','category_edit;37');
INSERT INTO olala3w_core_privilege VALUES('2965','12','product','product_menu_add;37');
INSERT INTO olala3w_core_privilege VALUES('2966','12','product','product_menu_edit;37');
INSERT INTO olala3w_core_privilege VALUES('2967','12','product','product_menu_del;37');
INSERT INTO olala3w_core_privilege VALUES('2968','12','product','product_list;37');
INSERT INTO olala3w_core_privilege VALUES('2969','12','product','product_add;37');
INSERT INTO olala3w_core_privilege VALUES('2970','12','product','product_edit;37');
INSERT INTO olala3w_core_privilege VALUES('2971','12','product','product_del;37');
INSERT INTO olala3w_core_privilege VALUES('2985','12','location','location_add;39');
INSERT INTO olala3w_core_privilege VALUES('2984','12','location','location_list;39');
INSERT INTO olala3w_core_privilege VALUES('2983','12','location','location_menu_del;39');
INSERT INTO olala3w_core_privilege VALUES('2982','12','location','location_menu_edit;39');
INSERT INTO olala3w_core_privilege VALUES('2981','12','location','location_menu_add;39');
INSERT INTO olala3w_core_privilege VALUES('2980','12','location','category_edit;39');
INSERT INTO olala3w_core_privilege VALUES('2986','12','location','location_edit;39');
INSERT INTO olala3w_core_privilege VALUES('2987','12','location','location_del;39');
INSERT INTO olala3w_core_privilege VALUES('2988','12','location','category_edit;40');
INSERT INTO olala3w_core_privilege VALUES('2989','12','location','location_menu_add;40');
INSERT INTO olala3w_core_privilege VALUES('2990','12','location','location_menu_edit;40');
INSERT INTO olala3w_core_privilege VALUES('2991','12','location','location_menu_del;40');
INSERT INTO olala3w_core_privilege VALUES('2992','12','location','location_list;40');
INSERT INTO olala3w_core_privilege VALUES('2993','12','location','location_add;40');
INSERT INTO olala3w_core_privilege VALUES('2994','12','location','location_edit;40');
INSERT INTO olala3w_core_privilege VALUES('2995','12','location','location_del;40');
INSERT INTO olala3w_core_privilege VALUES('2996','12','road','road_add');
INSERT INTO olala3w_core_privilege VALUES('2997','12','road','road_edit');
INSERT INTO olala3w_core_privilege VALUES('2998','12','road','road_del');
INSERT INTO olala3w_core_privilege VALUES('2999','12','street','street_add');
INSERT INTO olala3w_core_privilege VALUES('3000','12','street','street_edit');
INSERT INTO olala3w_core_privilege VALUES('3001','12','street','street_del');
INSERT INTO olala3w_core_privilege VALUES('3002','12','direction','direction_add');
INSERT INTO olala3w_core_privilege VALUES('3003','12','direction','direction_edit');
INSERT INTO olala3w_core_privilege VALUES('3004','12','direction','direction_del');
INSERT INTO olala3w_core_privilege VALUES('3005','12','prjname','prjname_add');
INSERT INTO olala3w_core_privilege VALUES('3006','12','prjname','prjname_edit');
INSERT INTO olala3w_core_privilege VALUES('3007','12','prjname','prjname_del');
INSERT INTO olala3w_core_privilege VALUES('3008','12','backup','backup_data');
INSERT INTO olala3w_core_privilege VALUES('3009','12','backup','backup_config');
INSERT INTO olala3w_core_privilege VALUES('3010','12','config','config_general');
INSERT INTO olala3w_core_privilege VALUES('3011','12','config','config_smtp');
INSERT INTO olala3w_core_privilege VALUES('3012','12','config','config_datetime');
INSERT INTO olala3w_core_privilege VALUES('3013','12','config','config_plugins');
INSERT INTO olala3w_core_privilege VALUES('3014','12','config','config_socialnetwork');
INSERT INTO olala3w_core_privilege VALUES('3015','12','config','config_search');
INSERT INTO olala3w_core_privilege VALUES('3016','12','config','config_upload');
INSERT INTO olala3w_core_privilege VALUES('3017','12','tool','tool_delete');
INSERT INTO olala3w_core_privilege VALUES('3018','12','tool','tool_site');
INSERT INTO olala3w_core_privilege VALUES('3019','12','tool','tool_keywords');
INSERT INTO olala3w_core_privilege VALUES('3020','12','tool','tool_ipdie');
INSERT INTO olala3w_core_privilege VALUES('3021','12','tool','tool_update');
INSERT INTO olala3w_core_privilege VALUES('3022','12','core','core_role');
INSERT INTO olala3w_core_privilege VALUES('3023','12','core','core_user');
INSERT INTO olala3w_core_privilege VALUES('3024','12','core','core_dashboard');
INSERT INTO olala3w_core_privilege VALUES('3025','12','core','core_mail');
INSERT INTO olala3w_core_privilege VALUES('3026','12','info','Info_diary');
INSERT INTO olala3w_core_privilege VALUES('3027','12','info','Info_php');
INSERT INTO olala3w_core_privilege VALUES('3028','12','info','Info_site');
INSERT INTO olala3w_core_privilege VALUES('3029','12','info','Info_expansion');
INSERT INTO olala3w_core_privilege VALUES('3032','11','article','article_menu_edit;9');
INSERT INTO olala3w_core_privilege VALUES('3033','11','article','article_menu_del;9');
INSERT INTO olala3w_core_privilege VALUES('3034','11','article','article_list;9');
INSERT INTO olala3w_core_privilege VALUES('3035','11','article','article_add;9');
INSERT INTO olala3w_core_privilege VALUES('3036','11','article','article_edit;9');
INSERT INTO olala3w_core_privilege VALUES('3037','11','article','article_del;9');
INSERT INTO olala3w_core_privilege VALUES('3038','11','article','category_edit;51');
INSERT INTO olala3w_core_privilege VALUES('3039','11','article','article_menu_add;51');
INSERT INTO olala3w_core_privilege VALUES('3040','11','article','article_menu_edit;51');
INSERT INTO olala3w_core_privilege VALUES('3041','11','article','article_menu_del;51');
INSERT INTO olala3w_core_privilege VALUES('3042','11','article','article_list;51');
INSERT INTO olala3w_core_privilege VALUES('3043','11','article','article_add;51');
INSERT INTO olala3w_core_privilege VALUES('3044','11','article','article_edit;51');
INSERT INTO olala3w_core_privilege VALUES('3045','11','article','article_del;51');
INSERT INTO olala3w_core_privilege VALUES('3046','11','article','category_edit;7');
INSERT INTO olala3w_core_privilege VALUES('3047','11','article','article_menu_add;7');
INSERT INTO olala3w_core_privilege VALUES('3048','11','article','article_menu_edit;7');
INSERT INTO olala3w_core_privilege VALUES('3049','11','article','article_menu_del;7');
INSERT INTO olala3w_core_privilege VALUES('3050','11','article','article_list;7');
INSERT INTO olala3w_core_privilege VALUES('3051','11','article','article_add;7');
INSERT INTO olala3w_core_privilege VALUES('3052','11','article','article_edit;7');
INSERT INTO olala3w_core_privilege VALUES('3053','11','article','article_del;7');
INSERT INTO olala3w_core_privilege VALUES('3054','11','gallery','category_edit;4');
INSERT INTO olala3w_core_privilege VALUES('3055','11','gallery','gallery_menu_add;4');
INSERT INTO olala3w_core_privilege VALUES('3056','11','gallery','gallery_menu_edit;4');
INSERT INTO olala3w_core_privilege VALUES('3057','11','gallery','gallery_menu_del;4');
INSERT INTO olala3w_core_privilege VALUES('3058','11','gallery','gallery_list;4');
INSERT INTO olala3w_core_privilege VALUES('3059','11','gallery','gallery_add;4');
INSERT INTO olala3w_core_privilege VALUES('3060','11','gallery','gallery_edit;4');
INSERT INTO olala3w_core_privilege VALUES('3061','11','gallery','gallery_del;4');
INSERT INTO olala3w_core_privilege VALUES('3062','11','gallery','category_edit;52');
INSERT INTO olala3w_core_privilege VALUES('3063','11','gallery','gallery_menu_add;52');
INSERT INTO olala3w_core_privilege VALUES('3064','11','gallery','gallery_menu_edit;52');
INSERT INTO olala3w_core_privilege VALUES('3065','11','gallery','gallery_menu_del;52');
INSERT INTO olala3w_core_privilege VALUES('3066','11','gallery','gallery_list;52');
INSERT INTO olala3w_core_privilege VALUES('3067','11','gallery','gallery_add;52');
INSERT INTO olala3w_core_privilege VALUES('3068','11','gallery','gallery_edit;52');
INSERT INTO olala3w_core_privilege VALUES('3069','11','gallery','gallery_del;52');
INSERT INTO olala3w_core_privilege VALUES('3070','11','project','category_edit;13');
INSERT INTO olala3w_core_privilege VALUES('3071','11','project','project_menu_add;13');
INSERT INTO olala3w_core_privilege VALUES('3072','11','project','project_menu_edit;13');
INSERT INTO olala3w_core_privilege VALUES('3073','11','project','project_menu_del;13');
INSERT INTO olala3w_core_privilege VALUES('3074','11','project','project_list;13');
INSERT INTO olala3w_core_privilege VALUES('3075','11','project','project_add;13');
INSERT INTO olala3w_core_privilege VALUES('3076','11','project','project_edit;13');
INSERT INTO olala3w_core_privilege VALUES('3077','11','project','project_del;13');
INSERT INTO olala3w_core_privilege VALUES('3078','11','project','category_edit;53');
INSERT INTO olala3w_core_privilege VALUES('3079','11','project','project_menu_add;53');
INSERT INTO olala3w_core_privilege VALUES('3080','11','project','project_menu_edit;53');
INSERT INTO olala3w_core_privilege VALUES('3081','11','project','project_menu_del;53');
INSERT INTO olala3w_core_privilege VALUES('3082','11','project','project_list;53');
INSERT INTO olala3w_core_privilege VALUES('3083','11','project','project_add;53');
INSERT INTO olala3w_core_privilege VALUES('3084','11','project','project_edit;53');
INSERT INTO olala3w_core_privilege VALUES('3085','11','project','project_del;53');
INSERT INTO olala3w_core_privilege VALUES('3137','11','product','owner_real;37');
INSERT INTO olala3w_core_privilege VALUES('3136','11','product','product_del;37');
INSERT INTO olala3w_core_privilege VALUES('3135','11','product','product_edit;37');
INSERT INTO olala3w_core_privilege VALUES('3134','11','product','product_add;37');
INSERT INTO olala3w_core_privilege VALUES('4644','1','product','product_list;9');
INSERT INTO olala3w_core_privilege VALUES('4643','1','product','product_menu_del;9');
INSERT INTO olala3w_core_privilege VALUES('4642','1','product','product_menu_edit;9');
INSERT INTO olala3w_core_privilege VALUES('3133','11','product','product_list;37');
INSERT INTO olala3w_core_privilege VALUES('3138','11','product','owner_cus;37');
INSERT INTO olala3w_core_privilege VALUES('3326','1','info','sys_info_php');
INSERT INTO olala3w_core_privilege VALUES('3325','1','info','sys_info_diary');
INSERT INTO olala3w_core_privilege VALUES('3334','1','core','core_mail');
INSERT INTO olala3w_core_privilege VALUES('4639','1','gallery','gallery_del;92');
INSERT INTO olala3w_core_privilege VALUES('4638','1','gallery','gallery_edit;92');
INSERT INTO olala3w_core_privilege VALUES('4637','1','gallery','gallery_add;92');
INSERT INTO olala3w_core_privilege VALUES('4636','1','gallery','gallery_list;92');
INSERT INTO olala3w_core_privilege VALUES('4635','1','gallery','gallery_menu_del;92');
INSERT INTO olala3w_core_privilege VALUES('4634','1','gallery','gallery_menu_edit;92');
INSERT INTO olala3w_core_privilege VALUES('4633','1','gallery','gallery_menu_add;92');
INSERT INTO olala3w_core_privilege VALUES('4632','1','gallery','category_edit;92');
INSERT INTO olala3w_core_privilege VALUES('4631','1','gallery','gallery_del;91');
INSERT INTO olala3w_core_privilege VALUES('4630','1','gallery','gallery_edit;91');
INSERT INTO olala3w_core_privilege VALUES('4629','1','gallery','gallery_add;91');
INSERT INTO olala3w_core_privilege VALUES('4628','1','gallery','gallery_list;91');
INSERT INTO olala3w_core_privilege VALUES('4627','1','gallery','gallery_menu_del;91');
INSERT INTO olala3w_core_privilege VALUES('4626','1','gallery','gallery_menu_edit;91');
INSERT INTO olala3w_core_privilege VALUES('4624','1','gallery','category_edit;91');
INSERT INTO olala3w_core_privilege VALUES('4625','1','gallery','gallery_menu_add;91');
INSERT INTO olala3w_core_privilege VALUES('4695','1','others','others_del;88');
INSERT INTO olala3w_core_privilege VALUES('4026','1','document','document_list;73');
INSERT INTO olala3w_core_privilege VALUES('4025','1','document','document_menu_del;73');
INSERT INTO olala3w_core_privilege VALUES('4024','1','document','document_menu_edit;73');
INSERT INTO olala3w_core_privilege VALUES('4023','1','document','document_menu_add;73');
INSERT INTO olala3w_core_privilege VALUES('4022','1','document','category_edit;73');
INSERT INTO olala3w_core_privilege VALUES('4028','1','document','document_edit;73');
INSERT INTO olala3w_core_privilege VALUES('4029','1','document','document_del;73');
INSERT INTO olala3w_core_privilege VALUES('4819','1','category','customer_list');
INSERT INTO olala3w_core_privilege VALUES('4818','1','category','contact_list');
INSERT INTO olala3w_core_privilege VALUES('4641','1','product','product_menu_add;9');
INSERT INTO olala3w_core_privilege VALUES('4640','1','product','category_edit;9');
INSERT INTO olala3w_core_privilege VALUES('4655','1','product','product_del;93');
INSERT INTO olala3w_core_privilege VALUES('4654','1','product','product_edit;93');
INSERT INTO olala3w_core_privilege VALUES('4653','1','product','product_add;93');
INSERT INTO olala3w_core_privilege VALUES('4652','1','product','product_list;93');
INSERT INTO olala3w_core_privilege VALUES('4651','1','product','product_menu_del;93');
INSERT INTO olala3w_core_privilege VALUES('4650','1','product','product_menu_edit;93');
INSERT INTO olala3w_core_privilege VALUES('4649','1','product','product_menu_add;93');
INSERT INTO olala3w_core_privilege VALUES('4648','1','product','category_edit;93');
INSERT INTO olala3w_core_privilege VALUES('4797','1','article','article_add;89');
INSERT INTO olala3w_core_privilege VALUES('4796','1','article','article_list;89');
INSERT INTO olala3w_core_privilege VALUES('4795','1','article','article_menu_del;89');
INSERT INTO olala3w_core_privilege VALUES('4794','1','article','article_menu_edit;89');
INSERT INTO olala3w_core_privilege VALUES('4793','1','article','article_menu_add;89');
INSERT INTO olala3w_core_privilege VALUES('4792','1','article','category_edit;89');
INSERT INTO olala3w_core_privilege VALUES('4791','1','article','article_del;97');
INSERT INTO olala3w_core_privilege VALUES('4790','1','article','article_edit;97');
INSERT INTO olala3w_core_privilege VALUES('4789','1','article','article_add;97');
INSERT INTO olala3w_core_privilege VALUES('4788','1','article','article_list;97');
INSERT INTO olala3w_core_privilege VALUES('4694','1','others','others_edit;88');
INSERT INTO olala3w_core_privilege VALUES('4693','1','others','others_add;88');
INSERT INTO olala3w_core_privilege VALUES('4692','1','others','others_list;88');
INSERT INTO olala3w_core_privilege VALUES('4691','1','others','others_menu_del;88');
INSERT INTO olala3w_core_privilege VALUES('4690','1','others','others_menu_edit;88');
INSERT INTO olala3w_core_privilege VALUES('4689','1','others','others_menu_add;88');
INSERT INTO olala3w_core_privilege VALUES('4688','1','others','category_edit;88');
INSERT INTO olala3w_core_privilege VALUES('4687','1','others','others_del;95');
INSERT INTO olala3w_core_privilege VALUES('4686','1','others','others_edit;95');
INSERT INTO olala3w_core_privilege VALUES('4685','1','others','others_add;95');
INSERT INTO olala3w_core_privilege VALUES('4684','1','others','others_list;95');
INSERT INTO olala3w_core_privilege VALUES('4683','1','others','others_menu_del;95');
INSERT INTO olala3w_core_privilege VALUES('4682','1','others','others_menu_edit;95');
INSERT INTO olala3w_core_privilege VALUES('4681','1','others','others_menu_add;95');
INSERT INTO olala3w_core_privilege VALUES('4680','1','others','category_edit;95');
INSERT INTO olala3w_core_privilege VALUES('4817','1','category','gallery_manager');
INSERT INTO olala3w_core_privilege VALUES('4816','1','category','article_manager');
INSERT INTO olala3w_core_privilege VALUES('4787','1','article','article_menu_del;97');
INSERT INTO olala3w_core_privilege VALUES('4786','1','article','article_menu_edit;97');
INSERT INTO olala3w_core_privilege VALUES('4785','1','article','article_menu_add;97');
INSERT INTO olala3w_core_privilege VALUES('4784','1','article','category_edit;97');
INSERT INTO olala3w_core_privilege VALUES('4783','1','article','article_del;94');
INSERT INTO olala3w_core_privilege VALUES('4781','1','article','article_add;94');
INSERT INTO olala3w_core_privilege VALUES('4782','1','article','article_edit;94');
INSERT INTO olala3w_core_privilege VALUES('4780','1','article','article_list;94');
INSERT INTO olala3w_core_privilege VALUES('4779','1','article','article_menu_del;94');
INSERT INTO olala3w_core_privilege VALUES('4778','1','article','article_menu_edit;94');
INSERT INTO olala3w_core_privilege VALUES('4777','1','article','article_menu_add;94');
INSERT INTO olala3w_core_privilege VALUES('4776','1','article','category_edit;94');
INSERT INTO olala3w_core_privilege VALUES('4775','1','article','article_del;98');
INSERT INTO olala3w_core_privilege VALUES('4774','1','article','article_edit;98');
INSERT INTO olala3w_core_privilege VALUES('4773','1','article','article_add;98');
INSERT INTO olala3w_core_privilege VALUES('4772','1','article','article_list;98');
INSERT INTO olala3w_core_privilege VALUES('4771','1','article','article_menu_del;98');
INSERT INTO olala3w_core_privilege VALUES('4770','1','article','article_menu_edit;98');
INSERT INTO olala3w_core_privilege VALUES('4769','1','article','article_menu_add;98');
INSERT INTO olala3w_core_privilege VALUES('4768','1','article','category_edit;98');
INSERT INTO olala3w_core_privilege VALUES('4801','1','article','article_menu_add;96');
INSERT INTO olala3w_core_privilege VALUES('4802','1','article','article_menu_edit;96');
INSERT INTO olala3w_core_privilege VALUES('4803','1','article','article_menu_del;96');
INSERT INTO olala3w_core_privilege VALUES('4804','1','article','article_list;96');
INSERT INTO olala3w_core_privilege VALUES('4805','1','article','article_add;96');
INSERT INTO olala3w_core_privilege VALUES('4806','1','article','article_edit;96');
INSERT INTO olala3w_core_privilege VALUES('4807','1','article','article_del;96');
INSERT INTO olala3w_core_privilege VALUES('4808','1','article','category_edit;90');
INSERT INTO olala3w_core_privilege VALUES('4809','1','article','article_menu_add;90');
INSERT INTO olala3w_core_privilege VALUES('4810','1','article','article_menu_edit;90');
INSERT INTO olala3w_core_privilege VALUES('4811','1','article','article_menu_del;90');
INSERT INTO olala3w_core_privilege VALUES('4812','1','article','article_list;90');
INSERT INTO olala3w_core_privilege VALUES('4813','1','article','article_add;90');
INSERT INTO olala3w_core_privilege VALUES('4814','1','article','article_edit;90');
INSERT INTO olala3w_core_privilege VALUES('4815','1','article','article_del;90');
INSERT INTO olala3w_core_privilege VALUES('4820','1','category','plugin_page');

-- --------------------------------------------------------

CREATE TABLE `olala3w_core_role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_core_role VALUES('1','Administrator','Nhóm quản trị tối cao','1','1441786254','1');
INSERT INTO olala3w_core_role VALUES('2','Tester','Nhóm kiểm thử','1','1441851198','1');
INSERT INTO olala3w_core_role VALUES('9','Broker','Nhân viên môi giới. Chỉ nhập và quản lý thông tin BĐS.','1','1439055844','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_core_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `user_name` varchar(16) NOT NULL,
  `password` varchar(50) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `gender` int(1) NOT NULL DEFAULT '0',
  `birthday` int(11) NOT NULL DEFAULT '0',
  `apply` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `is_show` int(1) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `vote` bigint(20) NOT NULL DEFAULT '1',
  `click_vote` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id_edit` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_core_user VALUES('1','1','admin','ca4c0178da5c3219c4150c77b16c935d','Administrator','1','696877200','Quản trị website','huyto.qng@gmail.com','0974779085','Thanh Khê - Đà Nẵng','','0','1','u_1488926690_2c2fdf897700774ab341f6f703fc1514.png','1','1','1','1408159832','1514622510','1');
INSERT INTO olala3w_core_user VALUES('25','1','dev','35622d129658338262443a22a9c7bac5','Tô Thái Huy','1','694198800','Kỹ thuật & phát triển','huyto.qng@gmail.com','0974 779 805','','','1','4','u_1437075987_ffbbbf570157f5aa239cf98d7caa354a.jpg','1','1','1','0','1498981974','1');
INSERT INTO olala3w_core_user VALUES('27','1','canh.nguyen','ea92e7f61ae8ffec59e55ab06407e8a7','Nguyễn Quang Cảnh','1','736534800','Chuyên viên tư vấn','canh@thienlongreal.com','0905 795 975','','','1','2','no','1','3','1','1498963475','1498981952','1');
INSERT INTO olala3w_core_user VALUES('28','1','yen.huynh','7d78d5050b9762868c51bbaf17c39625','Huỳnh Yến','2','768070800','Chuyên viên tư vấn','yen@thienlongreal.com','0905 499 942','','','1','5','no','1','3','1','1498963993','1499276740','1');
INSERT INTO olala3w_core_user VALUES('31','1','quoc.pham','f34ed748a0b693669ab1d6f3dbcfec0c','Phạm Đình Quốc','1','641840400','Chuyên viên tư vấn','quoc@thienlongreal.com','0905 077 742','','','1','6','no','1','3','1','1498964183','1499276740','1');
INSERT INTO olala3w_core_user VALUES('32','1','phuc.vo','f0e0c5590e617c76aeecd237d98148ea','Võ Hoàng Phúc','1','799606800','Chuyên viên tư vấn','phuc@thienlongreal.com','0935 351 525','','','1','3','no','1','3','1','1498964280','1498981975','1');
INSERT INTO olala3w_core_user VALUES('33','1','binh.nguyen','0672b59f9b986765c9c2e0825d2fa826','Nguyễn Văn Bình','1','641840400','Chuyên viên tư vấn','binh@thienlongreal.com','0935 589 502','','','0','7','no','1','3','1','1498964411','1498967936','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_direction` (
  `direction_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`direction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_document` (
  `document_id` int(11) NOT NULL AUTO_INCREMENT,
  `document_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `release_date` int(11) NOT NULL DEFAULT '0',
  `effective_date` int(11) NOT NULL DEFAULT '0',
  `file` varchar(255) NOT NULL DEFAULT 'no',
  `type` varchar(5) NOT NULL DEFAULT 'unk',
  `size` int(11) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `content` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`document_id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_document_menu` (
  `document_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL DEFAULT 'not-found',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `comment` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`document_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_gallery` (
  `gallery_id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `upload_id` bigint(20) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `content` text NOT NULL,
  `link` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gallery_id`)
) ENGINE=MyISAM AUTO_INCREMENT=635 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_gallery VALUES('628','84','Home Solution Apartment','img-1','','','','img-1-1511974615.jpg','1793','Dự án','','','1','1','1','1495295400','1512062690','1');
INSERT INTO olala3w_gallery VALUES('629','84','Img 2','img-2','','','','img-2-1511974630.jpg','1794','','','','1','0','1','1495294800','1511974630','25');
INSERT INTO olala3w_gallery VALUES('630','84','Img 3','img-3','','','','img-3-1511974648.jpg','1795','','','','1','0','1','1495294200','1511974648','25');
INSERT INTO olala3w_gallery VALUES('631','84','Img 4','img-4','','','','img-4-1511974712.jpg','1852','','','','1','0','1','1495293600','1511974712','25');
INSERT INTO olala3w_gallery VALUES('632','84','Img 5','img-5','','','','img-5-1511974744.jpg','1853','','','','1','0','1','1495293000','1511974744','25');

-- --------------------------------------------------------

CREATE TABLE `olala3w_gallery_menu` (
  `gallery_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `comment` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gallery_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_gallery_menu VALUES('84','91','Slider home','slider-home','','','','0','1','','1','0','no','1495095137','1495095137','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_gift` (
  `gift_id` int(11) NOT NULL AUTO_INCREMENT,
  `gift_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `price` bigint(15) NOT NULL DEFAULT '0',
  `made` varchar(255) NOT NULL,
  `material` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `content` longtext NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gift_id`)
) ENGINE=MyISAM AUTO_INCREMENT=132 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_gift_menu` (
  `gift_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gift_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=144 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_link` (
  `link_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `link` varchar(255) NOT NULL,
  `category` int(11) NOT NULL DEFAULT '0',
  `menu` int(11) NOT NULL DEFAULT '0',
  `post` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`link_id`)
) ENGINE=InnoDB AUTO_INCREMENT=358 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_link VALUES('1','gioi-thieu','94','0','0','1513527252');
INSERT INTO olala3w_link VALUES('2','slider','91','0','0','0');
INSERT INTO olala3w_link VALUES('5','kien-truc','89','0','0','1513527222');
INSERT INTO olala3w_link VALUES('6','tin-tuc','90','0','0','1513527261');
INSERT INTO olala3w_link VALUES('54','city','95','0','0','1494961394');
INSERT INTO olala3w_link VALUES('59','da-nang','95','3','0','1494961453');
INSERT INTO olala3w_link VALUES('60','quang-nam','95','4','0','1494961457');
INSERT INTO olala3w_link VALUES('61','quang-ngai','95','5','0','1494961461');
INSERT INTO olala3w_link VALUES('192','hai-chau','95','3','131','1495043231');
INSERT INTO olala3w_link VALUES('193','thanh-khe','95','3','132','1495043241');
INSERT INTO olala3w_link VALUES('194','lien-chieu','95','3','133','1495043251');
INSERT INTO olala3w_link VALUES('195','cam-le','95','3','134','1495043259');
INSERT INTO olala3w_link VALUES('196','son-tra','95','3','135','1495043267');
INSERT INTO olala3w_link VALUES('197','ngu-hanh-son','95','3','136','1495043278');
INSERT INTO olala3w_link VALUES('198','hoa-vang','95','3','137','1495043293');
INSERT INTO olala3w_link VALUES('199','hoang-sa','95','3','138','1495043633');
INSERT INTO olala3w_link VALUES('200','tam-ky','95','4','139','1495043672');
INSERT INTO olala3w_link VALUES('201','hoi-an','95','4','140','1495043679');
INSERT INTO olala3w_link VALUES('202','tay-giang','95','4','141','1495043687');
INSERT INTO olala3w_link VALUES('203','phu-ninh','95','4','142','1495043731');
INSERT INTO olala3w_link VALUES('204','dai-loc','95','4','143','1495043737');
INSERT INTO olala3w_link VALUES('205','nam-giang','95','4','144','1495043743');
INSERT INTO olala3w_link VALUES('206','dong-giang','95','4','145','1495043835');
INSERT INTO olala3w_link VALUES('207','nong-son','95','4','146','1495043849');
INSERT INTO olala3w_link VALUES('208','hiep-duc','95','4','147','1495043854');
INSERT INTO olala3w_link VALUES('209','que-son','95','4','148','1495043860');
INSERT INTO olala3w_link VALUES('210','tien-phuoc','95','4','149','1495043869');
INSERT INTO olala3w_link VALUES('211','phuoc-son','95','4','150','1495043876');
INSERT INTO olala3w_link VALUES('212','nui-thanh','95','4','151','1495043917');
INSERT INTO olala3w_link VALUES('213','nam-tra-my','95','4','152','1495043926');
INSERT INTO olala3w_link VALUES('214','dien-ban','95','4','153','1495043934');
INSERT INTO olala3w_link VALUES('215','duy-xuyen','95','4','154','1495043942');
INSERT INTO olala3w_link VALUES('216','thang-binh','95','4','155','1495043951');
INSERT INTO olala3w_link VALUES('217','bac-tra-my','95','4','156','1495043958');
INSERT INTO olala3w_link VALUES('218','slider-home','91','84','0','1495095137');
INSERT INTO olala3w_link VALUES('237','noi-that','96','0','0','1513527231');
INSERT INTO olala3w_link VALUES('258','img-1','91','84','628','1512062685');
INSERT INTO olala3w_link VALUES('259','img-2','91','84','629','1511974630');
INSERT INTO olala3w_link VALUES('260','img-3','91','84','630','1511974648');
INSERT INTO olala3w_link VALUES('267','adminw','0','0','0','0');
INSERT INTO olala3w_link VALUES('269','contact','0','0','0','0');
INSERT INTO olala3w_link VALUES('314','img-4','91','84','631','1511974712');
INSERT INTO olala3w_link VALUES('315','img-5','91','84','632','1511974744');
INSERT INTO olala3w_link VALUES('317','y-tuong','97','0','0','1513527215');
INSERT INTO olala3w_link VALUES('318','ve-chung-toi','94','428','0','1512313435');
INSERT INTO olala3w_link VALUES('319','kien-truc-nha-o','89','429','0','1513524595');
INSERT INTO olala3w_link VALUES('320','kien-truc-can-ho-dich-vu','89','430','0','1513524604');
INSERT INTO olala3w_link VALUES('321','kien-truc-cong-trinh-cong-cong','89','431','0','1513524612');
INSERT INTO olala3w_link VALUES('322','toa-nha','97','432','0','1514791780');
INSERT INTO olala3w_link VALUES('323','canh-quan','97','433','0','1513524310');
INSERT INTO olala3w_link VALUES('324','khu-dan-cu','97','434','0','1513524322');
INSERT INTO olala3w_link VALUES('326','thong-tin-thi-truong','90','436','0','1512182589');
INSERT INTO olala3w_link VALUES('327','kien-thuc-va-kinh-nghiem','90','437','0','1512182604');
INSERT INTO olala3w_link VALUES('328','khong-gian-dep','90','438','0','1512182612');
INSERT INTO olala3w_link VALUES('329','noi-that-nha-o','96','439','0','1513524402');
INSERT INTO olala3w_link VALUES('330','noi-that-can-ho-dich-vu','96','440','0','1513524421');
INSERT INTO olala3w_link VALUES('331','noi-that-cong-trinh-cong-cong','96','441','0','1513524442');
INSERT INTO olala3w_link VALUES('332','san-pham-dich-vu','94','442','0','1512312725');
INSERT INTO olala3w_link VALUES('333','nguon-nhan-luc','94','443','0','1512312745');
INSERT INTO olala3w_link VALUES('334','lien-he','94','444','0','1512312831');
INSERT INTO olala3w_link VALUES('337','gioi-thieu-s-home','94','428','890','1512414362');
INSERT INTO olala3w_link VALUES('339','uu-diem-cua-san-go-cong-nghiep','89','429','892','1513670501');
INSERT INTO olala3w_link VALUES('340','nha-sai-gon-42-m2-nhu-rong-gap-doi-nho-dung-tong-trang','89','429','893','1513670496');
INSERT INTO olala3w_link VALUES('341','can-bep-sai-gon-vua-lam-da-phai-pha-de-sua-lai','89','429','894','1513670477');
INSERT INTO olala3w_link VALUES('342','giuong-sieu-rong-giai-phap-cho-gia-dinh-muon-con-ngu-chung','89','429','895','1513670470');
INSERT INTO olala3w_link VALUES('343','nha-toi-bo-phi-giuong-tang-tu-khi-mua-2-nam-truoc','96','439','896','1513670583');
INSERT INTO olala3w_link VALUES('344','xay-nha-2-tang-dien-tich-su-dung-130m2-het-bao-nhieu-tien','96','439','897','1513670570');
INSERT INTO olala3w_link VALUES('345','phong-khach-tong-xanh-nen-chon-gach-lat-mau-gi','96','439','898','1513670557');
INSERT INTO olala3w_link VALUES('346','doc-gia-nhan-giai-tuan-5-6-cuoc-thi-thiet-ke-y-tuong-cho-phong-khach-thuong-luu','96','439','899','1513670539');
INSERT INTO olala3w_link VALUES('347','xay-dung','98','0','0','1513527239');
INSERT INTO olala3w_link VALUES('348','du-an-dang-thi-cong','98','448','0','1513611437');
INSERT INTO olala3w_link VALUES('349','cong-trinh-cai-tao','98','449','0','1513611443');
INSERT INTO olala3w_link VALUES('350','tags','0','0','0','0');
INSERT INTO olala3w_link VALUES('351','page','0','0','0','0');
INSERT INTO olala3w_link VALUES('352','du-an-da-hoan-thanh','98','447','0','1513611426');
INSERT INTO olala3w_link VALUES('353','sai-lam-khien-ban-dap-nhieu-tien-cho-nha-ma-van-xau','90','436','905','1513651730');
INSERT INTO olala3w_link VALUES('354','bi-mat-trong-chiec-chieu-he-mat-dong-am-cua-nguoi-nhat','90','436','906','1513673615');
INSERT INTO olala3w_link VALUES('355','cach-tao-khoang-tuong-nha-bep-thong-minh','90','437','907','1513651980');
INSERT INTO olala3w_link VALUES('357','demo-124xkad','94','428','909','1513653607');

-- --------------------------------------------------------

CREATE TABLE `olala3w_location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_location_menu` (
  `location_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`location_menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_online` (
  `online_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `site` varchar(255) NOT NULL,
  `agent` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`online_id`)
) ENGINE=InnoDB AUTO_INCREMENT=706 DEFAULT CHARSET=latin1;

INSERT INTO olala3w_online VALUES('705','127.0.0.1','1514792090','url=favicon.ico','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36','0');

-- --------------------------------------------------------

CREATE TABLE `olala3w_online_daily` (
  `online_daily_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`online_daily_id`)
) ENGINE=MyISAM AUTO_INCREMENT=720 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_online_daily VALUES('1','2014-08-18','3');
INSERT INTO olala3w_online_daily VALUES('2','2014-08-17','1');
INSERT INTO olala3w_online_daily VALUES('3','2014-08-14','102');
INSERT INTO olala3w_online_daily VALUES('4','2014-08-06','100');
INSERT INTO olala3w_online_daily VALUES('5','2014-08-16','3');
INSERT INTO olala3w_online_daily VALUES('6','2014-08-13','10');
INSERT INTO olala3w_online_daily VALUES('7','2014-08-11','40');
INSERT INTO olala3w_online_daily VALUES('8','2014-08-09','90');
INSERT INTO olala3w_online_daily VALUES('9','2014-08-15','82');
INSERT INTO olala3w_online_daily VALUES('10','2014-08-12','207');
INSERT INTO olala3w_online_daily VALUES('11','2014-08-10','10');
INSERT INTO olala3w_online_daily VALUES('12','2014-08-08','7');
INSERT INTO olala3w_online_daily VALUES('13','2014-08-07','13');
INSERT INTO olala3w_online_daily VALUES('14','2014-08-19','13');
INSERT INTO olala3w_online_daily VALUES('15','2014-08-20','9');
INSERT INTO olala3w_online_daily VALUES('16','2014-08-21','135');
INSERT INTO olala3w_online_daily VALUES('17','2014-08-22','5');
INSERT INTO olala3w_online_daily VALUES('18','2014-09-27','7');
INSERT INTO olala3w_online_daily VALUES('19','2014-09-28','16');
INSERT INTO olala3w_online_daily VALUES('20','2014-09-29','5');
INSERT INTO olala3w_online_daily VALUES('21','2014-09-30','14');
INSERT INTO olala3w_online_daily VALUES('22','2014-10-01','16');
INSERT INTO olala3w_online_daily VALUES('23','2014-10-02','12');
INSERT INTO olala3w_online_daily VALUES('24','2014-10-03','7');
INSERT INTO olala3w_online_daily VALUES('25','2014-10-04','1');
INSERT INTO olala3w_online_daily VALUES('26','2014-10-05','2');
INSERT INTO olala3w_online_daily VALUES('27','2014-10-07','4');
INSERT INTO olala3w_online_daily VALUES('28','2014-10-08','11');
INSERT INTO olala3w_online_daily VALUES('29','2014-10-14','1');
INSERT INTO olala3w_online_daily VALUES('30','2014-10-20','1');
INSERT INTO olala3w_online_daily VALUES('31','2014-10-26','4');
INSERT INTO olala3w_online_daily VALUES('32','2014-10-27','9');
INSERT INTO olala3w_online_daily VALUES('33','2014-10-28','11');
INSERT INTO olala3w_online_daily VALUES('34','2014-10-29','13');
INSERT INTO olala3w_online_daily VALUES('35','2014-10-30','10');
INSERT INTO olala3w_online_daily VALUES('36','2014-10-31','14');
INSERT INTO olala3w_online_daily VALUES('37','2014-11-01','8');
INSERT INTO olala3w_online_daily VALUES('38','2014-11-02','12');
INSERT INTO olala3w_online_daily VALUES('39','2014-11-03','2');
INSERT INTO olala3w_online_daily VALUES('40','2014-11-05','4');
INSERT INTO olala3w_online_daily VALUES('41','2014-11-06','2');
INSERT INTO olala3w_online_daily VALUES('42','2014-11-07','4');
INSERT INTO olala3w_online_daily VALUES('43','2014-11-08','1');
INSERT INTO olala3w_online_daily VALUES('44','2014-11-09','1');
INSERT INTO olala3w_online_daily VALUES('45','2014-11-10','11');
INSERT INTO olala3w_online_daily VALUES('46','2014-11-11','8');
INSERT INTO olala3w_online_daily VALUES('47','2014-11-12','3');
INSERT INTO olala3w_online_daily VALUES('48','2014-11-13','5');
INSERT INTO olala3w_online_daily VALUES('49','2014-11-14','6');
INSERT INTO olala3w_online_daily VALUES('50','2014-11-15','1');
INSERT INTO olala3w_online_daily VALUES('51','2014-11-16','1');
INSERT INTO olala3w_online_daily VALUES('52','2014-11-17','4');
INSERT INTO olala3w_online_daily VALUES('53','2014-11-18','1');
INSERT INTO olala3w_online_daily VALUES('54','2014-11-19','4');
INSERT INTO olala3w_online_daily VALUES('55','2014-11-20','1');
INSERT INTO olala3w_online_daily VALUES('56','2014-11-21','4');
INSERT INTO olala3w_online_daily VALUES('57','2014-11-22','1');
INSERT INTO olala3w_online_daily VALUES('58','2014-11-23','16');
INSERT INTO olala3w_online_daily VALUES('59','2014-11-24','1');
INSERT INTO olala3w_online_daily VALUES('60','2014-11-25','5');
INSERT INTO olala3w_online_daily VALUES('61','2014-11-27','15');
INSERT INTO olala3w_online_daily VALUES('62','2014-11-28','18');
INSERT INTO olala3w_online_daily VALUES('63','2014-11-29','10');
INSERT INTO olala3w_online_daily VALUES('64','2014-11-30','10');
INSERT INTO olala3w_online_daily VALUES('65','2014-12-01','6');
INSERT INTO olala3w_online_daily VALUES('66','2014-12-02','13');
INSERT INTO olala3w_online_daily VALUES('67','2014-12-03','9');
INSERT INTO olala3w_online_daily VALUES('68','2014-12-04','9');
INSERT INTO olala3w_online_daily VALUES('69','2014-12-05','7');
INSERT INTO olala3w_online_daily VALUES('70','2014-12-06','1');
INSERT INTO olala3w_online_daily VALUES('71','2014-12-08','5');
INSERT INTO olala3w_online_daily VALUES('72','2014-12-09','2');
INSERT INTO olala3w_online_daily VALUES('73','2014-12-10','5');
INSERT INTO olala3w_online_daily VALUES('74','2014-12-11','13');
INSERT INTO olala3w_online_daily VALUES('75','2014-12-12','4');
INSERT INTO olala3w_online_daily VALUES('76','2014-12-16','2');
INSERT INTO olala3w_online_daily VALUES('77','2014-12-20','11');
INSERT INTO olala3w_online_daily VALUES('78','2014-12-21','6');
INSERT INTO olala3w_online_daily VALUES('79','2014-12-22','5');
INSERT INTO olala3w_online_daily VALUES('80','2014-12-23','3');
INSERT INTO olala3w_online_daily VALUES('81','2014-12-24','1');
INSERT INTO olala3w_online_daily VALUES('82','2014-12-26','2');
INSERT INTO olala3w_online_daily VALUES('83','2014-12-27','10');
INSERT INTO olala3w_online_daily VALUES('84','0000-00-00','1');
INSERT INTO olala3w_online_daily VALUES('85','2014-12-28','15');
INSERT INTO olala3w_online_daily VALUES('86','2014-12-29','11');
INSERT INTO olala3w_online_daily VALUES('87','2014-12-30','1');
INSERT INTO olala3w_online_daily VALUES('88','2015-01-02','11');
INSERT INTO olala3w_online_daily VALUES('89','2015-01-03','4');
INSERT INTO olala3w_online_daily VALUES('90','2015-01-04','2');
INSERT INTO olala3w_online_daily VALUES('91','2015-01-05','9');
INSERT INTO olala3w_online_daily VALUES('92','2015-01-06','7');
INSERT INTO olala3w_online_daily VALUES('93','2015-01-07','1');
INSERT INTO olala3w_online_daily VALUES('94','2015-01-08','7');
INSERT INTO olala3w_online_daily VALUES('95','2015-01-09','13');
INSERT INTO olala3w_online_daily VALUES('96','2015-01-10','2');
INSERT INTO olala3w_online_daily VALUES('97','2015-01-12','1');
INSERT INTO olala3w_online_daily VALUES('98','2015-01-19','2');
INSERT INTO olala3w_online_daily VALUES('99','2015-01-20','12');
INSERT INTO olala3w_online_daily VALUES('100','2015-01-21','8');
INSERT INTO olala3w_online_daily VALUES('101','2015-01-22','43');
INSERT INTO olala3w_online_daily VALUES('102','2015-01-23','36');
INSERT INTO olala3w_online_daily VALUES('103','2015-01-24','34');
INSERT INTO olala3w_online_daily VALUES('104','2015-01-24','34');
INSERT INTO olala3w_online_daily VALUES('105','2015-01-25','46');
INSERT INTO olala3w_online_daily VALUES('106','2015-01-26','51');
INSERT INTO olala3w_online_daily VALUES('107','2015-01-27','53');
INSERT INTO olala3w_online_daily VALUES('108','2015-01-28','46');
INSERT INTO olala3w_online_daily VALUES('109','2015-01-29','471');
INSERT INTO olala3w_online_daily VALUES('110','2015-01-30','191');
INSERT INTO olala3w_online_daily VALUES('111','2015-01-31','106');
INSERT INTO olala3w_online_daily VALUES('112','2015-02-01','61');
INSERT INTO olala3w_online_daily VALUES('113','2015-02-02','37');
INSERT INTO olala3w_online_daily VALUES('114','2015-02-03','53');
INSERT INTO olala3w_online_daily VALUES('115','2015-02-04','66');
INSERT INTO olala3w_online_daily VALUES('116','2015-02-05','63');
INSERT INTO olala3w_online_daily VALUES('117','2015-02-06','86');
INSERT INTO olala3w_online_daily VALUES('118','2015-02-07','63');
INSERT INTO olala3w_online_daily VALUES('119','2015-02-08','68');
INSERT INTO olala3w_online_daily VALUES('120','2015-02-09','64');
INSERT INTO olala3w_online_daily VALUES('121','2015-02-10','46');
INSERT INTO olala3w_online_daily VALUES('122','2015-02-11','53');
INSERT INTO olala3w_online_daily VALUES('123','2015-02-12','28');
INSERT INTO olala3w_online_daily VALUES('124','2015-02-13','155');
INSERT INTO olala3w_online_daily VALUES('125','2015-02-14','43');
INSERT INTO olala3w_online_daily VALUES('126','2015-02-15','27');
INSERT INTO olala3w_online_daily VALUES('127','2015-02-16','22');
INSERT INTO olala3w_online_daily VALUES('128','2015-02-17','20');
INSERT INTO olala3w_online_daily VALUES('129','2015-02-18','19');
INSERT INTO olala3w_online_daily VALUES('130','2015-02-19','16');
INSERT INTO olala3w_online_daily VALUES('131','2015-02-20','18');
INSERT INTO olala3w_online_daily VALUES('132','2015-02-21','33');
INSERT INTO olala3w_online_daily VALUES('133','2015-02-22','31');
INSERT INTO olala3w_online_daily VALUES('134','2015-02-23','34');
INSERT INTO olala3w_online_daily VALUES('135','2015-02-24','22');
INSERT INTO olala3w_online_daily VALUES('136','2015-02-25','26');
INSERT INTO olala3w_online_daily VALUES('137','2015-02-26','34');
INSERT INTO olala3w_online_daily VALUES('138','2015-02-27','19');
INSERT INTO olala3w_online_daily VALUES('139','2015-02-28','5');
INSERT INTO olala3w_online_daily VALUES('140','2015-03-01','12');
INSERT INTO olala3w_online_daily VALUES('141','2015-03-02','24');
INSERT INTO olala3w_online_daily VALUES('142','2015-03-03','48');
INSERT INTO olala3w_online_daily VALUES('143','2015-03-04','49');
INSERT INTO olala3w_online_daily VALUES('144','2015-03-05','43');
INSERT INTO olala3w_online_daily VALUES('145','2015-03-06','33');
INSERT INTO olala3w_online_daily VALUES('146','2015-03-07','52');
INSERT INTO olala3w_online_daily VALUES('147','2015-03-08','26');
INSERT INTO olala3w_online_daily VALUES('148','2015-03-09','46');
INSERT INTO olala3w_online_daily VALUES('149','2015-03-10','37');
INSERT INTO olala3w_online_daily VALUES('150','2015-03-11','47');
INSERT INTO olala3w_online_daily VALUES('151','2015-03-12','33');
INSERT INTO olala3w_online_daily VALUES('152','2015-03-13','28');
INSERT INTO olala3w_online_daily VALUES('153','2015-03-14','2');
INSERT INTO olala3w_online_daily VALUES('154','2015-03-16','5');
INSERT INTO olala3w_online_daily VALUES('155','2015-03-17','18');
INSERT INTO olala3w_online_daily VALUES('156','2015-03-18','11');
INSERT INTO olala3w_online_daily VALUES('157','2015-03-19','21');
INSERT INTO olala3w_online_daily VALUES('158','2015-03-20','18');
INSERT INTO olala3w_online_daily VALUES('159','2015-03-21','3');
INSERT INTO olala3w_online_daily VALUES('160','2015-05-06','5');
INSERT INTO olala3w_online_daily VALUES('161','2015-05-07','4');
INSERT INTO olala3w_online_daily VALUES('162','2015-05-08','3');
INSERT INTO olala3w_online_daily VALUES('163','2015-05-09','2');
INSERT INTO olala3w_online_daily VALUES('164','2015-05-10','8');
INSERT INTO olala3w_online_daily VALUES('165','2015-05-11','3');
INSERT INTO olala3w_online_daily VALUES('166','2015-05-12','4');
INSERT INTO olala3w_online_daily VALUES('167','2015-05-15','1');
INSERT INTO olala3w_online_daily VALUES('168','2015-05-16','2');
INSERT INTO olala3w_online_daily VALUES('169','2015-05-17','2');
INSERT INTO olala3w_online_daily VALUES('170','2015-05-18','1');
INSERT INTO olala3w_online_daily VALUES('171','2015-05-19','3');
INSERT INTO olala3w_online_daily VALUES('172','2015-05-23','1');
INSERT INTO olala3w_online_daily VALUES('173','2015-05-24','1');
INSERT INTO olala3w_online_daily VALUES('174','2015-05-25','2');
INSERT INTO olala3w_online_daily VALUES('175','2015-05-26','2');
INSERT INTO olala3w_online_daily VALUES('176','2015-05-27','4');
INSERT INTO olala3w_online_daily VALUES('177','2015-05-28','4');
INSERT INTO olala3w_online_daily VALUES('178','2015-05-29','3');
INSERT INTO olala3w_online_daily VALUES('179','2015-05-31','3');
INSERT INTO olala3w_online_daily VALUES('180','2015-06-01','1');
INSERT INTO olala3w_online_daily VALUES('181','2015-06-02','2');
INSERT INTO olala3w_online_daily VALUES('182','2015-06-03','3');
INSERT INTO olala3w_online_daily VALUES('183','2015-06-04','3');
INSERT INTO olala3w_online_daily VALUES('184','2015-06-05','1');
INSERT INTO olala3w_online_daily VALUES('185','2015-06-06','1');
INSERT INTO olala3w_online_daily VALUES('186','2015-06-08','1');
INSERT INTO olala3w_online_daily VALUES('187','2015-06-09','2');
INSERT INTO olala3w_online_daily VALUES('188','2015-06-10','1');
INSERT INTO olala3w_online_daily VALUES('189','2015-06-11','2');
INSERT INTO olala3w_online_daily VALUES('190','2015-06-12','3');
INSERT INTO olala3w_online_daily VALUES('191','2015-06-13','2');
INSERT INTO olala3w_online_daily VALUES('192','2015-06-14','1');
INSERT INTO olala3w_online_daily VALUES('193','2015-06-15','4');
INSERT INTO olala3w_online_daily VALUES('194','2015-06-16','1');
INSERT INTO olala3w_online_daily VALUES('195','2015-06-17','1');
INSERT INTO olala3w_online_daily VALUES('196','2015-06-18','1');
INSERT INTO olala3w_online_daily VALUES('197','2015-06-21','1');
INSERT INTO olala3w_online_daily VALUES('198','2015-06-22','3');
INSERT INTO olala3w_online_daily VALUES('199','2015-06-23','1');
INSERT INTO olala3w_online_daily VALUES('200','2015-06-24','8');
INSERT INTO olala3w_online_daily VALUES('201','2015-06-28','1');
INSERT INTO olala3w_online_daily VALUES('202','2015-06-29','3');
INSERT INTO olala3w_online_daily VALUES('203','2015-06-30','4');
INSERT INTO olala3w_online_daily VALUES('204','2015-07-01','4');
INSERT INTO olala3w_online_daily VALUES('205','2015-07-02','3');
INSERT INTO olala3w_online_daily VALUES('206','2015-07-03','3');
INSERT INTO olala3w_online_daily VALUES('207','2015-07-06','1');
INSERT INTO olala3w_online_daily VALUES('208','2015-07-07','1');
INSERT INTO olala3w_online_daily VALUES('209','2015-07-12','4');
INSERT INTO olala3w_online_daily VALUES('210','2015-07-13','6');
INSERT INTO olala3w_online_daily VALUES('211','2015-07-14','29');
INSERT INTO olala3w_online_daily VALUES('212','2015-07-15','190');
INSERT INTO olala3w_online_daily VALUES('213','2015-07-16','361');
INSERT INTO olala3w_online_daily VALUES('214','2015-07-17','354');
INSERT INTO olala3w_online_daily VALUES('215','2015-07-18','238');
INSERT INTO olala3w_online_daily VALUES('216','2015-07-19','343');
INSERT INTO olala3w_online_daily VALUES('217','2015-07-20','802');
INSERT INTO olala3w_online_daily VALUES('218','2015-07-21','1926');
INSERT INTO olala3w_online_daily VALUES('219','2015-07-22','1349');
INSERT INTO olala3w_online_daily VALUES('220','2015-07-23','1648');
INSERT INTO olala3w_online_daily VALUES('221','2015-07-24','2370');
INSERT INTO olala3w_online_daily VALUES('222','2015-07-25','4986');
INSERT INTO olala3w_online_daily VALUES('223','2015-07-26','2251');
INSERT INTO olala3w_online_daily VALUES('224','2015-07-27','3882');
INSERT INTO olala3w_online_daily VALUES('225','2015-07-28','3496');
INSERT INTO olala3w_online_daily VALUES('226','2015-07-29','3603');
INSERT INTO olala3w_online_daily VALUES('227','2015-07-30','2778');
INSERT INTO olala3w_online_daily VALUES('228','2015-07-31','5');
INSERT INTO olala3w_online_daily VALUES('229','2015-08-01','2');
INSERT INTO olala3w_online_daily VALUES('230','2015-08-02','3');
INSERT INTO olala3w_online_daily VALUES('231','2015-08-03','2');
INSERT INTO olala3w_online_daily VALUES('232','2015-08-05','5');
INSERT INTO olala3w_online_daily VALUES('233','2015-08-06','1');
INSERT INTO olala3w_online_daily VALUES('234','2015-08-07','5');
INSERT INTO olala3w_online_daily VALUES('235','2015-08-08','8');
INSERT INTO olala3w_online_daily VALUES('236','2015-08-09','7');
INSERT INTO olala3w_online_daily VALUES('237','2015-08-10','6');
INSERT INTO olala3w_online_daily VALUES('238','2015-08-11','1');
INSERT INTO olala3w_online_daily VALUES('239','2015-08-12','2');
INSERT INTO olala3w_online_daily VALUES('240','2015-08-13','3');
INSERT INTO olala3w_online_daily VALUES('241','2015-08-14','1');
INSERT INTO olala3w_online_daily VALUES('242','2015-08-16','2');
INSERT INTO olala3w_online_daily VALUES('243','2015-08-17','2');
INSERT INTO olala3w_online_daily VALUES('244','2015-08-18','1');
INSERT INTO olala3w_online_daily VALUES('245','2015-08-28','2');
INSERT INTO olala3w_online_daily VALUES('246','2015-08-29','1');
INSERT INTO olala3w_online_daily VALUES('247','2015-08-30','1');
INSERT INTO olala3w_online_daily VALUES('248','2015-08-31','3');
INSERT INTO olala3w_online_daily VALUES('249','2015-09-01','1');
INSERT INTO olala3w_online_daily VALUES('250','2015-09-04','1');
INSERT INTO olala3w_online_daily VALUES('251','2015-09-05','1');
INSERT INTO olala3w_online_daily VALUES('252','2015-09-06','1');
INSERT INTO olala3w_online_daily VALUES('253','2015-09-07','1');
INSERT INTO olala3w_online_daily VALUES('254','2015-09-08','1');
INSERT INTO olala3w_online_daily VALUES('255','2015-09-09','3');
INSERT INTO olala3w_online_daily VALUES('256','2015-09-10','3');
INSERT INTO olala3w_online_daily VALUES('257','2015-09-11','2');
INSERT INTO olala3w_online_daily VALUES('258','2015-09-17','1');
INSERT INTO olala3w_online_daily VALUES('259','2015-09-27','3');
INSERT INTO olala3w_online_daily VALUES('260','2015-09-28','2');
INSERT INTO olala3w_online_daily VALUES('261','2015-10-19','1');
INSERT INTO olala3w_online_daily VALUES('262','2015-10-20','4');
INSERT INTO olala3w_online_daily VALUES('263','2015-10-21','1');
INSERT INTO olala3w_online_daily VALUES('264','2015-10-24','1');
INSERT INTO olala3w_online_daily VALUES('265','2015-10-25','5');
INSERT INTO olala3w_online_daily VALUES('266','2015-10-26','22');
INSERT INTO olala3w_online_daily VALUES('267','2015-10-27','36');
INSERT INTO olala3w_online_daily VALUES('268','2015-11-10','1');
INSERT INTO olala3w_online_daily VALUES('269','2015-11-11','3');
INSERT INTO olala3w_online_daily VALUES('270','2015-11-12','22');
INSERT INTO olala3w_online_daily VALUES('271','2015-11-13','45');
INSERT INTO olala3w_online_daily VALUES('272','2015-11-14','9');
INSERT INTO olala3w_online_daily VALUES('273','2015-11-15','27');
INSERT INTO olala3w_online_daily VALUES('274','2015-11-16','36');
INSERT INTO olala3w_online_daily VALUES('275','2015-11-17','24');
INSERT INTO olala3w_online_daily VALUES('276','2015-11-18','10');
INSERT INTO olala3w_online_daily VALUES('277','2015-11-19','14');
INSERT INTO olala3w_online_daily VALUES('278','2015-11-20','7');
INSERT INTO olala3w_online_daily VALUES('279','2015-11-21','5');
INSERT INTO olala3w_online_daily VALUES('280','2015-11-22','1');
INSERT INTO olala3w_online_daily VALUES('281','2015-11-23','12');
INSERT INTO olala3w_online_daily VALUES('282','2015-11-24','5');
INSERT INTO olala3w_online_daily VALUES('283','2015-11-27','1');
INSERT INTO olala3w_online_daily VALUES('284','2015-11-28','2');
INSERT INTO olala3w_online_daily VALUES('285','2015-11-29','1');
INSERT INTO olala3w_online_daily VALUES('286','2015-11-30','4');
INSERT INTO olala3w_online_daily VALUES('287','2015-12-01','38');
INSERT INTO olala3w_online_daily VALUES('288','2015-12-02','34');
INSERT INTO olala3w_online_daily VALUES('289','2015-12-03','41');
INSERT INTO olala3w_online_daily VALUES('290','2015-12-04','34');
INSERT INTO olala3w_online_daily VALUES('291','2015-12-09','1');
INSERT INTO olala3w_online_daily VALUES('292','2015-12-19','1');
INSERT INTO olala3w_online_daily VALUES('293','2015-12-20','2');
INSERT INTO olala3w_online_daily VALUES('294','2015-12-21','7');
INSERT INTO olala3w_online_daily VALUES('295','2015-12-22','5');
INSERT INTO olala3w_online_daily VALUES('296','2015-12-23','52');
INSERT INTO olala3w_online_daily VALUES('297','2015-12-24','37');
INSERT INTO olala3w_online_daily VALUES('298','2015-12-25','39');
INSERT INTO olala3w_online_daily VALUES('299','2015-12-26','13');
INSERT INTO olala3w_online_daily VALUES('300','2015-12-27','2');
INSERT INTO olala3w_online_daily VALUES('301','2015-12-28','18');
INSERT INTO olala3w_online_daily VALUES('302','2015-12-29','9');
INSERT INTO olala3w_online_daily VALUES('303','2015-12-30','16');
INSERT INTO olala3w_online_daily VALUES('304','2015-12-31','6');
INSERT INTO olala3w_online_daily VALUES('305','2016-01-07','3');
INSERT INTO olala3w_online_daily VALUES('306','2016-01-08','3');
INSERT INTO olala3w_online_daily VALUES('307','2016-01-09','7');
INSERT INTO olala3w_online_daily VALUES('308','2016-01-10','1');
INSERT INTO olala3w_online_daily VALUES('309','2016-01-12','7');
INSERT INTO olala3w_online_daily VALUES('310','2016-01-13','4');
INSERT INTO olala3w_online_daily VALUES('311','2016-01-14','4');
INSERT INTO olala3w_online_daily VALUES('312','2016-01-15','14');
INSERT INTO olala3w_online_daily VALUES('313','2016-01-16','66');
INSERT INTO olala3w_online_daily VALUES('314','2016-01-17','45');
INSERT INTO olala3w_online_daily VALUES('315','2016-01-18','31');
INSERT INTO olala3w_online_daily VALUES('316','2016-01-19','7');
INSERT INTO olala3w_online_daily VALUES('317','2016-01-20','12');
INSERT INTO olala3w_online_daily VALUES('318','2016-01-21','5');
INSERT INTO olala3w_online_daily VALUES('319','2016-01-22','7');
INSERT INTO olala3w_online_daily VALUES('320','2016-01-23','4');
INSERT INTO olala3w_online_daily VALUES('321','2016-01-24','1');
INSERT INTO olala3w_online_daily VALUES('322','2016-01-25','25');
INSERT INTO olala3w_online_daily VALUES('323','2016-01-26','1');
INSERT INTO olala3w_online_daily VALUES('324','2016-01-27','11');
INSERT INTO olala3w_online_daily VALUES('325','2016-01-28','40');
INSERT INTO olala3w_online_daily VALUES('326','2016-01-29','35');
INSERT INTO olala3w_online_daily VALUES('327','2016-01-30','6');
INSERT INTO olala3w_online_daily VALUES('328','2016-02-01','14');
INSERT INTO olala3w_online_daily VALUES('329','2016-02-02','40');
INSERT INTO olala3w_online_daily VALUES('330','2016-02-03','163');
INSERT INTO olala3w_online_daily VALUES('331','2016-02-04','81');
INSERT INTO olala3w_online_daily VALUES('332','2016-02-05','63');
INSERT INTO olala3w_online_daily VALUES('333','2016-02-06','52');
INSERT INTO olala3w_online_daily VALUES('334','2016-02-07','38');
INSERT INTO olala3w_online_daily VALUES('335','2016-02-08','35');
INSERT INTO olala3w_online_daily VALUES('336','2016-02-09','48');
INSERT INTO olala3w_online_daily VALUES('337','2016-02-10','39');
INSERT INTO olala3w_online_daily VALUES('338','2016-02-11','34');
INSERT INTO olala3w_online_daily VALUES('339','2016-02-12','74');
INSERT INTO olala3w_online_daily VALUES('340','2016-02-13','56');
INSERT INTO olala3w_online_daily VALUES('341','2016-02-14','60');
INSERT INTO olala3w_online_daily VALUES('342','2016-02-15','104');
INSERT INTO olala3w_online_daily VALUES('343','2016-02-16','59');
INSERT INTO olala3w_online_daily VALUES('344','2016-02-17','58');
INSERT INTO olala3w_online_daily VALUES('345','2016-02-18','43');
INSERT INTO olala3w_online_daily VALUES('346','2016-02-19','2');
INSERT INTO olala3w_online_daily VALUES('347','2016-02-20','2');
INSERT INTO olala3w_online_daily VALUES('348','2016-02-22','3');
INSERT INTO olala3w_online_daily VALUES('349','2016-03-01','1');
INSERT INTO olala3w_online_daily VALUES('350','2016-03-04','3');
INSERT INTO olala3w_online_daily VALUES('351','2016-03-04','3');
INSERT INTO olala3w_online_daily VALUES('352','2016-03-07','1');
INSERT INTO olala3w_online_daily VALUES('353','2016-03-08','1');
INSERT INTO olala3w_online_daily VALUES('354','2016-03-09','14');
INSERT INTO olala3w_online_daily VALUES('355','2016-03-10','5');
INSERT INTO olala3w_online_daily VALUES('356','2016-03-11','6');
INSERT INTO olala3w_online_daily VALUES('357','2016-03-13','2');
INSERT INTO olala3w_online_daily VALUES('358','2016-03-14','1');
INSERT INTO olala3w_online_daily VALUES('359','2016-03-20','1');
INSERT INTO olala3w_online_daily VALUES('360','2016-03-26','8');
INSERT INTO olala3w_online_daily VALUES('361','2016-03-27','8');
INSERT INTO olala3w_online_daily VALUES('362','2016-03-28','46');
INSERT INTO olala3w_online_daily VALUES('363','2016-03-29','1');
INSERT INTO olala3w_online_daily VALUES('364','2016-03-30','11');
INSERT INTO olala3w_online_daily VALUES('365','2016-03-31','2');
INSERT INTO olala3w_online_daily VALUES('366','2016-04-02','1');
INSERT INTO olala3w_online_daily VALUES('367','2016-04-03','5');
INSERT INTO olala3w_online_daily VALUES('368','2016-04-04','10');
INSERT INTO olala3w_online_daily VALUES('369','2016-04-05','31');
INSERT INTO olala3w_online_daily VALUES('370','2016-04-06','65');
INSERT INTO olala3w_online_daily VALUES('371','2016-04-07','35');
INSERT INTO olala3w_online_daily VALUES('372','2016-04-08','15');
INSERT INTO olala3w_online_daily VALUES('373','2016-04-09','1');
INSERT INTO olala3w_online_daily VALUES('374','2016-04-20','2');
INSERT INTO olala3w_online_daily VALUES('375','2016-04-22','2');
INSERT INTO olala3w_online_daily VALUES('376','2016-04-23','7');
INSERT INTO olala3w_online_daily VALUES('377','2016-04-24','8');
INSERT INTO olala3w_online_daily VALUES('378','2016-04-25','1');
INSERT INTO olala3w_online_daily VALUES('379','2016-04-26','2');
INSERT INTO olala3w_online_daily VALUES('380','2016-04-27','4');
INSERT INTO olala3w_online_daily VALUES('381','2016-04-28','3');
INSERT INTO olala3w_online_daily VALUES('382','2016-05-05','1');
INSERT INTO olala3w_online_daily VALUES('383','2016-05-08','9');
INSERT INTO olala3w_online_daily VALUES('384','2016-05-09','3');
INSERT INTO olala3w_online_daily VALUES('385','2016-05-10','2');
INSERT INTO olala3w_online_daily VALUES('386','2016-05-11','5');
INSERT INTO olala3w_online_daily VALUES('387','2016-05-12','6');
INSERT INTO olala3w_online_daily VALUES('388','2016-05-13','11');
INSERT INTO olala3w_online_daily VALUES('389','2016-05-15','3');
INSERT INTO olala3w_online_daily VALUES('390','2016-05-16','8');
INSERT INTO olala3w_online_daily VALUES('391','2016-05-17','7');
INSERT INTO olala3w_online_daily VALUES('392','2016-05-19','3');
INSERT INTO olala3w_online_daily VALUES('393','2016-05-19','3');
INSERT INTO olala3w_online_daily VALUES('394','2016-05-20','2');
INSERT INTO olala3w_online_daily VALUES('395','2016-05-22','5');
INSERT INTO olala3w_online_daily VALUES('396','2016-05-23','1');
INSERT INTO olala3w_online_daily VALUES('397','2016-05-24','1');
INSERT INTO olala3w_online_daily VALUES('398','2016-05-30','5');
INSERT INTO olala3w_online_daily VALUES('399','2016-06-16','1');
INSERT INTO olala3w_online_daily VALUES('400','2016-06-24','5');
INSERT INTO olala3w_online_daily VALUES('401','2016-06-25','12');
INSERT INTO olala3w_online_daily VALUES('402','2016-06-26','5');
INSERT INTO olala3w_online_daily VALUES('403','2016-08-08','6');
INSERT INTO olala3w_online_daily VALUES('404','2016-08-09','4');
INSERT INTO olala3w_online_daily VALUES('405','2016-08-10','5');
INSERT INTO olala3w_online_daily VALUES('406','2016-08-11','2');
INSERT INTO olala3w_online_daily VALUES('407','2016-08-12','6');
INSERT INTO olala3w_online_daily VALUES('408','2016-08-14','1');
INSERT INTO olala3w_online_daily VALUES('409','2016-08-16','12');
INSERT INTO olala3w_online_daily VALUES('410','2016-08-17','39');
INSERT INTO olala3w_online_daily VALUES('411','2016-08-18','157');
INSERT INTO olala3w_online_daily VALUES('412','2016-08-19','196');
INSERT INTO olala3w_online_daily VALUES('413','2016-08-20','227');
INSERT INTO olala3w_online_daily VALUES('414','2016-08-21','190');
INSERT INTO olala3w_online_daily VALUES('415','2016-08-22','545');
INSERT INTO olala3w_online_daily VALUES('416','2016-08-23','367');
INSERT INTO olala3w_online_daily VALUES('417','2016-08-24','369');
INSERT INTO olala3w_online_daily VALUES('418','2016-08-25','418');
INSERT INTO olala3w_online_daily VALUES('419','2016-08-26','512');
INSERT INTO olala3w_online_daily VALUES('420','2016-08-27','614');
INSERT INTO olala3w_online_daily VALUES('421','2016-08-28','631');
INSERT INTO olala3w_online_daily VALUES('422','2016-08-29','728');
INSERT INTO olala3w_online_daily VALUES('423','2016-08-30','579');
INSERT INTO olala3w_online_daily VALUES('424','2016-08-31','333');
INSERT INTO olala3w_online_daily VALUES('425','2016-09-01','219');
INSERT INTO olala3w_online_daily VALUES('426','2016-09-02','108');
INSERT INTO olala3w_online_daily VALUES('427','2016-09-03','157');
INSERT INTO olala3w_online_daily VALUES('428','2016-09-04','156');
INSERT INTO olala3w_online_daily VALUES('429','2016-09-05','662');
INSERT INTO olala3w_online_daily VALUES('430','2016-09-06','744');
INSERT INTO olala3w_online_daily VALUES('431','2016-09-07','504');
INSERT INTO olala3w_online_daily VALUES('432','2016-09-08','571');
INSERT INTO olala3w_online_daily VALUES('433','2016-09-09','516');
INSERT INTO olala3w_online_daily VALUES('434','2016-09-10','484');
INSERT INTO olala3w_online_daily VALUES('435','2016-09-11','384');
INSERT INTO olala3w_online_daily VALUES('436','2016-09-12','332');
INSERT INTO olala3w_online_daily VALUES('437','2016-09-13','371');
INSERT INTO olala3w_online_daily VALUES('438','2016-09-14','338');
INSERT INTO olala3w_online_daily VALUES('439','2016-09-15','366');
INSERT INTO olala3w_online_daily VALUES('440','2016-09-16','536');
INSERT INTO olala3w_online_daily VALUES('441','2016-09-17','345');
INSERT INTO olala3w_online_daily VALUES('442','2016-09-18','363');
INSERT INTO olala3w_online_daily VALUES('443','2016-09-19','354');
INSERT INTO olala3w_online_daily VALUES('444','2016-09-20','359');
INSERT INTO olala3w_online_daily VALUES('445','2016-09-21','471');
INSERT INTO olala3w_online_daily VALUES('446','2016-09-22','405');
INSERT INTO olala3w_online_daily VALUES('447','2016-09-23','460');
INSERT INTO olala3w_online_daily VALUES('448','2016-09-24','461');
INSERT INTO olala3w_online_daily VALUES('449','2016-09-25','426');
INSERT INTO olala3w_online_daily VALUES('450','2016-09-26','432');
INSERT INTO olala3w_online_daily VALUES('451','2016-09-27','447');
INSERT INTO olala3w_online_daily VALUES('452','2016-09-28','324');
INSERT INTO olala3w_online_daily VALUES('453','2016-09-29','167');
INSERT INTO olala3w_online_daily VALUES('454','2016-09-30','265');
INSERT INTO olala3w_online_daily VALUES('455','2016-10-01','334');
INSERT INTO olala3w_online_daily VALUES('456','2016-10-02','272');
INSERT INTO olala3w_online_daily VALUES('457','2016-10-03','217');
INSERT INTO olala3w_online_daily VALUES('458','2016-10-04','214');
INSERT INTO olala3w_online_daily VALUES('459','2016-10-05','367');
INSERT INTO olala3w_online_daily VALUES('460','2016-10-06','462');
INSERT INTO olala3w_online_daily VALUES('461','2016-10-07','394');
INSERT INTO olala3w_online_daily VALUES('462','2016-10-08','321');
INSERT INTO olala3w_online_daily VALUES('463','2016-10-09','247');
INSERT INTO olala3w_online_daily VALUES('464','2016-10-10','268');
INSERT INTO olala3w_online_daily VALUES('465','2016-10-11','348');
INSERT INTO olala3w_online_daily VALUES('466','2016-10-12','471');
INSERT INTO olala3w_online_daily VALUES('467','2016-10-13','451');
INSERT INTO olala3w_online_daily VALUES('468','2016-10-14','502');
INSERT INTO olala3w_online_daily VALUES('469','2016-10-15','300');
INSERT INTO olala3w_online_daily VALUES('470','2016-10-16','228');
INSERT INTO olala3w_online_daily VALUES('471','2016-10-17','234');
INSERT INTO olala3w_online_daily VALUES('472','2016-10-18','272');
INSERT INTO olala3w_online_daily VALUES('473','2016-10-19','276');
INSERT INTO olala3w_online_daily VALUES('474','2016-10-20','366');
INSERT INTO olala3w_online_daily VALUES('475','2016-10-21','205');
INSERT INTO olala3w_online_daily VALUES('476','2016-10-22','228');
INSERT INTO olala3w_online_daily VALUES('477','2016-10-23','304');
INSERT INTO olala3w_online_daily VALUES('478','2016-10-24','286');
INSERT INTO olala3w_online_daily VALUES('479','2016-10-25','383');
INSERT INTO olala3w_online_daily VALUES('480','2016-10-26','338');
INSERT INTO olala3w_online_daily VALUES('481','2016-10-27','249');
INSERT INTO olala3w_online_daily VALUES('482','2016-10-28','295');
INSERT INTO olala3w_online_daily VALUES('483','2016-10-29','542');
INSERT INTO olala3w_online_daily VALUES('484','2016-10-30','468');
INSERT INTO olala3w_online_daily VALUES('485','2016-10-31','473');
INSERT INTO olala3w_online_daily VALUES('486','2016-11-01','300');
INSERT INTO olala3w_online_daily VALUES('487','2016-11-02','263');
INSERT INTO olala3w_online_daily VALUES('488','2016-11-03','369');
INSERT INTO olala3w_online_daily VALUES('489','2016-11-04','320');
INSERT INTO olala3w_online_daily VALUES('490','2016-11-05','202');
INSERT INTO olala3w_online_daily VALUES('491','2016-11-06','216');
INSERT INTO olala3w_online_daily VALUES('492','2016-11-07','243');
INSERT INTO olala3w_online_daily VALUES('493','2016-11-08','228');
INSERT INTO olala3w_online_daily VALUES('494','2016-11-09','200');
INSERT INTO olala3w_online_daily VALUES('495','2016-11-10','335');
INSERT INTO olala3w_online_daily VALUES('496','2016-11-11','189');
INSERT INTO olala3w_online_daily VALUES('497','2016-11-12','199');
INSERT INTO olala3w_online_daily VALUES('498','2016-11-13','476');
INSERT INTO olala3w_online_daily VALUES('499','2016-11-14','748');
INSERT INTO olala3w_online_daily VALUES('500','2016-11-15','384');
INSERT INTO olala3w_online_daily VALUES('501','2016-11-16','535');
INSERT INTO olala3w_online_daily VALUES('502','2016-11-17','669');
INSERT INTO olala3w_online_daily VALUES('503','2016-11-18','714');
INSERT INTO olala3w_online_daily VALUES('504','2016-11-19','778');
INSERT INTO olala3w_online_daily VALUES('505','2016-11-20','472');
INSERT INTO olala3w_online_daily VALUES('506','2016-11-21','339');
INSERT INTO olala3w_online_daily VALUES('507','2016-11-22','489');
INSERT INTO olala3w_online_daily VALUES('508','2016-11-23','283');
INSERT INTO olala3w_online_daily VALUES('509','2016-11-24','246');
INSERT INTO olala3w_online_daily VALUES('510','2016-11-25','276');
INSERT INTO olala3w_online_daily VALUES('511','2016-11-26','288');
INSERT INTO olala3w_online_daily VALUES('512','2016-11-27','268');
INSERT INTO olala3w_online_daily VALUES('513','2016-11-28','504');
INSERT INTO olala3w_online_daily VALUES('514','2016-11-29','478');
INSERT INTO olala3w_online_daily VALUES('515','2016-11-30','694');
INSERT INTO olala3w_online_daily VALUES('516','2016-12-01','524');
INSERT INTO olala3w_online_daily VALUES('517','2016-12-02','456');
INSERT INTO olala3w_online_daily VALUES('518','2016-12-03','450');
INSERT INTO olala3w_online_daily VALUES('519','2016-12-04','248');
INSERT INTO olala3w_online_daily VALUES('520','2016-12-05','99');
INSERT INTO olala3w_online_daily VALUES('521','2016-12-06','406');
INSERT INTO olala3w_online_daily VALUES('522','2016-12-07','508');
INSERT INTO olala3w_online_daily VALUES('523','2016-12-08','343');
INSERT INTO olala3w_online_daily VALUES('524','2016-12-09','452');
INSERT INTO olala3w_online_daily VALUES('525','2016-12-10','356');
INSERT INTO olala3w_online_daily VALUES('526','2016-12-11','415');
INSERT INTO olala3w_online_daily VALUES('527','2016-12-12','405');
INSERT INTO olala3w_online_daily VALUES('528','2016-12-13','260');
INSERT INTO olala3w_online_daily VALUES('529','2016-12-14','328');
INSERT INTO olala3w_online_daily VALUES('530','2016-12-15','697');
INSERT INTO olala3w_online_daily VALUES('531','2016-12-16','506');
INSERT INTO olala3w_online_daily VALUES('532','2016-12-17','388');
INSERT INTO olala3w_online_daily VALUES('533','2016-12-18','289');
INSERT INTO olala3w_online_daily VALUES('534','2016-12-19','312');
INSERT INTO olala3w_online_daily VALUES('535','2016-12-20','345');
INSERT INTO olala3w_online_daily VALUES('536','2016-12-21','349');
INSERT INTO olala3w_online_daily VALUES('537','2016-12-22','228');
INSERT INTO olala3w_online_daily VALUES('538','2016-12-23','374');
INSERT INTO olala3w_online_daily VALUES('539','2016-12-24','270');
INSERT INTO olala3w_online_daily VALUES('540','2016-12-25','201');
INSERT INTO olala3w_online_daily VALUES('541','2016-12-26','163');
INSERT INTO olala3w_online_daily VALUES('542','2016-12-27','178');
INSERT INTO olala3w_online_daily VALUES('543','2016-12-28','204');
INSERT INTO olala3w_online_daily VALUES('544','2016-12-29','244');
INSERT INTO olala3w_online_daily VALUES('545','2016-12-30','291');
INSERT INTO olala3w_online_daily VALUES('546','2016-12-31','535');
INSERT INTO olala3w_online_daily VALUES('547','2017-01-01','432');
INSERT INTO olala3w_online_daily VALUES('548','2017-01-02','383');
INSERT INTO olala3w_online_daily VALUES('549','2017-01-03','456');
INSERT INTO olala3w_online_daily VALUES('550','2017-01-04','324');
INSERT INTO olala3w_online_daily VALUES('551','2017-01-05','269');
INSERT INTO olala3w_online_daily VALUES('552','2017-01-06','117');
INSERT INTO olala3w_online_daily VALUES('553','2017-01-07','211');
INSERT INTO olala3w_online_daily VALUES('554','2017-01-08','282');
INSERT INTO olala3w_online_daily VALUES('555','2017-01-09','259');
INSERT INTO olala3w_online_daily VALUES('556','2017-01-10','270');
INSERT INTO olala3w_online_daily VALUES('557','2017-01-11','287');
INSERT INTO olala3w_online_daily VALUES('558','2017-01-12','287');
INSERT INTO olala3w_online_daily VALUES('559','2017-01-13','310');
INSERT INTO olala3w_online_daily VALUES('560','2017-01-14','96');
INSERT INTO olala3w_online_daily VALUES('561','2017-01-15','138');
INSERT INTO olala3w_online_daily VALUES('562','2017-01-16','173');
INSERT INTO olala3w_online_daily VALUES('563','2017-01-17','120');
INSERT INTO olala3w_online_daily VALUES('564','2017-01-18','206');
INSERT INTO olala3w_online_daily VALUES('565','2017-01-19','179');
INSERT INTO olala3w_online_daily VALUES('566','2017-01-20','136');
INSERT INTO olala3w_online_daily VALUES('567','2017-01-21','152');
INSERT INTO olala3w_online_daily VALUES('568','2017-01-22','257');
INSERT INTO olala3w_online_daily VALUES('569','2017-01-23','206');
INSERT INTO olala3w_online_daily VALUES('570','2017-01-24','226');
INSERT INTO olala3w_online_daily VALUES('571','2017-01-25','291');
INSERT INTO olala3w_online_daily VALUES('572','2017-01-26','154');
INSERT INTO olala3w_online_daily VALUES('573','2017-01-27','64');
INSERT INTO olala3w_online_daily VALUES('574','2017-01-28','118');
INSERT INTO olala3w_online_daily VALUES('575','2017-01-29','61');
INSERT INTO olala3w_online_daily VALUES('576','2017-01-30','89');
INSERT INTO olala3w_online_daily VALUES('577','2017-01-31','121');
INSERT INTO olala3w_online_daily VALUES('578','2017-02-01','98');
INSERT INTO olala3w_online_daily VALUES('579','2017-02-02','229');
INSERT INTO olala3w_online_daily VALUES('580','2017-02-03','310');
INSERT INTO olala3w_online_daily VALUES('581','2017-02-04','219');
INSERT INTO olala3w_online_daily VALUES('582','2017-02-05','254');
INSERT INTO olala3w_online_daily VALUES('583','2017-02-06','348');
INSERT INTO olala3w_online_daily VALUES('584','2017-02-07','279');
INSERT INTO olala3w_online_daily VALUES('585','2017-02-08','249');
INSERT INTO olala3w_online_daily VALUES('586','2017-02-09','215');
INSERT INTO olala3w_online_daily VALUES('587','2017-02-10','155');
INSERT INTO olala3w_online_daily VALUES('588','2017-02-11','140');
INSERT INTO olala3w_online_daily VALUES('589','2017-02-12','120');
INSERT INTO olala3w_online_daily VALUES('590','2017-02-13','154');
INSERT INTO olala3w_online_daily VALUES('591','2017-02-14','327');
INSERT INTO olala3w_online_daily VALUES('592','2017-02-15','314');
INSERT INTO olala3w_online_daily VALUES('593','2017-02-16','292');
INSERT INTO olala3w_online_daily VALUES('594','2017-02-17','183');
INSERT INTO olala3w_online_daily VALUES('595','2017-02-18','276');
INSERT INTO olala3w_online_daily VALUES('596','2017-02-19','211');
INSERT INTO olala3w_online_daily VALUES('597','2017-02-20','247');
INSERT INTO olala3w_online_daily VALUES('598','2017-02-21','141');
INSERT INTO olala3w_online_daily VALUES('599','2017-02-22','138');
INSERT INTO olala3w_online_daily VALUES('600','2017-02-23','166');
INSERT INTO olala3w_online_daily VALUES('601','2017-02-24','100');
INSERT INTO olala3w_online_daily VALUES('602','2017-02-25','175');
INSERT INTO olala3w_online_daily VALUES('603','2017-02-26','163');
INSERT INTO olala3w_online_daily VALUES('604','2017-02-27','6');
INSERT INTO olala3w_online_daily VALUES('605','2017-02-28','1');
INSERT INTO olala3w_online_daily VALUES('606','2017-03-01','3');
INSERT INTO olala3w_online_daily VALUES('607','2017-03-05','6');
INSERT INTO olala3w_online_daily VALUES('608','2017-03-06','1');
INSERT INTO olala3w_online_daily VALUES('609','2017-03-07','4');
INSERT INTO olala3w_online_daily VALUES('610','2017-03-08','97');
INSERT INTO olala3w_online_daily VALUES('611','2017-03-09','6');
INSERT INTO olala3w_online_daily VALUES('612','2017-03-10','1');
INSERT INTO olala3w_online_daily VALUES('613','2017-03-11','1');
INSERT INTO olala3w_online_daily VALUES('614','2017-03-11','1');
INSERT INTO olala3w_online_daily VALUES('615','2017-03-13','2');
INSERT INTO olala3w_online_daily VALUES('616','2017-03-14','2');
INSERT INTO olala3w_online_daily VALUES('617','2017-03-15','3');
INSERT INTO olala3w_online_daily VALUES('618','2017-03-20','3');
INSERT INTO olala3w_online_daily VALUES('619','2017-03-21','2');
INSERT INTO olala3w_online_daily VALUES('620','2017-04-16','1');
INSERT INTO olala3w_online_daily VALUES('621','2017-04-17','5');
INSERT INTO olala3w_online_daily VALUES('622','2017-04-21','3');
INSERT INTO olala3w_online_daily VALUES('623','2017-04-22','1');
INSERT INTO olala3w_online_daily VALUES('624','2017-04-26','1');
INSERT INTO olala3w_online_daily VALUES('625','2017-04-28','6');
INSERT INTO olala3w_online_daily VALUES('626','2017-04-29','3');
INSERT INTO olala3w_online_daily VALUES('627','2017-05-03','4');
INSERT INTO olala3w_online_daily VALUES('628','2017-05-04','2');
INSERT INTO olala3w_online_daily VALUES('629','2017-05-05','7');
INSERT INTO olala3w_online_daily VALUES('630','2017-05-07','9');
INSERT INTO olala3w_online_daily VALUES('631','2017-05-08','1');
INSERT INTO olala3w_online_daily VALUES('632','2017-05-09','6');
INSERT INTO olala3w_online_daily VALUES('633','2017-05-10','6');
INSERT INTO olala3w_online_daily VALUES('634','2017-05-12','1');
INSERT INTO olala3w_online_daily VALUES('635','2017-05-16','2');
INSERT INTO olala3w_online_daily VALUES('636','2017-05-17','11');
INSERT INTO olala3w_online_daily VALUES('637','2017-05-18','30');
INSERT INTO olala3w_online_daily VALUES('638','2017-05-19','10');
INSERT INTO olala3w_online_daily VALUES('639','2017-05-20','8');
INSERT INTO olala3w_online_daily VALUES('640','2017-05-21','20');
INSERT INTO olala3w_online_daily VALUES('641','2017-05-22','3');
INSERT INTO olala3w_online_daily VALUES('642','2017-05-23','3');
INSERT INTO olala3w_online_daily VALUES('643','2017-05-29','1');
INSERT INTO olala3w_online_daily VALUES('644','2017-05-30','2');
INSERT INTO olala3w_online_daily VALUES('645','2017-05-31','3');
INSERT INTO olala3w_online_daily VALUES('646','2017-06-01','1');
INSERT INTO olala3w_online_daily VALUES('647','2017-06-03','1');
INSERT INTO olala3w_online_daily VALUES('648','2017-06-07','1');
INSERT INTO olala3w_online_daily VALUES('649','2017-06-08','3');
INSERT INTO olala3w_online_daily VALUES('650','2017-06-09','6');
INSERT INTO olala3w_online_daily VALUES('651','2017-06-11','1');
INSERT INTO olala3w_online_daily VALUES('652','2017-06-12','6');
INSERT INTO olala3w_online_daily VALUES('653','2017-06-13','16');
INSERT INTO olala3w_online_daily VALUES('654','2017-06-14','1');
INSERT INTO olala3w_online_daily VALUES('655','2017-06-15','2');
INSERT INTO olala3w_online_daily VALUES('656','2017-06-16','1');
INSERT INTO olala3w_online_daily VALUES('657','2017-06-17','2');
INSERT INTO olala3w_online_daily VALUES('658','2017-06-18','5');
INSERT INTO olala3w_online_daily VALUES('659','2017-06-21','1');
INSERT INTO olala3w_online_daily VALUES('660','2017-06-22','1');
INSERT INTO olala3w_online_daily VALUES('661','2017-06-23','2');
INSERT INTO olala3w_online_daily VALUES('662','2017-06-24','1');
INSERT INTO olala3w_online_daily VALUES('663','2017-06-26','4');
INSERT INTO olala3w_online_daily VALUES('664','2017-06-27','12');
INSERT INTO olala3w_online_daily VALUES('665','2017-06-28','25');
INSERT INTO olala3w_online_daily VALUES('666','2017-06-29','36');
INSERT INTO olala3w_online_daily VALUES('667','2017-06-30','50');
INSERT INTO olala3w_online_daily VALUES('668','2017-07-01','46');
INSERT INTO olala3w_online_daily VALUES('669','2017-07-02','55');
INSERT INTO olala3w_online_daily VALUES('670','2017-07-03','83');
INSERT INTO olala3w_online_daily VALUES('671','2017-07-04','60');
INSERT INTO olala3w_online_daily VALUES('672','2017-07-05','3');
INSERT INTO olala3w_online_daily VALUES('673','2017-07-06','10');
INSERT INTO olala3w_online_daily VALUES('674','2017-07-07','1');
INSERT INTO olala3w_online_daily VALUES('675','2017-07-09','1');
INSERT INTO olala3w_online_daily VALUES('676','2017-07-11','12');
INSERT INTO olala3w_online_daily VALUES('677','2017-07-12','8');
INSERT INTO olala3w_online_daily VALUES('678','2017-07-13','3');
INSERT INTO olala3w_online_daily VALUES('679','2017-07-17','2');
INSERT INTO olala3w_online_daily VALUES('680','2017-07-18','1');
INSERT INTO olala3w_online_daily VALUES('681','2017-07-21','1');
INSERT INTO olala3w_online_daily VALUES('682','2017-07-28','1');
INSERT INTO olala3w_online_daily VALUES('683','2017-08-04','1');
INSERT INTO olala3w_online_daily VALUES('684','2017-08-05','5');
INSERT INTO olala3w_online_daily VALUES('685','2017-08-06','2');
INSERT INTO olala3w_online_daily VALUES('686','2017-08-07','3');
INSERT INTO olala3w_online_daily VALUES('687','2017-08-08','2');
INSERT INTO olala3w_online_daily VALUES('688','2017-08-09','1');
INSERT INTO olala3w_online_daily VALUES('689','2017-08-10','3');
INSERT INTO olala3w_online_daily VALUES('690','2017-08-11','1');
INSERT INTO olala3w_online_daily VALUES('691','2017-08-12','1');
INSERT INTO olala3w_online_daily VALUES('692','2017-08-13','1');
INSERT INTO olala3w_online_daily VALUES('693','2017-11-27','1');
INSERT INTO olala3w_online_daily VALUES('694','2017-11-29','4');
INSERT INTO olala3w_online_daily VALUES('695','2017-11-30','5');
INSERT INTO olala3w_online_daily VALUES('696','2017-12-01','5');
INSERT INTO olala3w_online_daily VALUES('697','2017-12-02','4');
INSERT INTO olala3w_online_daily VALUES('698','2017-12-03','4');
INSERT INTO olala3w_online_daily VALUES('699','2017-12-04','4');
INSERT INTO olala3w_online_daily VALUES('700','2017-12-05','2');
INSERT INTO olala3w_online_daily VALUES('701','2017-12-06','3');
INSERT INTO olala3w_online_daily VALUES('702','2017-12-07','1');
INSERT INTO olala3w_online_daily VALUES('703','2017-12-08','2');
INSERT INTO olala3w_online_daily VALUES('704','2017-12-09','3');
INSERT INTO olala3w_online_daily VALUES('705','2017-12-13','1');
INSERT INTO olala3w_online_daily VALUES('706','2017-12-16','2');
INSERT INTO olala3w_online_daily VALUES('707','2017-12-17','1');
INSERT INTO olala3w_online_daily VALUES('708','2017-12-18','5');
INSERT INTO olala3w_online_daily VALUES('709','2017-12-19','6');
INSERT INTO olala3w_online_daily VALUES('710','2017-12-20','6');
INSERT INTO olala3w_online_daily VALUES('711','2017-12-21','1');
INSERT INTO olala3w_online_daily VALUES('712','2017-12-22','1');
INSERT INTO olala3w_online_daily VALUES('713','2017-12-24','4');
INSERT INTO olala3w_online_daily VALUES('714','2017-12-25','3');
INSERT INTO olala3w_online_daily VALUES('715','2017-12-27','2');
INSERT INTO olala3w_online_daily VALUES('716','2017-12-28','1');
INSERT INTO olala3w_online_daily VALUES('717','2017-12-30','5');
INSERT INTO olala3w_online_daily VALUES('718','2017-12-31','1');
INSERT INTO olala3w_online_daily VALUES('719','2018-01-01','3');

-- --------------------------------------------------------

CREATE TABLE `olala3w_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `ip` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL DEFAULT 'fa-shopping-cart',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_others` (
  `others_id` int(11) NOT NULL AUTO_INCREMENT,
  `others_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `p_from` bigint(20) NOT NULL DEFAULT '0',
  `p_to` bigint(20) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`others_id`)
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_others VALUES('131','3','Hải Châu','hai-chau','0','0','1','1','0','1495043231','1495043231','1');
INSERT INTO olala3w_others VALUES('132','3','Thanh Khê','thanh-khe','0','0','2','1','0','1495043240','1495043240','1');
INSERT INTO olala3w_others VALUES('133','3','Liên Chiểu','lien-chieu','0','0','3','1','0','1495043251','1495043251','1');
INSERT INTO olala3w_others VALUES('134','3','Cẩm Lệ','cam-le','0','0','4','1','0','1495043259','1495043259','1');
INSERT INTO olala3w_others VALUES('135','3','Sơn Trà','son-tra','0','0','5','1','0','1495043267','1495043267','1');
INSERT INTO olala3w_others VALUES('136','3','Ngũ Hành Sơn','ngu-hanh-son','0','0','6','1','0','1495043278','1495043278','1');
INSERT INTO olala3w_others VALUES('137','3','Hòa Vang','hoa-vang','0','0','7','1','0','1495043293','1495043293','1');
INSERT INTO olala3w_others VALUES('138','3','Hoàng Sa','hoang-sa','0','0','8','1','0','1495043633','1495043633','1');
INSERT INTO olala3w_others VALUES('139','4','Tam Kỳ','tam-ky','0','0','1','1','0','1495043672','1495043672','1');
INSERT INTO olala3w_others VALUES('140','4','Hội An','hoi-an','0','0','2','1','0','1495043679','1495043679','1');
INSERT INTO olala3w_others VALUES('141','4','Tây Giang','tay-giang','0','0','3','1','0','1495043686','1495043686','1');
INSERT INTO olala3w_others VALUES('142','4','Phú Ninh','phu-ninh','0','0','4','1','0','1495043731','1495043731','1');
INSERT INTO olala3w_others VALUES('143','4','Đại Lộc','dai-loc','0','0','5','1','0','1495043737','1495043737','1');
INSERT INTO olala3w_others VALUES('144','4','Nam Giang','nam-giang','0','0','6','1','0','1495043743','1495043743','1');
INSERT INTO olala3w_others VALUES('145','4','Đông Giang','dong-giang','0','0','7','1','0','1495043787','1495043835','1');
INSERT INTO olala3w_others VALUES('146','4','Nông Sơn','nong-son','0','0','8','1','0','1495043848','1495043848','1');
INSERT INTO olala3w_others VALUES('147','4','Hiệp Đức','hiep-duc','0','0','9','1','0','1495043854','1495043854','1');
INSERT INTO olala3w_others VALUES('148','4','Quế Sơn','que-son','0','0','10','1','0','1495043860','1495043860','1');
INSERT INTO olala3w_others VALUES('149','4','Tiên Phước','tien-phuoc','0','0','11','1','0','1495043869','1495043869','1');
INSERT INTO olala3w_others VALUES('150','4','Phước Sơn','phuoc-son','0','0','12','1','0','1495043876','1495043876','1');
INSERT INTO olala3w_others VALUES('151','4','Núi Thành','nui-thanh','0','0','13','1','0','1495043916','1495043916','1');
INSERT INTO olala3w_others VALUES('152','4','Nam Trà My','nam-tra-my','0','0','14','1','0','1495043925','1495043925','1');
INSERT INTO olala3w_others VALUES('153','4','Điện Bàn','dien-ban','0','0','15','1','0','1495043934','1495043934','1');
INSERT INTO olala3w_others VALUES('154','4','Duy Xuyên','duy-xuyen','0','0','16','1','0','1495043942','1495043942','1');
INSERT INTO olala3w_others VALUES('155','4','Thăng Bình','thang-binh','0','0','17','1','0','1495043951','1495043951','1');
INSERT INTO olala3w_others VALUES('156','4','Bắc Trà My','bac-tra-my','0','0','18','1','0','1495043958','1495043958','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_others_menu` (
  `others_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `plus` varchar(255) NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`others_menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_others_menu VALUES('3','95','Đà Nẵng','da-nang','','0','1','1','0','1493371980','1494961453','1');
INSERT INTO olala3w_others_menu VALUES('4','95','Quảng Nam','quang-nam','','0','2','1','0','1493371987','1494961457','1');
INSERT INTO olala3w_others_menu VALUES('5','95','Quảng Ngãi','quang-ngai','','0','3','1','0','1493371994','1494961461','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_page` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `content` longtext NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`page_id`)
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_page VALUES('27','copyright','Copyright','','<p>© Copyright 2017 S Home,<br />\r\nAll Rights Reserved.</p>\r\n','1','1','1513527026','25');

-- --------------------------------------------------------

CREATE TABLE `olala3w_prjname` (
  `prjname_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`prjname_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_menu_id` int(11) NOT NULL,
  `owner` int(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `upload_id` bigint(20) NOT NULL DEFAULT '0',
  `acreage` double NOT NULL DEFAULT '0',
  `price` float NOT NULL DEFAULT '0',
  `price_unit` varchar(255) NOT NULL,
  `direction` varchar(255) NOT NULL,
  `direction_2` varchar(255) NOT NULL,
  `road` varchar(255) NOT NULL,
  `road_2` varchar(255) NOT NULL,
  `bedroom` int(11) NOT NULL DEFAULT '0',
  `bathroom` int(11) NOT NULL DEFAULT '0',
  `city` varchar(255) NOT NULL,
  `city_2` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `district_2` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `type_2` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `content` text CHARACTER SET utf8mb4 NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `youtube_img` varchar(255) NOT NULL DEFAULT 'no',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `pin` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=664 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_product_menu` (
  `product_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `plus` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=254 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_project` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `content` longtext NOT NULL,
  `upload_id` bigint(20) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`project_id`)
) ENGINE=MyISAM AUTO_INCREMENT=206 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_project_menu` (
  `project_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `comment` text NOT NULL,
  `project_type` int(11) NOT NULL DEFAULT '0',
  `price_max` bigint(20) NOT NULL DEFAULT '0',
  `price_min` bigint(20) NOT NULL DEFAULT '0',
  `legal` int(1) NOT NULL DEFAULT '0',
  `location` int(11) NOT NULL DEFAULT '0',
  `geo_radius` int(11) NOT NULL DEFAULT '0',
  `project_use` varchar(255) NOT NULL,
  `project_hot` varchar(255) NOT NULL,
  `project_involve` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`project_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=217 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_register_email` (
  `register_email_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`register_email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_register_try` (
  `register_try_id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL DEFAULT 'no-name',
  `phone` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `note` text NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`register_try_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_road` (
  `road_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`road_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_share` (
  `share_id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `session` varchar(255) NOT NULL,
  `count` bigint(20) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`share_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_share VALUES('15','915','Tô Thái Huy','0974779085','killlllme@gmail.com','1e161bb14eb5e2af1394b954c9a6f1bc','11','1513784557','1513779767');
INSERT INTO olala3w_share VALUES('18','895','Thái Huy','0905779085','huyto.qng@gmail.com','bd5add404333f2b7cce53a75ca1fb1ef','4','1514617549','1514621167');
INSERT INTO olala3w_share VALUES('19','895','Huy Tô','0905779085','killlllme@gmail.com','9e3f95c855f9bde7c8a0a793f2765b57','4','1514618514','1514618523');

-- --------------------------------------------------------

CREATE TABLE `olala3w_street` (
  `street_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`street_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_tags` (
  `tags_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `count` bigint(20) NOT NULL DEFAULT '0',
  `click` bigint(20) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tags_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO olala3w_tags VALUES('7','Kiến trúc','kien-truc','5','1','1513669122','1513790541','1');
INSERT INTO olala3w_tags VALUES('8','Nhà ở','nha-o','10','2','1513669122','1513790546','1');
INSERT INTO olala3w_tags VALUES('10','Sài Gòn','sai-gon','2','0','1513669141','1513669141','1');
INSERT INTO olala3w_tags VALUES('11','Đà Nẵng','da-nang','2','0','1513669163','1513669163','1');
INSERT INTO olala3w_tags VALUES('12','Ý tưởng','y-tuong','1','0','1513670256','1513670256','1');
INSERT INTO olala3w_tags VALUES('13','Toà nhà','toa-nha','1','0','1513670256','1513670256','1');
INSERT INTO olala3w_tags VALUES('15','Nội thất','noi-that','4','0','1513670538','1513670538','1');
INSERT INTO olala3w_tags VALUES('16','Hà Nội','ha-noi','1','0','1513670539','1513670539','1');
INSERT INTO olala3w_tags VALUES('17','Tin tức','tin-tuc','3','0','1513670686','1513670686','1');
INSERT INTO olala3w_tags VALUES('18','Thông tin thị trường','thong-tin-thi-truong','2','0','1513670687','1513670687','1');
INSERT INTO olala3w_tags VALUES('19','Nhật Bản','nhat-ban','1','0','1513670687','1513670687','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_tour` (
  `tour_id` int(11) NOT NULL AUTO_INCREMENT,
  `tour_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `tour_keys` varchar(255) NOT NULL,
  `price` bigint(15) NOT NULL DEFAULT '0',
  `date_schedule` varchar(255) NOT NULL,
  `date_departure` int(11) NOT NULL DEFAULT '0',
  `means` varchar(255) NOT NULL,
  `tour_type` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `sale` int(3) NOT NULL DEFAULT '0',
  `schedule` text NOT NULL,
  `price_list_service` text NOT NULL,
  `upload_id` bigint(20) NOT NULL,
  `maps` text NOT NULL,
  `video` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `pin` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tour_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_tour_menu` (
  `tour_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tour_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=157 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_uploads_tmp` (
  `upload_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` int(1) NOT NULL DEFAULT '0',
  `list_img` text NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`upload_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1941 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_uploads_tmp VALUES('1606','0','','1494148567');
INSERT INTO olala3w_uploads_tmp VALUES('1607','0','','1494148608');
INSERT INTO olala3w_uploads_tmp VALUES('1608','0','','1494148724');
INSERT INTO olala3w_uploads_tmp VALUES('1628','0','','1494522106');
INSERT INTO olala3w_uploads_tmp VALUES('1619','1','','1494180762');
INSERT INTO olala3w_uploads_tmp VALUES('1622','0','','1494183294');
INSERT INTO olala3w_uploads_tmp VALUES('1616','0','','1494180652');
INSERT INTO olala3w_uploads_tmp VALUES('1627','0','','1494217625');
INSERT INTO olala3w_uploads_tmp VALUES('1629','0','','1494953260');
INSERT INTO olala3w_uploads_tmp VALUES('1630','0','','1494955327');
INSERT INTO olala3w_uploads_tmp VALUES('1631','0','','1494956909');
INSERT INTO olala3w_uploads_tmp VALUES('1632','0','','1494956952');
INSERT INTO olala3w_uploads_tmp VALUES('1633','0','','1494957143');
INSERT INTO olala3w_uploads_tmp VALUES('1634','0','','1494957148');
INSERT INTO olala3w_uploads_tmp VALUES('1635','0','','1494957283');
INSERT INTO olala3w_uploads_tmp VALUES('1636','0','','1494957291');
INSERT INTO olala3w_uploads_tmp VALUES('1637','0','','1494957477');
INSERT INTO olala3w_uploads_tmp VALUES('1638','0','','1494957571');
INSERT INTO olala3w_uploads_tmp VALUES('1639','0','','1494957620');
INSERT INTO olala3w_uploads_tmp VALUES('1640','0','','1494957740');
INSERT INTO olala3w_uploads_tmp VALUES('1641','0','','1494957784');
INSERT INTO olala3w_uploads_tmp VALUES('1642','0','','1494957897');
INSERT INTO olala3w_uploads_tmp VALUES('1643','0','','1494957911');
INSERT INTO olala3w_uploads_tmp VALUES('1644','0','','1494957928');
INSERT INTO olala3w_uploads_tmp VALUES('1645','0','','1494957938');
INSERT INTO olala3w_uploads_tmp VALUES('1646','0','','1494957963');
INSERT INTO olala3w_uploads_tmp VALUES('1647','0','','1494958319');
INSERT INTO olala3w_uploads_tmp VALUES('1648','0','','1494958338');
INSERT INTO olala3w_uploads_tmp VALUES('1649','0','','1494958380');
INSERT INTO olala3w_uploads_tmp VALUES('1650','0','','1494964431');
INSERT INTO olala3w_uploads_tmp VALUES('1651','0','','1494964594');
INSERT INTO olala3w_uploads_tmp VALUES('1652','0','','1494964628');
INSERT INTO olala3w_uploads_tmp VALUES('1653','0','','1494964706');
INSERT INTO olala3w_uploads_tmp VALUES('1654','0','','1494964720');
INSERT INTO olala3w_uploads_tmp VALUES('1655','0','','1494964728');
INSERT INTO olala3w_uploads_tmp VALUES('1656','0','','1494965079');
INSERT INTO olala3w_uploads_tmp VALUES('1657','0','','1494965086');
INSERT INTO olala3w_uploads_tmp VALUES('1658','0','','1494965100');
INSERT INTO olala3w_uploads_tmp VALUES('1659','0','','1494965108');
INSERT INTO olala3w_uploads_tmp VALUES('1660','0','','1494965195');
INSERT INTO olala3w_uploads_tmp VALUES('1661','0','','1494965197');
INSERT INTO olala3w_uploads_tmp VALUES('1662','0','','1494965321');
INSERT INTO olala3w_uploads_tmp VALUES('1663','0','','1494965622');
INSERT INTO olala3w_uploads_tmp VALUES('1664','0','','1494965634');
INSERT INTO olala3w_uploads_tmp VALUES('1665','0','','1494965702');
INSERT INTO olala3w_uploads_tmp VALUES('1666','0','','1494965808');
INSERT INTO olala3w_uploads_tmp VALUES('1667','0','','1494965898');
INSERT INTO olala3w_uploads_tmp VALUES('1668','0','','1494965988');
INSERT INTO olala3w_uploads_tmp VALUES('1669','0','','1495042897');
INSERT INTO olala3w_uploads_tmp VALUES('1670','0','','1495042931');
INSERT INTO olala3w_uploads_tmp VALUES('1671','0','','1495042992');
INSERT INTO olala3w_uploads_tmp VALUES('1672','0','','1495043043');
INSERT INTO olala3w_uploads_tmp VALUES('1673','0','','1495043080');
INSERT INTO olala3w_uploads_tmp VALUES('1674','0','','1495043121');
INSERT INTO olala3w_uploads_tmp VALUES('1675','0','','1495043181');
INSERT INTO olala3w_uploads_tmp VALUES('1676','0','','1495043969');
INSERT INTO olala3w_uploads_tmp VALUES('1677','0','','1495071652');
INSERT INTO olala3w_uploads_tmp VALUES('1678','0','','1495073071');
INSERT INTO olala3w_uploads_tmp VALUES('1679','0','','1495077827');
INSERT INTO olala3w_uploads_tmp VALUES('1680','0','','1495077935');
INSERT INTO olala3w_uploads_tmp VALUES('1681','0','','1495077944');
INSERT INTO olala3w_uploads_tmp VALUES('1682','0','','1495078243');
INSERT INTO olala3w_uploads_tmp VALUES('1683','0','','1495078255');
INSERT INTO olala3w_uploads_tmp VALUES('1684','0','','1495080039');
INSERT INTO olala3w_uploads_tmp VALUES('1685','0','','1495080041');
INSERT INTO olala3w_uploads_tmp VALUES('1686','0','','1495080128');
INSERT INTO olala3w_uploads_tmp VALUES('1687','0','','1495080264');
INSERT INTO olala3w_uploads_tmp VALUES('1688','0','','1495081141');
INSERT INTO olala3w_uploads_tmp VALUES('1689','0','','1495081156');
INSERT INTO olala3w_uploads_tmp VALUES('1690','0','','1495081196');
INSERT INTO olala3w_uploads_tmp VALUES('1691','0','','1495081212');
INSERT INTO olala3w_uploads_tmp VALUES('1692','0','','1495081253');
INSERT INTO olala3w_uploads_tmp VALUES('1693','0','','1495081273');
INSERT INTO olala3w_uploads_tmp VALUES('1694','0','','1495081338');
INSERT INTO olala3w_uploads_tmp VALUES('1695','0','','1495081368');
INSERT INTO olala3w_uploads_tmp VALUES('1696','0','','1495081388');
INSERT INTO olala3w_uploads_tmp VALUES('1697','0','','1495081414');
INSERT INTO olala3w_uploads_tmp VALUES('1698','0','','1495081426');
INSERT INTO olala3w_uploads_tmp VALUES('1699','0','','1495082018');
INSERT INTO olala3w_uploads_tmp VALUES('1700','0','','1495082099');
INSERT INTO olala3w_uploads_tmp VALUES('1701','0','','1495082263');
INSERT INTO olala3w_uploads_tmp VALUES('1702','0','','1495090079');
INSERT INTO olala3w_uploads_tmp VALUES('1703','0','','1495090087');
INSERT INTO olala3w_uploads_tmp VALUES('1704','0','','1495090095');
INSERT INTO olala3w_uploads_tmp VALUES('1705','0','','1495090509');
INSERT INTO olala3w_uploads_tmp VALUES('1706','0','','1495091563');
INSERT INTO olala3w_uploads_tmp VALUES('1707','0','','1495091622');
INSERT INTO olala3w_uploads_tmp VALUES('1708','0','','1495091681');
INSERT INTO olala3w_uploads_tmp VALUES('1709','0','','1495091842');
INSERT INTO olala3w_uploads_tmp VALUES('1710','0','','1495092033');
INSERT INTO olala3w_uploads_tmp VALUES('1711','0','','1495092064');
INSERT INTO olala3w_uploads_tmp VALUES('1712','0','','1495092066');
INSERT INTO olala3w_uploads_tmp VALUES('1713','0','','1495092142');
INSERT INTO olala3w_uploads_tmp VALUES('1714','0','','1495092189');
INSERT INTO olala3w_uploads_tmp VALUES('1715','0','','1495092205');
INSERT INTO olala3w_uploads_tmp VALUES('1716','0','','1495092208');
INSERT INTO olala3w_uploads_tmp VALUES('1717','0','','1495092245');
INSERT INTO olala3w_uploads_tmp VALUES('1718','0','','1495092309');
INSERT INTO olala3w_uploads_tmp VALUES('1719','0','','1495092339');
INSERT INTO olala3w_uploads_tmp VALUES('1720','0','','1495092354');
INSERT INTO olala3w_uploads_tmp VALUES('1721','0','','1495092390');
INSERT INTO olala3w_uploads_tmp VALUES('1722','0','','1495092406');
INSERT INTO olala3w_uploads_tmp VALUES('1723','0','','1495092453');
INSERT INTO olala3w_uploads_tmp VALUES('1724','0','','1495092462');
INSERT INTO olala3w_uploads_tmp VALUES('1725','0','','1495092683');
INSERT INTO olala3w_uploads_tmp VALUES('1726','0','','1495092730');
INSERT INTO olala3w_uploads_tmp VALUES('1727','0','','1495092796');
INSERT INTO olala3w_uploads_tmp VALUES('1728','0','','1495092880');
INSERT INTO olala3w_uploads_tmp VALUES('1729','0','','1495093352');
INSERT INTO olala3w_uploads_tmp VALUES('1730','0','','1495093880');
INSERT INTO olala3w_uploads_tmp VALUES('1731','0','','1495094500');
INSERT INTO olala3w_uploads_tmp VALUES('1732','0','','1495094582');
INSERT INTO olala3w_uploads_tmp VALUES('1733','0','','1495094601');
INSERT INTO olala3w_uploads_tmp VALUES('1734','0','','1495094603');
INSERT INTO olala3w_uploads_tmp VALUES('1735','0','','1495094640');
INSERT INTO olala3w_uploads_tmp VALUES('1736','0','','1495094707');
INSERT INTO olala3w_uploads_tmp VALUES('1737','0','','1495094808');
INSERT INTO olala3w_uploads_tmp VALUES('1738','0','','1495094867');
INSERT INTO olala3w_uploads_tmp VALUES('1739','0','','1495094913');
INSERT INTO olala3w_uploads_tmp VALUES('1740','0','','1495095142');
INSERT INTO olala3w_uploads_tmp VALUES('1741','0','','1495095336');
INSERT INTO olala3w_uploads_tmp VALUES('1742','0','','1495096192');
INSERT INTO olala3w_uploads_tmp VALUES('1743','0','','1495097070');
INSERT INTO olala3w_uploads_tmp VALUES('1744','0','','1495097239');
INSERT INTO olala3w_uploads_tmp VALUES('1745','0','','1495097275');
INSERT INTO olala3w_uploads_tmp VALUES('1746','0','','1495097289');
INSERT INTO olala3w_uploads_tmp VALUES('1747','0','','1495098068');
INSERT INTO olala3w_uploads_tmp VALUES('1748','0','','1495098188');
INSERT INTO olala3w_uploads_tmp VALUES('1749','0','','1495098424');
INSERT INTO olala3w_uploads_tmp VALUES('1750','0','','1495098682');
INSERT INTO olala3w_uploads_tmp VALUES('1751','0','','1495102772');
INSERT INTO olala3w_uploads_tmp VALUES('1752','0','','1495103096');
INSERT INTO olala3w_uploads_tmp VALUES('1753','0','','1495103191');
INSERT INTO olala3w_uploads_tmp VALUES('1754','0','','1495103200');
INSERT INTO olala3w_uploads_tmp VALUES('1755','0','','1495103240');
INSERT INTO olala3w_uploads_tmp VALUES('1756','0','','1495126834');
INSERT INTO olala3w_uploads_tmp VALUES('1757','0','','1495126842');
INSERT INTO olala3w_uploads_tmp VALUES('1758','0','','1495179895');
INSERT INTO olala3w_uploads_tmp VALUES('1759','0','','1495186231');
INSERT INTO olala3w_uploads_tmp VALUES('1760','0','','1495204220');
INSERT INTO olala3w_uploads_tmp VALUES('1761','0','','1495214441');
INSERT INTO olala3w_uploads_tmp VALUES('1762','0','','1495214502');
INSERT INTO olala3w_uploads_tmp VALUES('1763','0','','1495214510');
INSERT INTO olala3w_uploads_tmp VALUES('1764','0','','1495214557');
INSERT INTO olala3w_uploads_tmp VALUES('1765','0','','1495214574');
INSERT INTO olala3w_uploads_tmp VALUES('1766','0','','1495214615');
INSERT INTO olala3w_uploads_tmp VALUES('1767','0','','1495214627');
INSERT INTO olala3w_uploads_tmp VALUES('1777','0','','1495222079');
INSERT INTO olala3w_uploads_tmp VALUES('1769','0','','1495218917');
INSERT INTO olala3w_uploads_tmp VALUES('1770','0','','1495218918');
INSERT INTO olala3w_uploads_tmp VALUES('1771','0','','1495218930');
INSERT INTO olala3w_uploads_tmp VALUES('1772','0','','1495219014');
INSERT INTO olala3w_uploads_tmp VALUES('1780','0','','1495222936');
INSERT INTO olala3w_uploads_tmp VALUES('1781','0','','1495225687');
INSERT INTO olala3w_uploads_tmp VALUES('1782','0','','1495225695');
INSERT INTO olala3w_uploads_tmp VALUES('1783','0','','1495225709');
INSERT INTO olala3w_uploads_tmp VALUES('1784','0','','1495225783');
INSERT INTO olala3w_uploads_tmp VALUES('1785','0','','1495225788');
INSERT INTO olala3w_uploads_tmp VALUES('1786','0','','1495225795');
INSERT INTO olala3w_uploads_tmp VALUES('1787','0','','1495225921');
INSERT INTO olala3w_uploads_tmp VALUES('1788','0','','1495225980');
INSERT INTO olala3w_uploads_tmp VALUES('1815','0','','1498926316');
INSERT INTO olala3w_uploads_tmp VALUES('1790','0','','1495226209');
INSERT INTO olala3w_uploads_tmp VALUES('1791','0','','1495226270');
INSERT INTO olala3w_uploads_tmp VALUES('1792','0','','1495226279');
INSERT INTO olala3w_uploads_tmp VALUES('1793','1','','1495295825');
INSERT INTO olala3w_uploads_tmp VALUES('1794','1','','1495295867');
INSERT INTO olala3w_uploads_tmp VALUES('1795','1','','1495295887');
INSERT INTO olala3w_uploads_tmp VALUES('1798','0','1495358188_1798_668c88252cb9e162b36d6713cb174c0d.jpg;1495358191_1798_a0d5434b0d5b08def83572649240c0d0.jpg;1495358193_1798_38a1905ecf631d468fddb233ee51b363.jpg;1495358196_1798_76764969447e3dbec7c38db97a6ad7ac.jpg;1495358198_1798_41556e4e12791ab26815bba9270fb00e.jpg;1495358201_1798_a9b7093b799d6d1af3f0f36140a99b00.jpg;1495358312_1798_4a1f7b9a6eaa938287d515789d6ce165.jpg;1495358597_1798_877678f580798b55d2ba436ed981e43f.jpg;1495358713_1798_98a69e0f2b0f255debde85fec5527457.jpg;1495359221_1798_30b32757c538d89ad60fc821bffaf712.jpg;','1495357896');
INSERT INTO olala3w_uploads_tmp VALUES('1799','0','','1495378192');
INSERT INTO olala3w_uploads_tmp VALUES('1822','0','','1498930039');
INSERT INTO olala3w_uploads_tmp VALUES('1872','0','','1512200462');
INSERT INTO olala3w_uploads_tmp VALUES('1868','0','','1512199995');
INSERT INTO olala3w_uploads_tmp VALUES('1867','0','','1512199992');
INSERT INTO olala3w_uploads_tmp VALUES('1870','0','','1512200004');
INSERT INTO olala3w_uploads_tmp VALUES('1869','0','','1512199997');
INSERT INTO olala3w_uploads_tmp VALUES('1871','0','','1512200459');
INSERT INTO olala3w_uploads_tmp VALUES('1873','0','','1512200480');
INSERT INTO olala3w_uploads_tmp VALUES('1862','0','','1512199394');
INSERT INTO olala3w_uploads_tmp VALUES('1861','0','','1512199378');
INSERT INTO olala3w_uploads_tmp VALUES('1860','0','','1512199283');
INSERT INTO olala3w_uploads_tmp VALUES('1859','0','','1512199258');
INSERT INTO olala3w_uploads_tmp VALUES('1858','0','','1512196492');
INSERT INTO olala3w_uploads_tmp VALUES('1857','0','','1512196489');
INSERT INTO olala3w_uploads_tmp VALUES('1856','0','','1512196235');
INSERT INTO olala3w_uploads_tmp VALUES('1801','0','','1495380859');
INSERT INTO olala3w_uploads_tmp VALUES('1805','0','','1495383166');
INSERT INTO olala3w_uploads_tmp VALUES('1803','0','','1495381092');
INSERT INTO olala3w_uploads_tmp VALUES('1804','0','','1495381176');
INSERT INTO olala3w_uploads_tmp VALUES('1806','0','','1495383327');
INSERT INTO olala3w_uploads_tmp VALUES('1807','0','','1495438809');
INSERT INTO olala3w_uploads_tmp VALUES('1808','0','','1495564220');
INSERT INTO olala3w_uploads_tmp VALUES('1809','0','','1496917138');
INSERT INTO olala3w_uploads_tmp VALUES('1810','0','','1496941270');
INSERT INTO olala3w_uploads_tmp VALUES('1812','0','','1498783037');
INSERT INTO olala3w_uploads_tmp VALUES('1813','0','','1498783213');
INSERT INTO olala3w_uploads_tmp VALUES('1814','0','','1498783548');
INSERT INTO olala3w_uploads_tmp VALUES('1874','0','','1512200572');
INSERT INTO olala3w_uploads_tmp VALUES('1875','0','','1512200591');
INSERT INTO olala3w_uploads_tmp VALUES('1876','0','','1512200603');
INSERT INTO olala3w_uploads_tmp VALUES('1877','0','','1512200625');
INSERT INTO olala3w_uploads_tmp VALUES('1878','0','','1512200962');
INSERT INTO olala3w_uploads_tmp VALUES('1879','0','','1512201090');
INSERT INTO olala3w_uploads_tmp VALUES('1880','0','','1512201162');
INSERT INTO olala3w_uploads_tmp VALUES('1881','0','','1512201165');
INSERT INTO olala3w_uploads_tmp VALUES('1882','1','','1512322090');
INSERT INTO olala3w_uploads_tmp VALUES('1866','0','','1512199983');
INSERT INTO olala3w_uploads_tmp VALUES('1865','0','','1512199903');
INSERT INTO olala3w_uploads_tmp VALUES('1864','0','','1512199424');
INSERT INTO olala3w_uploads_tmp VALUES('1863','0','','1512199422');
INSERT INTO olala3w_uploads_tmp VALUES('1855','0','','1512195909');
INSERT INTO olala3w_uploads_tmp VALUES('1853','1','','1511974722');
INSERT INTO olala3w_uploads_tmp VALUES('1852','1','','1511974697');
INSERT INTO olala3w_uploads_tmp VALUES('1846','0','','1500602267');
INSERT INTO olala3w_uploads_tmp VALUES('1848','0','','1502208452');
INSERT INTO olala3w_uploads_tmp VALUES('1850','0','','1502293558');
INSERT INTO olala3w_uploads_tmp VALUES('1851','0','','1502522062');
INSERT INTO olala3w_uploads_tmp VALUES('1895','0','','1513580979');
INSERT INTO olala3w_uploads_tmp VALUES('1884','0','','1512355126');
INSERT INTO olala3w_uploads_tmp VALUES('1885','1','','1512405485');
INSERT INTO olala3w_uploads_tmp VALUES('1886','1','','1512405582');
INSERT INTO olala3w_uploads_tmp VALUES('1887','1','','1512405912');
INSERT INTO olala3w_uploads_tmp VALUES('1888','1','','1512405977');
INSERT INTO olala3w_uploads_tmp VALUES('1889','1','','1512409955');
INSERT INTO olala3w_uploads_tmp VALUES('1890','1','','1512410007');
INSERT INTO olala3w_uploads_tmp VALUES('1891','1','','1512410578');
INSERT INTO olala3w_uploads_tmp VALUES('1892','1','','1512410620');
INSERT INTO olala3w_uploads_tmp VALUES('1896','0','','1513611478');
INSERT INTO olala3w_uploads_tmp VALUES('1897','0','','1513612543');
INSERT INTO olala3w_uploads_tmp VALUES('1898','0','','1513612561');
INSERT INTO olala3w_uploads_tmp VALUES('1899','0','','1513613547');
INSERT INTO olala3w_uploads_tmp VALUES('1900','0','','1513613624');
INSERT INTO olala3w_uploads_tmp VALUES('1901','0','','1513613659');
INSERT INTO olala3w_uploads_tmp VALUES('1904','0','','1513614302');
INSERT INTO olala3w_uploads_tmp VALUES('1905','0','','1513615488');
INSERT INTO olala3w_uploads_tmp VALUES('1908','1','','1513651677');
INSERT INTO olala3w_uploads_tmp VALUES('1909','1','','1513651747');
INSERT INTO olala3w_uploads_tmp VALUES('1910','1','','1513651900');
INSERT INTO olala3w_uploads_tmp VALUES('1912','1','','1513653595');
INSERT INTO olala3w_uploads_tmp VALUES('1914','0','','1513667575');
INSERT INTO olala3w_uploads_tmp VALUES('1915','0','','1513667630');
INSERT INTO olala3w_uploads_tmp VALUES('1923','0','','1513753446');
INSERT INTO olala3w_uploads_tmp VALUES('1917','0','','1513667813');
INSERT INTO olala3w_uploads_tmp VALUES('1922','0','','1513744161');
INSERT INTO olala3w_uploads_tmp VALUES('1921','0','','1513741762');
INSERT INTO olala3w_uploads_tmp VALUES('1924','0','','1513761677');
INSERT INTO olala3w_uploads_tmp VALUES('1925','0','','1513761807');
INSERT INTO olala3w_uploads_tmp VALUES('1940','0','','1514649365');
INSERT INTO olala3w_uploads_tmp VALUES('1927','0','','1513777098');
INSERT INTO olala3w_uploads_tmp VALUES('1928','0','','1513788910');
INSERT INTO olala3w_uploads_tmp VALUES('1929','0','','1513788912');
INSERT INTO olala3w_uploads_tmp VALUES('1930','0','','1513789012');
INSERT INTO olala3w_uploads_tmp VALUES('1931','0','','1513930085');
INSERT INTO olala3w_uploads_tmp VALUES('1932','0','','1513930095');
INSERT INTO olala3w_uploads_tmp VALUES('1933','0','','1513930419');
INSERT INTO olala3w_uploads_tmp VALUES('1934','0','','1513930437');
INSERT INTO olala3w_uploads_tmp VALUES('1935','0','','1513930488');
INSERT INTO olala3w_uploads_tmp VALUES('1936','0','','1513930504');
INSERT INTO olala3w_uploads_tmp VALUES('1937','0','','1513930650');
INSERT INTO olala3w_uploads_tmp VALUES('1938','0','','1514195304');
INSERT INTO olala3w_uploads_tmp VALUES('1939','0','','1514195323');

-- --------------------------------------------------------

CREATE TABLE `olala3w_vote` (
  `vote_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `session` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `vote` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vote_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

