-- [MySQL -  Database Backup] Created time: 24/04/2018 - 17:24:50

-- Host: localhost
-- Server version: 5.6.20
-- Collation: utf8_general_ci
-- Time zone: SE Asia Standard Time

-- Database: ol_nhaphodanang3


CREATE TABLE `olala_article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `article_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `price` double NOT NULL DEFAULT '0',
  `block` int(11) NOT NULL DEFAULT '0',
  `flat` int(11) NOT NULL DEFAULT '0',
  `open_sale` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `upload_id` bigint(20) NOT NULL DEFAULT '0',
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `youtube_img` varchar(255) NOT NULL DEFAULT 'no',
  `tags` varchar(255) NOT NULL,
  `tags_2` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `pin` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=946 DEFAULT CHARSET=utf8;

INSERT INTO olala_article VALUES('919','458','Bất động sản Sài Gòn thưởng Tết tiền tỷ','bat-dong-san-sai-gon-thuong-tet-tien-ty','','','','bat-dong-san-sai-gon-thuong-tet-tien-ty-1518196015.jpg','','','0','0','0','0','0','2177','Một công ty địa ốc tại Tân Bình, TP HCM vừa công bố thưởng cuối năm cho nhân viên xuất sắc quà và hiện kim 1,3 tỷ đồng.','<p>Phần thưởng này được công bố trong lễ tổng kết năm kinh doanh 2017 của doanh nghiệp, tổ chức vào trung tuần tháng 1/2018. Khoản thưởng Tết Mậu Tuất cho nhân viên xuất sắc gồm có: một ôtô 7 chỗ cùng phiếu tích lũy an sinh để mua nhà, tiền mặt và voucher với tổng giá trị 1,3 tỷ đồng; trong đó ôtô chiếm trên 50% giá trị giải thưởng. Năm 2017 vừa qua, doanh nghiệp đã bàn giao và đưa vào vận hành 2 dự án căn hộ tại TP HCM.</p>\r\n\r\n<p>Trong khi đó, lãnh đạo một công ty tư vấn và môi giới bất động sản có trụ sở tại quận 5, TP HCM tiết lộ với&nbsp;<em>VnExpress</em>, khoản thu nhập cả năm cấp trưởng nhóm sale xuất sắc của doanh nghiệp lên đến trên 2 tỷ đồng. Trong đó, khoản lương hồi tố (được trả bù nhờ bán hàng vượt doanh số quy định) lên đến 15 triệu đồng mỗi tháng. Nếu tính 12 tháng hồi tố lương kèm tháng lương thứ 13 và 14 đạt gần 250 triệu đồng.</p>\r\n\r\n<p>Ngoài ra, công ty còn có khoản thưởng 3% hoa hồng dựa trên tổng doanh số mang về. Chính sách thưởng cho nhóm kinh doanh xuất sắc được phân bổ như sau: trưởng nhóm được hưởng 30% quỹ tiền thưởng, phần còn lại chia đều cho các cá nhân có hiệu suất bán hàng tốt trong năm. \"Cộng tất cả các khoản thưởng và lương hồi tố cuối năm, ước tính cá nhân xuất sắc nhất thừa sức rinh về bạc tỷ\", ông nói.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\" class=\"tcs\">\r\n	<tbody>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled tcs-selected\"><img alt=\"Khá nhiều công ty bất động sản tại TP HCM rục rịch thưởng Tết bạc tỷ. Ảnh: K.H\" data-natural-width=\"500\" data-pwidth=\"500\" data-width=\"500\" src=\"https://i-kinhdoanh.vnecdn.net/2018/01/22/a-tb-dia-oc-thuong-Tet-8740-1516635615.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Khá nhiều công ty bất động sản tại TP HCM rục rịch thưởng Tết bạc tỷ. Ảnh:&nbsp;<em>K.H</em></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Lãnh đạo công ty này cho biết thêm, năm 2016 giám đốc sàn xuất sắc của công ty có khoản thu nhập 1,3 tỷ đồng, nhưng dự kiến năm 2017 có thể tăng đột biến, vọt lên 2-2,2 tỷ đồng, đã bao gồm các khoản thưởng Tết. Năm qua, công ty này bán được 2.800 bất động sản, trong đó 40% là căn hộ giá vừa túi tiền, 60% rổ hàng tiêu thụ được là đất nền và nhà phố. Sản lượng hàng bán được của năm 2017 cao hơn năm trước 1.000 sản phẩm, tăng hơn 50%.</p>\r\n\r\n<p>Doanh nghiệp có hệ thống 6 sàn địa ốc thì 5 sàn đã vượt chỉ tiêu đề ra, toàn công ty có trên 80% nhân viên thuộc diện được hồi tố lương (nhận thêm 8-15 triệu đồng mỗi tháng và bù cho cả năm) nhờ bán hàng đạt chỉ tiêu quy định.</p>\r\n\r\n<p>Riêng một công ty địa ốc có trụ sở tại phố đi bộ Bùi Viện TP HCM tuy bán hàng quy mô vừa và nhỏ cũng đã lên kế hoạch thưởng Tết cho giám đốc sàn xuất sắc bằng xe SH kèm hiện kim, trị giá gần 200 triệu đồng. Ngoài ra, các sàn còn được công ty mẹ (chủ đầu tư) thưởng cho tập thể 500 triệu đồng để nhân viên có quỹ đi du lịch nước ngoài.</p>\r\n\r\n<p>Tổng giám đốc Công ty Việt An Hòa, Trần Khánh Quang cho biết, thưởng Tết ngành địa ốc năm 2017 đạt mốc tiền tỷ là điều dễ hiểu vì trong 12 tháng qua, thị trường đã chứng kiến nhiều cơn sốt đất lan rộng, bất động sản liền thổ đạt thanh khoản cao, biên lợi nhuận ghi nhận ở mức lý tưởng. Bên cạnh đó những doanh nghiệp môi giới phân phối căn hộ bình dân, giá vừa túi tiền đều thắng lớn vì khả năng tiêu thụ hàng ở phân khúc giá rẻ tại Sài Gòn vẫn cực tốt.</p>\r\n\r\n<p>Tuy nhiên, ông Quang đánh giá, mức thưởng Tết tuy ngất ngưởng vươn đến tầm bạc tỷ không phải là hình mẫu đại diện cho toàn thị trường bất động sản. Chỉ có 10-15% những cá nhân và tập thể xuất sắc mới rủng rỉnh tiền thưởng Tết từ bạc trăm đến bạc tỷ đồng, trong đó số người bỏ túi bạc tỷ đếm trên đầu ngón tay. 30-40% nhân viên hoạt động trong ngành này được thưởng ở mức khá tốt, tức có tháng lương 13-14 hoặc 15 kèm hoa hồng. Số đông còn lại của thị trường có thể ăn Tết khiêm tốn hơn vì tiền thưởng chỉ ở mức từ trung bình trở xuống.&nbsp;</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Vũ Lê<br />\r\n(VnExpress.net)</strong></p>\r\n','','no','[]','[]','1','0','0','42','1516677480','1518196015','25');
INSERT INTO olala_article VALUES('918','458','Bất động sản nghỉ dưỡng Đà Lạt phát triển cùng du lịch','bat-dong-san-nghi-duong-da-lat-phat-trien-cung-du-lich','','','','bat-dong-san-nghi-duong-da-lat-phat-trien-cung-du-lich-1518196043.jpg','','','0','0','0','0','0','2176','Cùng sự đẩy mạnh du lịch của thành phố, dự án bất động sản nghỉ dưỡng khai thác lợi thế về vị trí, thiết kế... để tăng sức cạnh tranh.','<p>Vào mùa du lịch cuối năm, Đà Lạt là một trong những địa điểm đón lượng khách ồ ạt của cả nước đổ về. Giá khách sạn, nhà nghỉ tăng vào cuối tuần hay dịp lễ, nhưng dường như vẫn chưa đáp ứng đủ nhu cầu. Dọc tuyến phố trung tâm quanh Hồ Xuân Hương và chợ Đà Lạt, vào mùa lễ hội, không khó để bắt gặp các bảng thông báo hết phòng.</p>\r\n\r\n<p>Sự phát triển mạnh mẽ của ngành du lịch cùng những yếu tố thuận lợi về tự nhiên đã góp phần giúp Đà Lạt thu hút nhà đầu tư trong nhiều lĩnh vực. Nhờ vậy, thị trường nhà đất tại thành phố du lịch này cũng có phần sôi động hơn.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\" class=\"tcs\">\r\n	<tbody>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled tcs-selected\" style=\"text-align: center;\"><img alt=\"polyad\" crossorigin=\"anonymous\" data-natural-width=\"500\" data-pwidth=\"500\" data-width=\"500\" src=\"https://i-kinhdoanh.vnecdn.net/2018/01/22/22-1-201837-3106-1516610918.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Đà Lạt là một trong những điểm hấp dẫn du lịch của cả nước. Ảnh:&nbsp;<em>Phong Vân.</em></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>\"Với nhu cầu lưu trú lớn tại thành phố du lịch, mô hình bất động sản nghỉ dưỡng tại Đà Lạt xuất hiện và phát triển thời gian gần đây dù chưa phải là giải pháp trọn vẹn, nhưng cũng gợi mở một hướng đi cho thành phố\", đại diện công ty Cổ phần Đầu tư Phong Vân cho biết.</p>\r\n\r\n<p>Dự án bất động sản nghỉ dưỡng cũng khai thác những ưu điểm của mình để tạo lợi thế cạnh tranh trong phân khúc này. Đơn cử như The Panorama - Đà Lạt. Sở hữu vị trí đắc địa, nơi giao nhau giữa đường Hoàng Văn Thụ, quốc lộ 20 và cao tốc Liên Khương, sau lưng là đường Phạm Hồng Thái chạy dọc Đà Lạt, dự án có vị trí cửa ngõ, dễ dàng kết nối với các khu vực lân cận.</p>\r\n\r\n<p>Từ dự án, du khách có thể tiếp cận những địa danh nổi tiếng của thành phố như chợ Đà Lạt, dinh Bảo Đại, sân golf Đà Lạt trong khoảng 8 phút di chuyển.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\" class=\"tcs\">\r\n	<tbody>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled\" style=\"text-align: center;\"><img alt=\"polyad\" crossorigin=\"anonymous\" data-natural-width=\"500\" data-pwidth=\"500\" data-width=\"500\" src=\"https://i-kinhdoanh.vnecdn.net/2018/01/22/22-1-201851-7763-1516610918.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Phối cảnh dự án The Panorama - Đà Lạt. Ảnh:&nbsp;<em>Phong Vân.</em></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Tận dụng lợi thế đó, chủ đầu tư dự án đã có ý tưởng độc đáo là thu Đà Lạt vào trong tầm mắt. Dự án với 3 tầng thương mại và 4 tầng căn hộ nghỉ dưỡng được thiết kế theo hình tháp tròn. Điều này giúp các căn hộ bên trong có tầm nhìn lan tỏa 360 độ, quan sát thành phố Đà Lạt từ nhiều góc.</p>\r\n\r\n<p>Với thiết kế mở, cho phép quan sát quan cảnh của núi rừng và các kiến trúc nhấp nhô nép mình bên những hàng thông, từ đây, du khách có thể tận hưởng không khí bình an của buổi sớm mai, hay ngắm hoàng hôn chiều tà, cũng như Đà Lạt lung linh khi màn đêm buông xuống.</p>\r\n\r\n<p>Nổi bật với kiến trúc độc đáo, thiết kế sang trọng theo phong cách Art Nouveau, dự án hướng đến mang lại cảm giác tách biệt, yên tĩnh, thư thái cho người lữ khách khi lưu trú. Nơi đây còn hội tụ các tiện ích cao cấp, đáp ứng nhu cầu cho cuộc sống hiện đại với tiêu chí “nơi thịnh vượng, chốn bình an”.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\" class=\"tcs\">\r\n	<tbody>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled\" style=\"text-align: center;\"><img alt=\"polyad\" data-natural-width=\"500\" data-pwidth=\"500\" data-width=\"500\" src=\"https://i-kinhdoanh.vnecdn.net/2018/01/22/22-1-20182-490473885-4756-1516610918.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Dự án The Panorama - Đà Lạt sở hữu tiện ích cao cấp. Thông tin chi tiết: Hotline ‎090 88888 22.&nbsp;<a href=\"http://www.dalatpanorama.com/\" target=\"_blank\">Website</a>. Ảnh:&nbsp;<em>Phong Vân.</em></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Với chính sách hạn chế các dự án bất động sản ở khu vực trung tâm và sự eo hẹp của quỹ đất thành phố, The Panorama - Đà Lạt có thể coi là một trong những dự án có vị thế trung tâm. \"Điều này là một trong những yếu tố góp phần giúp dự án thu hút đầu tư và hứa hẹn gia tăng giá trị tại thị trường bất động sản nghỉ dưỡng\", đại diện chủ đầu tư cho biết.</p>\r\n\r\n<p>Dự án tọa lạc tại số 37 Trần Hưng Đạo, phường 10, thành phố Đà Lạt với 7 tầng nổi và 2 tầng hầm. 60 căn hộ có diện tích đa dạng 49m2, 78m2, 87 m2, 252m2. Chủ đầu tư dự án là công ty Cổ phần Đầu tư Phong Vân.</p>\r\n\r\n<p>Hiện dự án triển khai tầng cuối cùng là tầng 7. Theo dự kiến, The Panorama - Đà Lạt sẽ hoàn tất và sẵn sàng bàn giao cho khách hàng vào khoảng tháng 9/2018.</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Y Vân<br />\r\n(VnExpress.net)</strong></p>\r\n','','no','[]','[]','1','0','0','5','1516677360','1518196043','25');
INSERT INTO olala_article VALUES('916','428','Trang tư vấn thông tin về các dự án bất động sản Nhà phố Đà Nẵng','trang-tu-van-thong-tin-ve-cac-du-an-bat-dong-san-nha-pho-da-nang','','','','no','','','0','0','0','0','0','2173','Chuyển kênh bất động sản tại Đà Nẵng.','<p>Bài giới thiệu về chúng tôi...</p>\r\n\r\n<div class=\"locationmap\"><iframe __idm_frm__=\"651\" height=\"350px\" src=\"/editor/googlemap.html?x=16.0495093443346&amp;y=108.19043567421875&amp;z=17&amp;img=Bản đồ Google Map...&amp;googlemap=true\" style=\"border: none; max-width:100%;\" width=\"100%\"></iframe></div>\r\n\r\n<p>&nbsp;</p>\r\n','','no','[]','[]','1','0','0','71','1516350240','1519704337','25');
INSERT INTO olala_article VALUES('917','458','90% căn hộ phong cách \'chuẩn Nhật\' đã có chủ','90-can-ho-phong-cach-chuan-nhat-da-co-chu','','','','90-can-ho-phong-cach-chuan-nhat-da-co-chu-1518196074.png','','','0','0','0','0','0','2175','Ascent Lakeside là dự án căn hộ Nhật Bản do Sanyo Homes - công ty cung cấp giải pháp nhà Nhật Bản hợp tác phát triển cùng Tiến Phát Corporation. Mới đây, chương trình \"Trải nghiệm cuộc sống Nhật Bản giữa lòng Sài Gòn\" dành cho khách mua căn hộ Ascent Lakeside được tổ chức tại Trung tâm Hội nghị Adora Premium (TP HCM).','<p>Tại dự kiện, ông Kazuya Anzai - Trưởng đại diện Công ty Sanyo Homes cho biết: \"Chúng tôi đã đồng hành cùng Tiến Phát Corporation từ lúc ý tưởng, lên kế hoạch và thi công hoàn chỉnh. Do đó chất lượng và công nghệ trong&nbsp;từng giai đoạn của dự án&nbsp;mang dấu ấn Nhật Bản\". Ascent Lakeside là dự án đầu tiên của Sanyo Homes tại nước ngoài sau 50 năm hoạt động.</p>\r\n\r\n<p>Đại diện chủ đầu tư cho biết, hơn&nbsp;90% căn hộ Ascent Lakeside đã có chủ.&nbsp;Dự án được nhiều khách hàng quan tâm nhờ vị trí đắc địa tại Khu đô thị&nbsp;Phú Mỹ Hưng, có sức hút với nhà đầu tư nhờ có tiềm năng cho thuê hoặc chuyển nhượng với mức sinh lời cao.&nbsp;</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"2\" cellspacing=\"0\" class=\"tcs\">\r\n	<tbody>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled\" style=\"text-align: center;\"><img alt=\"ASCENT LAKESIDE QUẬN 7 - HƠN 90% CĂN HỘ ĐÃ CÓ CHỦ (Xin edit)\" data-natural-width=\"500\" data-pwidth=\"500\" data-width=\"500\" src=\"https://i-kinhdoanh.vnecdn.net/2018/01/23/Image-207756341-ExtractWord-0-5069-5885-1516669814.png\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Buổi trò chuyện với nhiều khách mời nổi tiếng.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Ngoài trải nghiệm văn hóa, phong cách sống, khách mời còn tham gia vào buổi talkshow Elle chủ đề cuộc sống phong cách Nhật Bản tại TP HCM do&nbsp;Thùy Dương - Trưởng ban biên tập Elle&nbsp;Decoration dẫn chương trình.&nbsp;</p>\r\n\r\n<p>Theo đại diện&nbsp;Tiến Phát Corporation,&nbsp;Ascent Lakeside là một trong những dự án \"Chuẩn Nhật cho nhà Việt\" hội tụ đầy đủ các yếu tố cho một cuộc sống đẳng cấp, hiện đại. Tại đây, cư dân được tận hưởng những tiện ích tiêu chuẩn Nhật như&nbsp;Cabana kết hợp công viên ven sông, khu đọc sách trên hồ, vườn Thượng Uyển, vườn Cha-Niwa, hồ bơi tràn bờ nước ấm kết hợp jacuzzi…</p>\r\n\r\n<p>Bên cạnh đó, hệ thống lọc nước sạch nhập khẩu&nbsp;từ Nhật Bản giúp cư dân uống&nbsp;trực tiếp tại vòi và&nbsp;sơn ngoại thất chống&nbsp;nóng,&nbsp;thấm, nứt nẻ có khả năng giữ màu từ 5 đến 10 năm.&nbsp;</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"2\" cellspacing=\"0\" class=\"tcs\">\r\n	<tbody>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled tcs-selected\" style=\"text-align: center;\"><img alt=\"ASCENT LAKESIDE QUẬN 7 - HƠN 90% CĂN HỘ ĐÃ CÓ CHỦ (Xin edit) - 1\" data-natural-width=\"500\" data-pwidth=\"500\" data-width=\"500\" src=\"https://i-kinhdoanh.vnecdn.net/2018/01/23/Image-ExtractWord-1-Out-1529-1516669814.png\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Nhiều khách hàng quan tâm và sở hữu căn hộ tại Ascent Lakeside.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Chị Minh Phương (quận 3) - khách mua căn hộ&nbsp;Ascent Lakdeside nhìn nhận: \"Lối sống tối giản của người Nhật, thiết kế&nbsp;chuẩn mực gần gũi với thiên nhiên là lý do khiến tôi chọn mua căn hộ\".&nbsp;</p>\r\n\r\n<p>Nhiều khách hàng khác chung ý kiến rằng ngoài&nbsp;vị trí đắc địa ngay KĐT Phú Mỹ Hưng,&nbsp;Ascent Lakeside sở hữu&nbsp;có quy mô vừa phải, số lượng căn hộ không quá nhiều, mang nét đặc trưng riêng&nbsp;không \"đụng hàng\".</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"2\" cellspacing=\"0\" class=\"tcs\">\r\n	<tbody>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled\" style=\"text-align: center;\"><img alt=\"ASCENT LAKESIDE QUẬN 7 - HƠN 90% CĂN HỘ ĐÃ CÓ CHỦ (Xin edit) - 2\" data-natural-width=\"500\" data-pwidth=\"500\" data-width=\"500\" src=\"https://i-kinhdoanh.vnecdn.net/2018/01/23/Image-664433974-ExtractWord-2-9899-5836-1516669814.png\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Khách mời tới sự kiện là chủ nhân tương lai của căn hộ. Hotline: 0911752588, 0919998890. Website: www.ascentlakeside.vn</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Sau&nbsp;The Ascent - Thao Dien Condominiums tại quận 2, đây là dự án thứ hai mang thương hiệu Ascent có đặc trưng luxury boutique home của Tiến Phát Corporation,</p>\r\n\r\n<p>Ông Lê Quốc Duy - Chủ tịch hội đồng quản trị Tiến Phát Corporation cho biết Ascent sẽ là dòng sản phẩm chính được công ty phát triển, tạo hướng đi riêng trên thị trường bất động sản. Do đó, các dự án&nbsp;Ascent được chú trọng hình thức, thiết kế mang đến cư dân trải nghiệm đa dạng.</p>\r\n\r\n<p>Trong giai đoạn tiếp theo,&nbsp;Tiến Phát Corporation sẽ ra mắt thêm các dự án dòng&nbsp;Ascent gồm&nbsp;Ascent Garden Home (quận 7) và Ascent Cityview (quận 4).</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Huyền Trang<br />\r\n(VnExpress.net)</strong></p>\r\n','','no','[]','[]','1','0','0','2','1516677240','1518196074','25');
INSERT INTO olala_article VALUES('943','458','Bất động sản Đà Nẵng: Khu vực nào đang hút nhà đầu tư?','bat-dong-san-da-nang-khu-vuc-nao-dang-hut-nha-dau-tu','','','','bat-dong-san-da-nang-khu-vuc-nao-dang-hut-nha-dau-tu-1519837822.jpg','','','0','0','0','0','0','2412','Hàng loạt dự án lớn ở khu vực Tây Bắc Đà Nẵng và lân cận đang triển khai khiến thị trường bất động sản khu vực phát triển mạnh mẽ...','<p><em><b>Hàng loạt dự án lớn ở khu vực Tây Bắc Đà Nẵng và lân cận đang triển khai khiến thị trường bất động sản khu vực phát triển mạnh mẽ. Với việc hội đủ các điều kiện, nhất là giá cả vừa túi tiền, quy hoạch tốt,… đất nền Tây Bắc Đà Nẵng hiện có xu hướng tăng dần.</b></em></p>\r\n\r\n<p>Đà Nẵng sẽ là điểm đến mới các nhà đầu tư và Tây Bắc Đà Nẵng được đánh giá là khu vực có tiềm năng phát triển mạnh. Sở dĩ đất nền tại khu vực Tây Bắc đang \"nóng\" là do khu vực này đang hội tụ đủ các điều kiện tiếp tục đà tăng trưởng mạnh và bền vững, nhất là phân khúc bất động sản hợp túi tiền của người dân và có quy hoạch tốt.</p>\r\n\r\n<p>Thứ nhất, khu vực Tây Bắc đang có nhiều dự án động lực hoàn toàn có thể thay đổi diện mạo khu vực, thay đổi \"cán cân\" vị thế quận Liên Chiểu và huyện Hòa Vang so với các quận trung tâm. Đơn cử là dự án trục vành đai phía Tây Đà Nẵng với tổng kinh phí ước tính hơn 1.500 tỷ đồng, dự án cảng Liên Chiểu, hầm đường bộ Hải Vân đang triển khai tuyến hầm số 2, đường cao tốc Đà Nẵng - Quảng Ngãi…</p>\r\n\r\n<p>Đặc biệt, với định hướng phát triển bền vững, Đà Nẵng có chiến lược phát triển mạnh những ngành dịch vụ du lịch, công nghệ thông tin, công nghệ cao và nông nghiệp công nghệ cao. Dự án Danang IT Park với tổng vốn đầu tư gần 300 triệu USD thuộc huyện Hòa Vang, Đà Nẵng được đầu tư để trở thành cộng đồng phát triển công nghệ thông tin tốt nhất châu Á theo mô hình thung lũng Silicon tại Đà Nẵng.</p>\r\n\r\n<p>Thứ hai, đề án Khu kinh tế ven biển Đà Nẵng sẽ được các bộ ngành hoàn thiện và bổ sung vào Quy hoạch tổng thể phát triển các khu kinh tế ven biển Việt Nam đến 2020, tầm nhìn 2035. Trong đó, khu kinh tế này bao gồm vịnh Đà Nẵng với một số khu vực lấn biển, Cảng Liên Chiểu, Khu Công nghệ cao Đà Nẵng, Khu công nghiệp Liên Chiểu…</p>\r\n\r\n<p>Thứ ba, với lợi thế nằm ngay điểm giao thông cầu vượt Ngã Ba Huế, nối liền quốc lộ 1A đi vào trung tâm của thành phố, một mặt lại giáp biển Nguyễn Tất Thành, giá đất nền đất nền Tây Bắc hiện vẫn rẻ hơn rất nhiều so với khu vực khác, quãng tăng giá còn rộng và tiềm năng, nên khu Tây Bắc đang trở thành vùng đất mới đầy lực hấp dẫn, thu hút các doanh nghiệp, nhà đầu tư cá nhân đổ về mua đất trong đó tiêu biểu là dự án Golden Hills.</p>\r\n\r\n<p>Ông Bùi Xuân Định, Tổng giám đốc Trung Nam Land chia sẻ: \"Dự án Golden Hills được thiết kế quy hoạch bởi S.O.M - Công ty thiết kế quy hoạch hàng đầu thế giới tại Mỹ có tổng diện tích 400ha với 6 phân khu với đầy đủ các chức năng vượt trội. Năm 2017, Trung Nam đã hoàn thiện giai đoạn 1 dự án với hạ tầng giao thông cao cấp, công viên, khu giải trí hiện đại, trường cấp 2 đẹp nhất Đà Nẵng. Các cơ quan chính quyền, trạm y tế cũng đã hoạt động nên nhanh chóng thu hút đông dân cư sinh sống, làm ăn\".</p>\r\n\r\n<p>Theo ông Định, Trung Nam đang dốc toàn lực thi công giai đoạn 2, đầu tư xây dựng khu phức hợp DITP Power tại đầu tuyến đường Nguyễn Tất Thành nối dài với tổng vốn đầu tư 250 tỷ đồng, 18 tầng; tập trung thi công các khu còn lại; tiếp tục phát triển hệ thống cảnh quan, trung tâm mua sắm và đặc biệt là chuỗi khu phố thương mại Nguyễn Tất Thành để tạo sự sôi động cho khu Tây Bắc Đà Nẵng\".</p>\r\n\r\n<p><a data-fancybox-group=\"img-lightbox\" href=\"https://vneconomy.mediacdn.vn/2017/anh-chinh-1512542277758.jpg\" target=\"_blank\" title=\"\"><img alt=\"undefined - Ảnh 1.\" data-original=\"https://vneconomy.mediacdn.vn/2017/anh-chinh-1512542277758.jpg\" h=\"1125\" height=\"\" id=\"img_072280b0-da50-11e7-97cc-3f2009779d6b\" photoid=\"072280b0-da50-11e7-97cc-3f2009779d6b\" rel=\"lightbox\" src=\"/uploads/images/2018/02/anh-chinh-1512542277758.jpg\" style=\"max-width: 100%;\" title=\"undefined - Ảnh 1.\" type=\"photo\" w=\"2000\" /></a></p>\r\n\r\n<p data-placeholder=\"[nhập chú thích]\">&nbsp;</p>\r\n\r\n<p>Nằm trên cung đường biển đẹp Nguyễn Tất Thành và bên cạnh dòng sông cu Đê, cách trung tâm Thành phố Đà Nẵng khoảng 15 phút đi ôtô, Golden Hills được thiết kế quy hoạch bởi S.O.M - Công ty thiết kết hàng đầu thế giới tại Mỹ.</p>\r\n\r\n<p>Tại Golden Hills, những khu vườn theo phong cách đô thị kết hợp các tuyến phố rợp cây xanh tạo không gian thư giãn cho cư dân.</p>\r\n\r\n<p><a data-fancybox-group=\"img-lightbox\" href=\"https://vneconomy.mediacdn.vn/2017/anh-4-1512542325699.jpeg\" target=\"_blank\" title=\"\"><img alt=\"undefined - Ảnh 2.\" data-original=\"https://vneconomy.mediacdn.vn/2017/anh-4-1512542325699.jpeg\" h=\"1125\" height=\"\" id=\"img_26a95580-da50-11e7-a06b-df02aacc919b\" photoid=\"26a95580-da50-11e7-a06b-df02aacc919b\" rel=\"lightbox\" src=\"/uploads/images/2018/02/anh-4-1512542325699.jpg\" style=\"max-width: 100%;\" title=\"undefined - Ảnh 2.\" type=\"photo\" w=\"2000\" /></a></p>\r\n\r\n<p>Golden Hills có đầy đủ các tiện ích như sân bóng, sân tennis, khu vui chơi cho trẻ em,… đã tạo nên sự phát triển đồng bộ cho toàn khu đô thị. Chính điều này, đến nay, Golden Hills đã thu hút khá đông dân cư đến sinh sống</p>\r\n\r\n<p>Hiện tại, khu A dự án có quy mô gần 100ha đã hoàn thiện hạ tầng và thu hút người đông dân cư đến sinh sống.</p>\r\n\r\n<p>Danang IT Park nằm trong định hướng phát triển công nghệ thông tin về phía Tây Bắc của Đà Nẵng. Nơi đây sẽ góp phần thu hút các nhà khoa học, kỹ sư, các chuyên gia về công nghệ trong và ngoài nước về làm việc, khuyến khích đào tạo các ngành công nghệ cao tại các trường đại học.</p>\r\n\r\n<p><a data-fancybox-group=\"img-lightbox\" href=\"https://vneconomy.mediacdn.vn/2017/anh-6-1512542345028.jpeg\" target=\"_blank\" title=\"\"><img alt=\"undefined - Ảnh 3.\" data-original=\"https://vneconomy.mediacdn.vn/2017/anh-6-1512542345028.jpeg\" h=\"1014\" height=\"\" id=\"img_323173b0-da50-11e7-9915-b99b9cfb322c\" photoid=\"323173b0-da50-11e7-9915-b99b9cfb322c\" rel=\"lightbox\" src=\"/uploads/images/2018/02/anh-6-1512542345028.jpg\" style=\"max-width: 100%;\" title=\"undefined - Ảnh 3.\" type=\"photo\" w=\"2000\" /></a></p>\r\n\r\n<p placeholder=\"[nhập chú thích]\">&nbsp;</p>\r\n\r\n<p>Vị trí dự án được tiếp cận với tuyến đường quốc lộ 1A kết nối với đường cao tốc Đà Nẵng - Quảng Ngãi, đường Nguyễn Tất Thành nối dài và đường DT602, tương lai không xa sẽ có tuyến metro và tuyến xe bus. Danang IT Park sẽ trở thành một trong những cộng đồng phát triển công nghệ thông tin theo mô hình của Thung lũng Silicon, với doanh thu ước đạt 3 tỷ USD/năm.</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Nguồn: VnEconomy</strong></p>\r\n','','no','[]','[]','1','0','0','1','1515430800','1519837822','25');
INSERT INTO olala_article VALUES('923','458','Long Giang Land tăng lãi 8 lần sau 3 tháng','long-giang-land-tang-lai-8-lan-sau-3-thang','','','','long-giang-land-tang-lai-8-lan-sau-3-thang-1518195977.jpg','','','0','0','0','0','0','2208','Việc bàn giao dự án tại TP HCM giúp đơn vị này ghi nhận doanh thu, lợi nhuận tăng đột biến trong quý cuối năm.','<p>Công ty cổ phần Đầu tư và Phát triển đô thị Long Giang (mã CK: LGL) vừa công bố báo cáo tài chính hợp nhất với kết quả đột biến trong quý. Báo cáo cho thấy, doanh thu lũy kế năm 2017 đạt 861 tỷ đồng, trong đó, riêng quý IV đạt 718 tỷ đồng doanh thu.&nbsp;</p>\r\n\r\n<p>Kết thúc năm 2017, công ty lãi sau thuế 106 tỷ đồng, trong khi cuối quý III, mới ghi nhận mức lãi sau thuế chưa đến 12 tỷ đồng.&nbsp;</p>\r\n\r\n<p>Long Giang Land cho biết, kết quả kinh doanh hợp nhất tăng đột biến là do ghi nhận doanh thu, lợi nhuận từ hoạt động bán và bàn giao căn hộ dự án Thành Thái. Dự án có 420 căn hộ, được triển khai xây dựng từ năm 2016.&nbsp;</p>\r\n\r\n<p>Tại Đại hội cổ đông đầu năm,&nbsp;đơn vị này đặt mục tiêu lợi nhuận 100 tỷ đồng.&nbsp;Đến cuối năm 2017, tổng tài sản của doanh nghiệp đạt 2.215 tỷ đồng.</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Nguyễn Hà<br />\r\n(VnExpress.net)</strong></p>\r\n','','no','[]','[]','1','0','0','3','1517626560','1518195977','25');
INSERT INTO olala_article VALUES('924','458','Hai khách trúng xe Mercedes tại lễ tri ân HaDo Centrosa Garden','hai-khach-trung-xe-mercedes-tai-le-tri-an-hado-centrosa-garden','','','','hai-khach-trung-xe-mercedes-tai-le-tri-an-hado-centrosa-garden-1518195952.jpg','','','0','0','0','0','0','2209','Trong sự kiện tri ân ngày 27/1 vừa qua, Tập đoàn Hà Đô đã tìm ra hai khách hàng may mắn của dự án HaDo Centrosa Garden trúng xe Mercedes.','<p>Chủ đầu tư Tập đoàn Hà Đô từng công bố, 99% khách hàng, những người đã đặt mua hơn 2.100 sản phẩm tại HaDo Centrosa Garden đều có cơ hội tham gia chương trình quay số trúng hai xe Mercedes. Quà tặng này thay cho cho lời tri ân chủ đầu tư Hà Đô dành cho các cư dân tương lai.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\" class=\"tcs\">\r\n	<tbody>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled\" style=\"text-align: center;\"><img alt=\"Nhiều khách hàng chứng kiến sự kiện tìm 2 chủ nhân căn hộ may mắn trúng 2 xe Mercedes.\" data-natural-width=\"500\" data-pwidth=\"500\" data-width=\"500\" src=\"https://i-kinhdoanh.vnecdn.net/2018/01/31/q3-4844-1517364008.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Nhiều khách hàng chứng kiến sự kiện tìm hai&nbsp;chủ nhân căn hộ may mắn trúng 2 xe Mercedes.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Theo đó, trong sự kiện \"Chọn chốn an khang - xe sang đón Tết\" ngày 27/1 vừa qua do Tập đoàn Hà Đô triển khai,&nbsp;chủ nhân sở hữu căn hộ I3-16.08 - bà Phạm Thị Hồng Loan và O1-09.10 - ông Đỗ Bá Hùng đã trở thành những khách hàng may mắn trúng xe Mercedes.&nbsp;</p>\r\n\r\n<p>Sau khi xem phát sóng trực tiếp chương trình và nhận thông báo từ chủ đầu tư Hà Đô, hai khách hàng may mắn này đã nhanh chóng có mặt tại dự án để thực hiện thủ tục nhận giải thưởng.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"2\" cellspacing=\"0\" class=\"tcs\">\r\n	<tbody>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled tcs-selected\" style=\"text-align: center;\"><img alt=\"Gia đình chủ nhân căn hộ I3-16.08 - Bà Phạm Thị Hồng Loan đã may mắn sở hữu chiếc Mercedes trong chương trình.\" data-natural-width=\"500\" data-pwidth=\"500\" data-width=\"500\" src=\"https://i-kinhdoanh.vnecdn.net/2018/01/31/q2-8115-1517364008.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Gia đình chủ nhân căn hộ I3-16.08 - Bà Phạm Thị Hồng Loan đã may mắn sở hữu chiếc Mercedes trong chương trình.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Bà Phạm Thị Hồng Loan - chủ nhân căn hộ I3-16.08, người trúng chiếc Mercedes đầu tiên trong chương trình chia sẻ: \"Tôi rất bất ngờ khi nhận thông tin trúng giải. Cả gia đình tôi đã cùng đến dự án ngay sau có kết quả quay thưởng. Tôi tin rằng với cách thức thực hiện và phát triển dự án như hiện nay, Tập đoàn Hà Đô sẽ còn phát triển hơn nữa\".</p>\r\n\r\n<p>Ông Đỗ Bá Hùng, chủ nhân căn hộ O1-09.10 người trúng xe Mercedes thứ hai trong chương trình cũng cho biết:&nbsp;\"Sau khi sở hữu một căn thuộc khu nhà phố liên kế, tôi tiếp tục đặt mua thêm một căn hộ tại block Orchid 1 để gia đình sinh sống. Tôi hài lòng về căn nhà phố liên kế cũng như căn hộ đã đặt mua và luôn an tâm thực hiện các tiến độ thanh toán vì tiến độ, chất lượng công trình đảm bảo\".</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\" class=\"tcs\">\r\n	<tbody>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled\" style=\"text-align: center;\"><img alt=\"Chủ nhân căn hộ O1-09.10, ông Đỗ Bá Hùng (bên trái) đã may mắn sở hữu chiếc Mercedes thứ hai trong chương trình. Khách hàng có nhu cầu tìm hiểu thông tin chi tiết về dự án, liên hệ: 1800 2018, 0926 756 756 (miễn phí). Địa chỉ dự án: Số 200 đường 3/2, phường 12, quận 10; website: www.hadocentrosagarden.vn\" data-natural-width=\"500\" data-pwidth=\"500\" data-width=\"500\" src=\"https://i-kinhdoanh.vnecdn.net/2018/02/02/hinh-thay-1-2834-1517544765.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Chủ nhân căn hộ O1-09.10, ông Đỗ Bá Hùng (bên trái) đã may mắn sở hữu chiếc Mercedes thứ hai trong chương trình.&nbsp;</p>\r\n\r\n			<p>Khách hàng có nhu cầu tìm hiểu thông tin chi tiết về dự án, liên hệ: 1800 2018,&nbsp;0926 756 756 (miễn phí). Địa chỉ dự án: Số 200 đường 3/2, phường 12, quận 10; website:&nbsp;<a href=\"http://www.hadocentrosagarden.vn/\" target=\"_blank\">www.hadocentrosagarden.vn</a></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Tại sự kiện, ông Phạm Quốc Huân - Phó Tổng Giám đốc Công ty CP Hà Đô - 756 đã gửi lời tri ân đến toàn thể khách hàng và các đối tác tham gia phát triển dự án. Ông cũng thay mặt chủ đầu tư cam kết dự án đảm bảo tiến độ, chất lượng xây dựng, dự kiến bàn giao sớm đến khách hàng.</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Thế Đan<br />\r\n(VnExpress.net)</strong></p>\r\n','','no','[]','[]','1','0','0','3','1517626680','1518195952','25');
INSERT INTO olala_article VALUES('926','458','The Panorama Đà Lạt thu hút khách hàng ngày mở bán','the-panorama-da-lat-thu-hut-khach-hang-ngay-mo-ban','','','','the-panorama-da-lat-thu-hut-khach-hang-ngay-mo-ban-1518195933.jpg','','','0','0','0','0','0','2211','\"Mười cánh bung nở, xếp tầng, nhỏ dần về phía trên tạo tháp hoa ấn tượng\", Thạc sĩ, KTS Hồ Viết Vinh chia sẻ ý tưởng thiết kế The Panorama.','<p>Tọa lạc trên \"con đường di sản\" mang đậm phong cách kiến trúc Pháp, dự án căn hộ The Panorama - Đà Lạt được bao quanh bởi rừng thông lớn, nét đặc trưng của thành phố nghìn hoa.</p>\r\n\r\n<p>Từ lợi thế của vị trí đắc địa này, Công ty CP Đầu tư Phong Vân - chủ đầu tư dự án đã triển khai ý tưởng \"thu Đà Lạt vào trong tầm mắt\".</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"2\" cellspacing=\"0\" class=\"tcs\">\r\n	<tbody>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled\" style=\"text-align: center;\"><img alt=\"The Panorama - Đà Lạt với góc nhìn 360 độ toàn cảnh Đà Lạt.\" data-natural-width=\"500\" data-pwidth=\"500\" data-width=\"500\" src=\"https://i-kinhdoanh.vnecdn.net/2018/01/29/h4-5016-1517215943.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>The Panorama - Đà Lạt với góc nhìn 360 độ toàn cảnh Đà Lạt.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Chia sẻ về ý tưởng thiết kế, Thạc sĩ, kiến trúc sư Hồ Viết Vinh, Giám đốc Trung tâm Nghiên cứu CREA, Trường Đại học Kiến trúc TP HCM cho biết: \"The Panorama mang dáng vẻ hoa Cẩm Tú Cầu (Hortensia) một loài hoa đặc trưng tại Đà Lạt\".</p>\r\n\r\n<p>Mười cánh bung nở, xếp tầng, thu nhỏ dần về phía trên tạo hình dáng tháp hoa ấn tượng, hòa mình vào vẻ đẹp lãng mạn của thành phố Festival Hoa. Phía bên dưới, các cánh cung cuốn vòm vượt độ cao 8m tạo những cánh hoa rộng để ngắm thiên nhiên từ bên trong\".</p>\r\n\r\n<p>\"The Panorama phù hợp với những khách hàng có nhu cầu trở về với thiên nhiên và tận hưởng trọn vẹn những giây phút thư giãn\", đại diện chủ đầu tư chia sẻ.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"2\" cellspacing=\"0\" class=\"tcs\">\r\n	<tbody>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled\" style=\"text-align: center;\"><img alt=\"Số lượng căn hộ giới hạn là một trong những điểm thu hút khách hàng.\" data-natural-width=\"500\" data-pwidth=\"500\" data-width=\"500\" src=\"https://i-kinhdoanh.vnecdn.net/2018/02/01/a1a-9069-1517446324.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Số lượng căn hộ giới hạn là một trong những điểm&nbsp;thu hút khách hàng.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>The Panorama trang trí theo phong cách Art Nouveau. Theo đó, mỗi căn hộ của dự án đều sang trọng, đơn giản và ấm cúng. Các chi tiết trang trí tinh tế, nhằm tô điểm cho bề mặt tường, trần và sàn nhà. Các vật dụng nội thất thiết kế theo hình thức hiện đại nhưng biểu cảm trong chất liệu và tỷ lệ.</p>\r\n\r\n<p>Dự án thiết kế theo phong cách mở, kiến tạo trên giá trị xanh, giữ nguyên vẹn không gian bên ngoài, nhiều ánh sáng bên trong.</p>\r\n\r\n<p>Chủ đầu tư cho biết hiện The Panorama&nbsp;triển khai đến tầng bảy (tầng cuối cùng), dự kiến hoàn tất bàn giao cho khách hàng vào khoảng tháng 9/2018.</p>\r\n\r\n<table align=\"center\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\" class=\"tcs\">\r\n	<tbody>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled tcs-selected\" style=\"text-align: center;\"><img alt=\"Lễ mở bán căn hộ The Panorama - Đà Lạt thu hút sự quan tâm và tìm hiểu của nhiều khách hàng.\" data-natural-width=\"500\" data-pwidth=\"500\" data-width=\"500\" src=\"https://i-kinhdoanh.vnecdn.net/2018/02/01/a2-7581-1517446324.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Sự kiện&nbsp;mở bán căn hộ The Panorama - Đà Lạt thu hút sự quan tâm của nhiều khách hàng.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>\"Với những ưu điểm về vị trí, kiến trúc, tiện ích, mức giá phù hợp, The Panorama - Đà Lạt được nhiều khách hàng đặt cọc ngay trong lễ mở bán ngày 28/1. Toàn bộ giỏ hàng đầu tiên đã giao dịch thành công trong 45 phút\", đại diện chủ đầu tư cho biết.</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Thế Đan<br />\r\n(VnExpress.net)</strong></p>\r\n','','no','[]','[]','1','0','0','20','1517626860','1518195933','25');
INSERT INTO olala_article VALUES('942','458','“Sóng mạnh” đổ về bất động sản Tây Bắc Đà Nẵng','song-manh-do-ve-bat-dong-san-tay-bac-da-nang','','','','song-manh-do-ve-bat-dong-san-tay-bac-da-nang-1519837512.jpg','','','0','0','0','0','0','2411','Cùng với lợi thế về giá, khu vực Tây Bắc Đà Nẵng đang chứng kiến các giao dịch bất động sản sôi động hơn bao giờ hết khi hàng loạt dự án “khủng” đang được triển khai tại khu vực này.','<p>Còn nhớ, tại trong buổi làm việc với lãnh đạo chủ chốt TP Đà Nẵng về tình hình phát triển kinh tế - xã hội trong năm 2016, Thủ tướng Nguyễn Xuân Phúc đã nhấn mạnh: “Tầm nhìn của Đà Nẵng là trở thành thành phố thông minh, một trung tâm giao thương quốc tế, một thành phố cạnh tranh với các thành phố lớn, đẹp của khu vực và thế giới, mà trước hết là một Singapore, một Hong Kong”. &nbsp;</p>\r\n\r\n<p><strong>Tiềm năng lớn</strong></p>\r\n\r\n<p>Theo quy hoạch phát triển không gian đô thị Đà Nẵng đến năm 2020, tầm nhìn 2030, khu vực cũ sẽ là trung tâm lịch sử, chính trị, văn hóa truyền thống, khu ven biển Tây Bắc và ven biển phía đông sẽ trở thành trung tâm thương mại dịch vụ, du lịch nghỉ dưỡng... được coi là nơi an cư lý tưởng đối với các cư dân thành phố biển.</p>\r\n\r\n<p>Quy hoạch này cũng cho thấy rõ một Đà Nẵng đa trung tâm, phát triển toàn diện, bền vững trong tương lai. &nbsp;</p>\r\n\r\n<p>Chỉ tính riêng khu vực Tây Bắc, khu vực này đang được quy hoạch là khu đô thị vệ tinh của TP. Đà Nẵng với các dự án nổi bật như tuyến giao thông vành đai phía Tây (vốn lên đến 1.5 ngàn tỷ đồng), Khu Khép Kín giải trí quốc tế Làng Vân, cảng Liên Chiểu, Khu công nghệ cao, Nhà ga hàng hóa Kim Liên…&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"/uploads/images/2018/02/anh-2-20.jpg\" style=\"max-width: 100%;\" /><br />\r\n<em>Golden Hills đang hoàn thiện dần từng hạng mục, đúng như cam kết từ chủ đầu tư (Ảnh: Trường cấp 2 Đàm Quang Trung trong lòng khu đô thị Golden Hills)</em></p>\r\n\r\n<p>Đồng thời, cũng tại khu vực này, Đà Nẵng đang kêu gọi đầu tư Khu công nghệ thông tin tập trung với mục tiêu đưa nơi này trở thành một cộng đồng CNTT theo mô hình của Thung lũng Silicon tại Hoa Kỳ hay Khu công nghệ cao Hsinchu tại Đài Loan. Qua đó góp phần thu hút các nhà khoa học, kỹ sư, các chuyên gia về công nghệ trong và ngoài nước về làm việc, khuyến khích đào tạo các ngành công nghệ cao tại các trường đại học; hình thành môi trường sống, môi trường làm việc lý tưởng với doanh thu ước đạt 3 tỷ USD/năm và khả năng tuyển dụng 25.000 lao động trong 10 năm tới, góp phần xây dựng nên một đô thị vệ tinh ở vùng Tây Bắc Đà Nẵng với khoảng 100.000 cư dân sinh sống.</p>\r\n\r\n<p>Được biết, với tổng vốn 32 triệu USD, theo kế hoạch, dự án sẽ hoàn tất xây dựng hạ tầng cơ sở trong 10 năm (2013-2023) bao gồm các hạng mục: khu sản xuất, kinh doanh sản phẩm và dịch vụ CNTT; khu nghiên cứu, phát triển và đào tạo, tư vấn; khu văn phòng, trụ sở làm việc; khu trưng bày hội chợ, triển lãm, giới thiệu sản phẩm và truyền thông, hiện dự án đang được triển khai với sự tham gia của công ty CP Trung Nam sau khi đơn vị này nhận chuyển nhượng 65% cổ phần DITP từ tập đoàn Rocky Lai &amp; Associates - Đà Nẵng và các nhà đầu tư tại Hoa Kỳ.&nbsp;</p>\r\n\r\n<p>Đây chính là nền tảng vững chắc để các nhà đầu tư tin rằng, bất động sản Tây Bắc chỉ phát triển theo hướng bền vững, chứ khó có thể xảy ra hiện tượng “bong bóng”. Và đó là một nền tảng để khu vực này không chỉ bứt phá trong năm nay, mà còn tiếp tục “nóng lên” trong những năm kế tiếp.</p>\r\n\r\n<p><strong>Dự án nào đang là tâm điểm?</strong></p>\r\n\r\n<p>Cùng với “cú huých” hạ tầng và những dự án khủng, khu vực Tây Bắc Đà Nẵng còn được giới bất động sản chú ý bởi giá tại khu vực này đang rất rẻ so với tiềm&nbsp;năng.&nbsp;</p>\r\n\r\n<p>Theo các chuyên gia bất động sản, hiện giá bất động sản tại khu vực này tương đối đảm bảo đúng giá trị thực. Các sản phẩm đến được tay người dân có nhu cầu mua để ở, đặc biệt là những người trẻ và gia đình tri thức do giá chỉ khoảng trên dưới 1 tỷ /sản phẩm nhưng nằm trong khu đô thị được đầu tư hạ tầng tốt, kết nối thuận tiện với mạng lưới trường học, bệnh viện, không gian công cộng vui chơi, giải trí,… Đặc biệt, do đường sá thông thoáng, nên việc di chuyển về trung tâm thành phố rất thuận tiện.</p>\r\n\r\n<p>“Lấy ví dụ với dự án Golden Hills, dù sở hữu địa thế thuận lợi trong khu vực phát triển bậc nhất TP Đà Nẵng, được thiết kế quy hoạch rất bài bản bởi đơn vị uy tín đã từng triển khai thành công Khu đô thị Phú Mỹ Hưng – Công ty thiết kế SOM, cách trung tâm TP Đà Nẵng 15 phút đi xe, chỉ cách biển khoảng 5 phút đi bộ nhưng tại dự án này, với tuyến lớn rộng 41m như Nguyễn Tất Thành nối dài, giá 1 lô đất dao động từ 1,2 - 1,4 tỷ đồng còn những tuyến đường nhỏ hơn thì giá 1 lô đất dao động khoảng 600 triệu đồng nên đã thu hút rất nhiều người dân đến sinh sống”, Ngô Văn Phương – môi giới một sản giao dịch tại khu vực này chia sẻ.</p>\r\n\r\n<p>Như vậy, với chiến lược phát triển không gian đô thị Đà Nẵng đến năm 2020, tầm nhìn 2030, có thể khẳng định: “Thiên thời, địa lợi” tại Tây Bắc Đà Nẵng đều đã có cả. Vậy nên, nhiều nhà đầu tư trong và ngoài nước cũng ráo riết khai thác các quỹ đất nơi đây để đầu tư các công trình quy mô lớn, tạo đà phát triển chung cho khu vực. Nhiều “ông lớn” trong ngành bất động sản đã nhanh chân để không bỏ lỡ mất cơ hội “góp mặt” tại “điểm nóng” này.</p>\r\n\r\n<p>Và với việc “quần anh hội tụ” như vậy, theo giới phân tích, 2018 sẽ là thời điểm để thị trường địa ốc Đà Nẵng nói chung và Tây Bắc nói riêng bứt phá ngoạn mục, hứa hẹn nhiều giao dịch sôi động.</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Theo: Thu Giang</strong><br />\r\n<em>http://batdongsan.enternews.vn</em></p>\r\n','','no','[]','[]','1','0','0','1','1515434400','1519837531','25');
INSERT INTO olala_article VALUES('935','457','The Sunrise Bay','the-sunrise-bay','','','','the-sunrise-bay-1519809409.jpg','','Nguyễn Tất Thành, Hải Châu, Đà Nẵng','3500000000','0','0','0','2','2403','Sunrise Bay Đà Nẵng – siêu dự án đô thị đẳng cấp quốc tế lớn nhất Đà Nẵng với quy mô 171 ha đất liền & 18 ha diện tích đảo được quy hoạch gồm nhiều hạng mục công trình: khách sạn, sân golf 18 lỗ, khu resort cao cấp, trung tâm hội nghị, bến cảng… cùng nhiều loại hình đầu tư như nhà phố thương mại, nhà phố vườn, biệt thự đơn lập, biệt thự song lập.','<div class=\"locationmap\"><iframe __idm_frm__=\"982\" height=\"350px\" src=\"/editor/googlemap.html?x=16.08386745636391&amp;y=108.20898749567482&amp;z=15&amp;img=The Sunrise Bay&amp;googlemap=true\" style=\"border: none; max-width:100%;\" width=\"100%\"></iframe></div>\r\n\r\n<div class=\"youtube-embed-wrapper\" style=\"position:relative;padding-bottom:51.5%;padding-top:30px;height:0;overflow:hidden\"><iframe allowfullscreen=\"\" frameborder=\"0\" height=\"360\" src=\"https://www.youtube.com/embed/1ya_QyERPb0?rel=0\" style=\"position:absolute;top:0;left:0;width:100%;height:100%\" width=\"640\"></iframe></div>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><u>Sơ đồ tổng thể:</u></h2>\r\n\r\n<p><strong><img alt=\"\" src=\"/uploads/images/2018/02/2017-11-14%20PLACE%20GROUND%20(560x540)%20ALL%20OF%20FINAL%20-%20Out%20Print-01.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/BangPhanKhuTheoCSBH-final.jpg\" style=\"max-width: 100%;\" /></strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><u>Khu đô thị vị trí độc tôn tại TP Đà Nẵng:</u></h2>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/2018/03/page-1.jpg\" style=\"max-width: 100%;\" /></p>\r\n\r\n<p><strong>Dự án The Sunrise Bay</strong>&nbsp;tọa lạc tại vị trí đắc địa - quỹ đất lấn biển vị thế có một không hai.</p>\r\n\r\n<p>The Sunrise Bay, dự án vịnh trong vịnh, nằm gọn trong eo biển, một trong những vị trí đắc địa ngay tại trung tâm của Đà Nẵng, kết nối linh hoạt với các tiện ích vệ tinh chỉ với vài phút di chuyển.</p>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/2018/03/page-3(1).jpg\" style=\"max-width: 100%;\" /></p>\r\n\r\n<p>-&nbsp;<strong>Chủ đầu tư</strong>: Công ty TNHH The Sunrise Bay</p>\r\n\r\n<p>-&nbsp;<strong>Vị trí</strong>: Phường Thanh Bình và phường Thuận Phước, quận Hải Châu, TP. Đà Nẵng</p>\r\n\r\n<p>+ Hướng Đông: view sông Hàn<br />\r\n+ Hướng Tây: vịnh Thanh Bình<br />\r\n+ Hướng Nam: trung tâm Đà Nẵng<br />\r\n+ Hướng Bắc: bán đảo Sơn Trà</p>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/2018/03/page-4(1).jpg\" style=\"max-width: 100%;\" /></p>\r\n\r\n<p>-&nbsp;<strong>Diện tích</strong>: 171 ha gồm 153 ha đất liền và 18 ha diện tích đảo</p>\r\n\r\n<p>-&nbsp;<strong>Loại hình sản phẩm</strong>: Nhà phố vườn townhouse /nhà phố thương mại shophouse / biệt thự song lập / biệt thự đơn lập.</p>\r\n\r\n<p>+ Nhà phố vườn townhouse: Diện tích từ 80m<sup>2</sup>&nbsp;- 90m<sup>2</sup>&nbsp;- 100m<sup>2</sup>&nbsp;- 100m<sup>2</sup>&nbsp;- 108m<sup>2</sup>&nbsp;- 120m<sup>2</sup><br />\r\n+ Nhà phố thương mại: Diện tích từ 100m<sup>2</sup>- 108m<sup>2</sup>-120m<sup>2</sup><br />\r\n+ Biệt thự song lập: 150m<sup>2</sup>-160m<sup>2</sup><br />\r\n+ Biệt thự đơn lập: 300m<sup>2</sup></p>\r\n\r\n<p><strong><span style=\"font-size: 10.8333px;\">-&nbsp;</span>Hình thức sở hữu nhà:</strong> Sở hữu lâu dài</p>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/2018/03/Co%20cau%20san%20pham%20The%20Sunrise%20Bay.jpg\" style=\"max-width: 100%;\" /></p>\r\n\r\n<p><strong>Các đối tác tham gia vào thiết kế dự án</strong></p>\r\n\r\n<p>- Thiết kế quy hoạch và kiến trúc:&nbsp;<strong>AEDAS</strong>, top 5 trong công ty thiết kế kiến trúc hàng đầu thế giới, đến từ Mỹ.</p>\r\n\r\n<p>- Thiết kế cảnh quan:&nbsp;<strong>EDSA</strong>, công ty nổi tiếng thiết kế hơn 500 dự án về cảnh quan trên 100 quốc gia trên toàn cầu.</p>\r\n\r\n<p>- Thiết kế đảo:&nbsp;<strong>SAFDIE ARCHITECT</strong>, ông chủ là&nbsp;<strong>MOSHE SAFDIE</strong>&nbsp;với những công trình kiến trúc độc đáo vô nhị, là người thiết kế nên Marina Bay Sand của Singapore.</p>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/2018/03/The%20Sunrise%20Bay28(1).jpg\" style=\"max-width: 100%;\" /></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/2018/03/The%20Sunrise%20Bay30.jpg\" style=\"max-width: 100%;\" /></p>\r\n\r\n<p>-&nbsp;<strong>Tiện ích</strong>: không gian sống của dự án The Sunrise Bay với nhiều tiện ích&nbsp;phong cách resort giúp cư dân tận hưởng cuộc sống an bình thoải mái.</p>\r\n\r\n<p>+ Tiện ích hồ bơi 5 sao<br />\r\n+ Không gian sinh hoạt cộng đồng<br />\r\n+ Khu vui chơi trẻ em<br />\r\n+ Khu công viên kéo dài 1km và công viên nội khu mang đến không gian xanh thư giãn&nbsp;<br />\r\n+ Bãi tắm nhân tạo, bến du thuyền</p>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/2018/03/page-15.jpg\" style=\"max-width: 100%;\" /></p>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/2018/03/page-17.jpg\" style=\"max-width: 100%;\" /></p>\r\n','https://www.youtube.com/watch?v=ifl_xlHjBns','yt_1519876572_2403_641906a544c5450492e5955920d4cf60_1.jpg','[]','[]','1','0','0','18','1519808400','1519876572','25');
INSERT INTO olala_article VALUES('936','466','Phú Gia Compound','phu-gia-compound','','','','phu-gia-compound-1519809943.jpg','','126 Ông Ích Khiêm, Hải Châu, Đà Nẵng','5800000000','0','0','0','3','2404','Phú Gia Compound là dự án phức hợp khu nhà phố vườn và nhà phố thương mại ấn tượng tại Trung tâm Đà Nẵng. Với vị trị đắc địa mặt tiền đường Ông Ích Khiêm, tiện ích hiện đại, dự án là một sự lựa chọn hoàn hảo để trải nghiệm một cuộc sống đẳng cấp và khác biệt.','<div class=\"locationmap\"><iframe __idm_frm__=\"1082\" height=\"350px\" src=\"/editor/googlemap.html?x=16.074320401094994&amp;y=108.21261754277191&amp;z=17&amp;img=Phú Gia Compound&amp;googlemap=true\" style=\"border: none; max-width:100%;\" width=\"100%\"></iframe></div>\r\n\r\n<div class=\"youtube-embed-wrapper\" style=\"position:relative;padding-bottom:51.5%;padding-top:30px;height:0;overflow:hidden\"><iframe allowfullscreen=\"\" frameborder=\"0\" height=\"360\" src=\"https://www.youtube.com/embed/KJpiEXUzCYE?rel=0\" style=\"position:absolute;top:0;left:0;width:100%;height:100%\" width=\"640\"></iframe></div>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><u>Sơ đồ tổng thể:</u></h2>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/2018/02/TONG%20THE%20-%2020161027_PG_Master%20plan%20Filelon.jpg\" style=\"max-width: 100%;\" /></p>\r\n','https://www.youtube.com/watch?v=KATNnJ48f_o','yt_1519876830_2404_f9f1481defaef85fa68b35c659faf8ee_1.jpg','[]','[]','1','0','0','6','1519806600','1519876830','25');
INSERT INTO olala_article VALUES('937','457','Monarchy','monarchy','','','','monarchy-1519833175.jpg','','Trần Hưng Đạo, Sơn Trà, Đà Nẵng','3000000000','0','0','0','2','2406','Nằm trong danh sách các di sản văn hoá thế giới nổi tiếng được UNESCO công nhận như : khu phố cổ Hội An, khu bảo tồn Mỹ Sơn và thành phố Huế thì thành phố Đà Nẵng không chỉ là biểu tượng tăng trưởng kinh tế - văn hoá ,là Điểm đến lý tưởng cho du lịch và giải trí mà còn được biết đến với danh hiệu Thành phố Đáng sống nhất Việt Nam.','<div class=\"locationmap\"><iframe __idm_frm__=\"1344\" height=\"350px\" src=\"/editor/googlemap.html?x=16.056154453777424&amp;y=108.23243370297394&amp;z=17&amp;img=Monarchy&amp;googlemap=true\" style=\"border: none; max-width:100%;\" width=\"100%\"></iframe></div>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><u>Mặt bằng căn hộ:</u></h2>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/2018/02/1_MB%20SH.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/2_MB%20TANG%201.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/3_MB%20TANG%203.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/4_MB%20TANG%204.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/5_MB%20TANG%205.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/6_MB%20TANG%206.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/7_MB%20TANG%207-15-22.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/8_MB%20TANG%208-16-23.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/9_MB%20TANG%209-17-24.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/10_MB%20TANG%2010-11-12-14-18-19-20-22-25-26-27.jpg\" style=\"max-width: 100%;\" /></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><u>Tổng quan dự án:</u></h2>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/2018/02/11_IMG_1401.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/12_IMG_1412.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/13_IMG_1406.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/14_IMG_1419.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/15_IMG_1424.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/16_IMG_1422.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/17_IMG_1427.jpg\" style=\"max-width: 100%;\" /></p>\r\n','','no','[]','[]','1','0','0','5','1519804800','1519839676','25');
INSERT INTO olala_article VALUES('938','457','Hiyori Garden Tower','hiyori-garden-tower','','','','hiyori-garden-tower-1519835455.jpg','','Võ Văn Kiệt, Sơn Trà, Đà Nẵng','1800000000','0','0','0','0','2407','Dự án Hiyori Garden Tower nằm trên tuyến đường, thuộc một trong những con đường đắc giá Võ Văn Kiệt, Đà Nẵng. Căn hộ được thiết kế theo căn hộ xanh kết hợp tiện nghi đầy đủ, với đầu tư 100% từ Nhật Bản “Xứ sở hoa anh đào” tại thành phố biển xinh đẹp Đà Nẵng. Nhằm đảm bảo một nơi an cư, mang đến những trải nghiệm tiện ích đầy đủ nhất cho cư dân sống tại căn hộ.','<div class=\"locationmap\"><iframe __idm_frm__=\"1347\" height=\"350px\" src=\"/editor/googlemap.html?x=16.061300383033252&amp;y=108.23558261635753&amp;z=17&amp;img=Hiyori Garden Tower&amp;googlemap=true\" style=\"border: none; max-width:100%;\" width=\"100%\"></iframe></div>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><u>Mặt bằng căn hộ:</u></h2>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/2018/02/201_Floorplan_05.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/202_Floorplan_06.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/203_Floorplan_07.jpg\" style=\"max-width: 100%;\" /></p>\r\n','','no','[]','[]','1','0','0','2','1519801200','1519839686','25');
INSERT INTO olala_article VALUES('939','455','The Ocean Estates','the-ocean-estates','','','','the-ocean-estates-1519836100.jpg','','Trường Sa, Ngũ Hành Sơn, Đà Nẵng','16000000000','0','0','0','2','2408','Khu biệt thự The Ocean Estates là điểm nhấn cuối cùng của dự án nghỉ dưỡng đình đám The Ocean Resort được chủ đầu tư VinaCapital khởi công vào cuối năm 2016. The Ocean Estates sở hữu địa thế chiến lược tại một trong những dải biển đẹp nhất miền Trung, chỉ cách sân bay Đà Nẵng khoảng 20 phút chạy xe và nằm trên trục đường nối liền những di sản văn hóa được UNESCO công nhận như Huế, phố cổ Hội An. Dự án đã được Sở Xây dựng thành phố Đà Nẵng công nhận đủ điều kiện bán nhà ở hình thành trong tương lai.','<div class=\"locationmap\"><iframe __idm_frm__=\"1355\" height=\"350px\" src=\"/editor/googlemap.html?x=16.012346261805895&amp;y=108.2627909446046&amp;z=15&amp;img=The Ocean Estates&amp;googlemap=true\" style=\"border: none; max-width:100%;\" width=\"100%\"></iframe></div>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><u>Tổng quan dự án:</u></h2>\r\n\r\n<p><u><img alt=\"\" src=\"/uploads/images/2018/02/The%20Ocean%20Estates.jpg\" style=\"max-width: 100%;\" /></u></p>\r\n','','no','[]','[]','1','0','0','1','1519797600','1519839736','25');
INSERT INTO olala_article VALUES('940','458','Mua nhà tặng vàng tại Prosper Plaza','mua-nha-tang-vang-tai-prosper-plaza','','','','mua-nha-tang-vang-tai-prosper-plaza-1519836662.jpg','','','0','0','0','0','0','2409','Nhân dịp Tết Mậu Tuất, chủ đầu tư dự án Prosper Plaza triển khai nhiều ưu đãi dành cho khách hàng như tặng vàng, chính sách thanh toán linh hoạt...','<p>Theo đại diện chủ đầu tư, bên cạnh những giải thưởng lớn, khi giao dịch thành công trong đợt mở bán căn hộ Prosper Plaza dịp đầu năm, khách hàng được nhận thêm các phần quà như tiền vàng có giá trị từ 2 đến 5 chỉ vàng 9999. Khách hàng tham quan dự án trong ngày diễn ra sự kiện cũng có cơ hội nhận nhiều phần quà hấp dẫn.</p>\r\n\r\n<p>\"Sau hai đợt mở bán đầu, đã có 1.000 căn tương đương 70% sản phẩm được giao dịch thành công. Để đáp ứng nhu cầu khách hàng, trong giai đoạn 3 này chủ đầu tư tiếp tục tung ra thị trường 469 sản phẩm. Đây là những căn hộ có tầm nhìn, tầng và vị trí đẹp của&nbsp;dự án Prosper Plaza\", đại diện chủ đầu tư cho biết.</p>\r\n\r\n<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\" class=\"tcs\">\r\n	<tbody>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled\" style=\"text-align: center;\"><img alt=\"Phối cảnh tổng thể dự án Prosper plaza.\" data-natural-width=\"479\" data-pwidth=\"500\" data-width=\"479\" src=\"/uploads/images/2018/02/Prosper-Plaza.jpg\" style=\"max-width: 100%;\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled\">\r\n			<p style=\"text-align: center;\">Phối cảnh tổng thể dự án Prosper plaza.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p>Bà Châu Thị Mỹ Linh, Tổng Giám đốc Công ty cổ phần đầu tư Phúc Phúc Yên cũng chia sẻ, Prosper Plaza được thị trường quan tâm với lượng giao dịch lớn bởi dự án thuộc phân khúc cao cấp, giá cả hợp lý, chính sách bán hàng linh hoạt. Bên cạnh đó, dự án có lợi thế về vị trí, được đầu tư thiết kế và quy hoạch hiện đại.</p>\r\n\r\n<p>Prosper Plaza đang ở giai đoạn đã cất nóc Block C, còn Block B đã hoàn thành sàn 18, Block A đã hoàn thành sàn 17 và đang trong quá trình hoàn thiện để chuẩn bị chào đón những cư dân đầu tiên.</p>\r\n\r\n<p>Dự án tiếp giáp các tuyến đại lộ lớn như tuyến đường Trường Chinh - Cộng Hòa. Từ đây, cư dân có thể dễ dàng di chuyển đến các khu vực lân cận như khu đô thị mới quận 12, quận Tân Phú, Tân Bình, Gò Vấp, hay Sân bay Tân Sơn Nhất…&nbsp;</p>\r\n\r\n<p>Ngoài hạ tầng giao thông thuận lợi, cư dân Prosper Plaza còn thừa hưởng hệ thống tiện tích ngoại khu đầy đủ như Coop Mart Trường Chinh, Pandora City, Big C, Aeon Mall cùng nhiều công trình trọng điểm như sân bay quốc tế Tân Sơn Nhất, khu công nghiệp Tân Bình, công viên Hoàng Văn Thụ…</p>\r\n\r\n<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\" class=\"tcs\">\r\n	<tbody>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled\" style=\"text-align: center;\"><img alt=\"Hồ bơi trung tâm - tiện ích chuẩn sống xanh tại Prosper plaza. Hiện dự án phân phối bởi đại lý uy tín như PY Prosper. Khách hảng quan tâm dự án liên hệ hotline : 0979 823 322; 02822159683, website: http://tapdoanphucyenprosper.com/\" data-natural-width=\"500\" data-pwidth=\"500\" data-width=\"500\" src=\"/uploads/images/2018/02/Prosper-Plaza02.jpg\" style=\"max-width: 100%;\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td class=\"tcs-selection-enabled\">\r\n			<p style=\"text-align: center;\">Hồ bơi trung tâm - tiện ích chuẩn sống xanh tại Prosper plaza. Hiện dự án phân phối bởi đại lý uy tín như PY Prosper. Khách hảng quan tâm dự án liên hệ Hotline : ‎0979 823 322; 02822159683, website:&nbsp;<a href=\"http://tapdoanphucyenprosper.com.vn/\" target=\"_blank\">http://tapdoanphucyenprosper.com.vn</a></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Điểm nổi bật của Prosper Plaza là sở hữu hồ sinh thái và công viên nội khu ngay trong lòng dự án. Nhờ quy hoạch và xây dựng khu vực công viên rộng lớn, cư dân ở đây có thể hưởng thụ không gian sống xanh, thanh bình.</p>\r\n\r\n<p>Không chỉ chăm chút về thiết kế, tiện ích nội khu, chủ đầu tư và đơn vị phân phối còn tạo nhiều điều kiện để khách hàng có thể tiếp cận dự án. Bên cạnh phương thức thanh toán linh hoạt, với mức giá trên dưới một tỷ đồng một căn (đã gồm VAT) gồm 2 phòng ngủ, 2 toilet , khách hàng còn được hỗ trợ và hướng dẫn vay vốn ngân hàng, hưởng gói lãi suất ưu đãi ctừ 7,7% một năm trong 12 tháng.</p>\r\n\r\n<p>Prosper Plaza xây dựng trên khu đất rộng 15.585m2 gồm 3 Block. Theo đại diện chủ đầu tư, với quy mô 1.500 căn hộ diện tích trung bình 49-65-70m2, đây là một trong những dự án có thể đáp ứng nhu cầu đa dạng cho mọi đối tượng khách hàng là cư dân hay nhà đầu tư.</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Thế Đan</strong></p>\r\n','','no','[]','[]','1','0','0','2','1518281220','1519836675','25');
INSERT INTO olala_article VALUES('941','458','Bất động sản Đà Nẵng: Dòng tiền đổ vào đâu trong năm 2018','bat-dong-san-da-nang-dong-tien-do-vao-dau-trong-nam-2018','','','','bat-dong-san-da-nang-dong-tien-do-vao-dau-trong-nam-2018-1519836977.jpg','','','0','0','0','0','0','2410','Đánh giá về triển vọng thị trường bất động sản năm 2018, giới chuyên môn cho rằng diễn biến sẽ tiếp tục đà khả quan, tuy nhiên, phân khúc căn hộ sẽ phải cạnh tranh rất khốc liệt, thị trường đất nền sẽ lên ngôi.','<p 20px=\"\" color:=\"\" font-size:=\"\" line-height:=\"\" new=\"\" text-align:=\"\" times=\"\">Theo giới phân tích, tại Đà Nẵng khu vực có tiềm năng phát triển nhất là Tây Bắc bởi nơi này đang hội tụ đủ các điều kiện tăng trưởng bền vững.</p>\r\n\r\n<p 20px=\"\" color:=\"\" font-size:=\"\" line-height:=\"\" new=\"\" text-align:=\"\" times=\"\">Mới đây, tập đoàn khách sạn Mikazuki từ Nhật Bản dự kiến sẽ đầu tư hơn 100 triệu USD để xây dựng công viên nước và khách sạn 5 sao tại khu du lịch Xuân Thiều nằm trên cung đường biển xanh Nguyễn Tất Thành thuộc phía Tây Bắc Đà Nẵng. Dự án này có diện tích gần 13ha nhằm mục tiêu đầu tư phát triển khu phức hợp dịch vụ bao gồm khách sạn đạt chuẩn 5 sao, khu công viên nước, công viên trò chơi và khu ẩm thực. Đây được xem là khoản đầu tư nước ngoài lớn nhất vào bất động sản du lịch Đà Nẵng năm 2017, năm đánh dấu sự kiện quốc tế APEC mở ra một cơ hội cực lớn về thu hút đầu tư cho địa phương.</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"Khách sạn 5 sao dự kiến sẽ xây dựng tại khu du lịch Xuân Thiều nằm trên cung đường biển Tất Thành Đà Nẵng\" data-original=\"https://dantricdn.com/2017/h1-1513670344360.jpg\" h=\"1024\" id=\"img_216212\" photoid=\"216212\" rel=\"https://dantricdn.com/2017/h1-1513670344360.jpg\" src=\"/uploads/images/2018/02/h1-1513670344360.jpg\" style=\"max-width: 100%;\" type=\"photo\" w=\"2000\" /><br />\r\n<em>Khách sạn 5 sao dự kiến sẽ xây dựng tại khu du lịch Xuân Thiều nằm trên cung đường biển Tất Thành Đà Nẵng.</em></p>\r\n\r\n<p 20px=\"\" color:=\"\" font-size:=\"\" line-height:=\"\" new=\"\" text-align:=\"\" times=\"\">Nguồn vốn gần 1 tỉ USD đổ vào Đà Nẵng tại Diễn đàn đầu tư 2017 được kỳ vọng là động lực mới đẩy nhanh các dự án chưa triển khai ở Q.Liên Chiểu. Trong đó, cảng Liên Chiểu (7.378 tỉ đồng), di dời ga đường sắt và phát triển đô thị TP.Đà Nẵng (15.441 tỉ đồng)… sẽ biến phía tây vịnh Đà Nẵng thành khu kinh tế ven biển. Điển hình là Khu CNTT (Danang IT Park) với tổng vốn đầu tư gần 300 triệu USD đang hoàn thiện theo mô hình thung lũng Silicon. Đặc biệt, thông tin từ Sở Xây dựng Đà Nẵng cho biết trong tương lai, Thành phố sẽ mở rộng quy mô khu đô thị Tây Bắc lên khoảng 37.000ha để đáp ứng quy mô dân số trên 2 triệu người.</p>\r\n\r\n<p 20px=\"\" color:=\"\" font-size:=\"\" line-height:=\"\" new=\"\" text-align:=\"\" times=\"\">&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"Theo giới phân tích, đất nền Golden Hills đang được săn lùng do tiềm năng phát triển du lịch biển Nguyễn Tất Thành và khu vực Tây Bắc sẽ bứt phá trong tương lai\" data-original=\"https://dantricdn.com/2017/h2-1513670344362.jpeg\" h=\"1181\" id=\"img_216213\" photoid=\"216213\" rel=\"https://dantricdn.com/2017/h2-1513670344362.jpeg\" src=\"/uploads/images/2018/02/h2-1513670344362.jpg\" style=\"max-width: 100%;\" type=\"photo\" w=\"2000\" /><br />\r\n<em>Theo giới phân tích, đất nền Golden Hills đang được săn lùng do tiềm năng phát triển du lịch biển Nguyễn Tất Thành và khu vực Tây Bắc sẽ bứt phá trong tương lai.</em></p>\r\n\r\n<p 20px=\"\" color:=\"\" font-size:=\"\" line-height:=\"\" new=\"\" text-align:=\"\" times=\"\">Ngoài ra, án ngữ ngay cửa ngõ ra vào khu Tây Bắc Đà Nẵng là dự án khu đô thị Golden Hills có quy mô 400ha do tập đoàn Trung Nam đầu tư từ năm 2011. Theo tìm hiểu, hiện nay khu A dự án Golden Hills có quy mô 100ha đã hoàn thành giai đoạn 1 vào năm 2017 với nhiều tiện ích vượt trội và thu hút đông người dân đến sinh sống.</p>\r\n\r\n<p 20px=\"\" color:=\"\" font-size:=\"\" line-height:=\"\" new=\"\" text-align:=\"\" times=\"\">Giai đoạn 2, Trung Nam đầu tư xây dựng khu phức hợp DITP Power tại đầu tuyến đường Nguyễn Tất Thành nối dài với tổng vốn đầu tư 250 tỉ đồng, 18 tầng; tập trung thi công các khu còn lại và đặc biệt là chuỗi khu phố thương mại Nguyễn Tất Thành để tạo sự sôi động cho khu Tây Bắc Đà Nẵng.</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"Khu phức hợp DITP Power trên tuyến đường Nguyễn Tất Thành với tổng vốn đầu tư 250 tỷ đồng, 18 tầng đang được triển khai trong năm 2017\" data-original=\"https://dantricdn.com/2017/h3-1513670344364.jpg\" h=\"1481\" id=\"img_216214\" photoid=\"216214\" rel=\"https://dantricdn.com/2017/h3-1513670344364.jpg\" src=\"/uploads/images/2018/02/h3-1513670344364.jpg\" style=\"max-width: 100%;\" type=\"photo\" w=\"1737\" /><br />\r\n<em>Khu phức hợp DITP Power trên tuyến đường Nguyễn Tất Thành với tổng vốn đầu tư 250 tỷ đồng, 18 tầng đang được triển khai trong năm 2017</em></p>\r\n\r\n<p 20px=\"\" color:=\"\" font-size:=\"\" line-height:=\"\" new=\"\" text-align:=\"\" times=\"\">Ghi nhận cho thấy, xu hướng đầu tư đất nền tại các khu vực này là đi theo giá trị thực về nhà ở, người mua đất chủ yếu phục vụ cho nhu cầu ở thực. Hiện tại, giao dịch mua bán đất nền tại khu Tây Bắc vẫn đang diễn ra hết sức sôi động xoay quanh các sản phẩm đất nền có giá từ 1 tỷ đồng nằm trong khu đô thị được đầu tư hạ tầng tốt, kết nối thuận tiện với mạng lưới trường học, bệnh viện, không gian công cộng vui chơi, giải trí. Điều này là một chỉ dấu quan trọng, một mặt phản ánh nhu cầu cao của thị trường về đất, mặt khác cho thấy sự bền vững của giá trị phân khúc đất nền</p>\r\n\r\n<p 20px=\"\" color:=\"\" font-size:=\"\" line-height:=\"\" new=\"\" text-align:=\"\" times=\"\">Đánh giá về triển vọng thị trường BĐS Đà Nẵng, đặc biệt là phân khúc đất nền ông Marc Townsend - Nguyên Tổng giám đốc CBRE Việt Nam cho biết: \"Do tâm lý người dân vẫn ưa chuộng đất nền và nhà phố theo đúng tập tục sinh sống bao đời nay, nhất là phân khúc căn hộ chung cư chưa phải là thị hiếu của khách hàng khu vực miền trung. Phần khác, nhờ sự kiện APEC mà Đà Nẵng đã có một hệ thống hạ tầng giao thông khá quy mô, kết nối đồng bộ. Chính những yếu tố này sẽ kích thích thị trường địa ốc thành phố này tăng trưởng mạnh trong thời gian tới\".</p>\r\n\r\n<p 20px=\"\" color:=\"\" font-size:=\"\" line-height:=\"\" new=\"\" style=\"text-align: right;\" text-align:=\"\" times=\"\"><strong>Nguồn: Dantri.com.vn</strong></p>\r\n','','no','[]','[]','1','0','0','1','1515754800','1519836977','25');
INSERT INTO olala_article VALUES('944','458','Tây Bắc – “cực” phát triển mới của Đà Nẵng','tay-bac-cuc-phat-trien-moi-cua-da-nang','','','','tay-bac-cuc-phat-trien-moi-cua-da-nang-1519837908.jpg','','','0','0','0','0','0','2413','Theo ông Bùi Minh Trí, đại diện Sở Xây dựng Đà Nẵng, đối với sản phẩm đất nền tại một số dự án đang triển khai ở khu vực Tây Bắc, khi chủ đầu tư rao bán thì giao dịch khá tốt. Điều này chứng tỏ nhu cầu nhà ở của người dân khu vực là rất cao.','<p font-size:=\"\" new=\"\" times=\"\"><strong>Nhiều cú hích hỗ trợ</strong></p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\">Trước đây, nhắc đến bất động sản Đà Nẵng người ta thường nghĩ tới khu vực phía Nam thành phố, khu vực được kế thừa nền tảng đô thị cũ cũng như sự thuận lợi về điều kiện tự nhiên. Thế nhưng, với quỹ đất ở các khu trung tâm ngày càng khan hiếm, các nhà đầu tư trên thị trường địa ốc Đà Nẵng đang có xu hướng dịch chuyển sang các khu vực lân cận nhằm tìm kiếm cơ hội.</p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\">Theo đề án quy hoạch của thành phố Đà Nẵng đến năm 2020, Tây Bắc đang là hướng phát triển chiến lược của thành phố. Trong đó, quận Liên Chiểu hiện đang nổi lên như một điểm sáng với hệ thống kết cấu hạ tầng tiên tiến và thuận lợi để thu hút các nhà đầu tư trong và ngoài nước.</p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\">Để thực hiện đề án trên, Đà Nẵng đã triển khai hàng loạt công trình trọng điểm. Tháng 2/2017, 65km đầu tiên dự án đường cao tốc Đà Nẵng - Quảng Ngãi đã chính thức được thông xe kỹ thuật.</p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\">Các hạng mục còn lại của dự án cũng đang được gấp rút thi công để đưa toàn tuyến vào khai thác cuối năm 2017, tạo điều kiện thuận lợi cho các doanh nghiệp trong các khu công nghiệp Đà Nẵng, Quảng Nam và Quảng Ngãi vận chuyển hàng hóa. Tháng 5/2017, quận Liên Chiểu được công nhận đô thị loại 1 cấp quận. Đây là một bước tiến đáng kể trong việc phát triển kinh tế, xã hội cho toàn khu vực.</p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\">Một dự án lớn nữa là ga hàng hóa Kim Liên mới sẽ được xây dựng hơn 80ha, nằm trong tổng thể dự án di dời ga đường sắt Đà Nẵng với tổng mức đầu tư khoảng 5.700 tỷ đồng.</p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\">Đề nghị xây Cảng Liên Chiểu theo hình thức hợp tác công tư (PPP) cũng đã được Bộ Giao thông Vận tải thông qua. Các dự án này khi đi vào hoạt động sẽ tạo động lực phát triển kinh tế và thu hút đông đảo lực lượng người lao động tới định cư tại khu vực này.</p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\">Bên cạnh đó, với lợi thế nằm ngay điểm giao thông Cầu Vượt Ngã Ba Huế, nối liền Quốc Lộ 1A đi vào trung tâm của Thành Phố, một mặt lại giáp biển Nguyễn Tất Thành, khu Tây Bắc thành phố trở thành vùng đất mới đầy lực hấp dẫn, thu hút các doanh nghiệp, nhà đầu tư cá nhân đổ về săn đất.</p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\"><strong>Hạ tầng đi trước, dự án theo sau</strong></p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\">Anh Thịnh, một môi giới bất động sản ở Đà Nẵng cho biết, bất động sản luôn phát triển sau hạ tầng một bước. Vì thế với hàng loạt dự án hạ tầng được đầu tư ở phía Tây Bắc thời gian qua, làn sóng đầu tư địa ốc theo các dự án nghìn tỷ diễn ra ở khu vực này cũng là điều dễ hiểu.</p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\">Bên cạnh những ưu thế về hạ tầng, về những dự án nghìn tỷ sắp được triển khai, khu vực Tây Bắc Đà Nẵng là một vùng đất được thiên nhiên ưu đãi bên sông, kề núi, cạnh biển, cách trung tâm thành phố chỉ 15 phút di chuyển. Do đó, khu vực này được đánh giá sẽ là mảnh đất tiềm năng thu hút người dân, các chuyên gia làm việc tại các khu lân cận, các trường đại học, các công ty nước ngoài đến làm việc, sinh sống và nghỉ dưỡng.</p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\">Những sự thay đổi này đã ít nhiều phát huy tác dụng, kích hoạt hàng loạt các dự án bất động sản cùng chuyển động. Nhiều ông lớn trong ngành bất động sản cũng đã nhanh chân góp mặt tại vùng đất mới này với một số dự án điển hình như: Pandora City và Lakeside Palace, Golden Hills, Khu đô thị Phước Lý, Chăm Riverpark.</p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\">Giới đầu tư bất động sản cho rằng, ngoài đòn bẩy hạ tầng và những dự án lớn, khu Tây Bắc thành phố được nhiều doanh nghiệp bất động sản chú ý bởi quỹ đất khu vực này còn nhiều. Vì chưa phát triển mạnh nên giá cả khá mềm so với mặt bằng chung, phù hợp với túi tiền của nhiều người.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"Cầu vượt ngã ba Huế nối liền nhiều tuyến đường trọng điểm của thành phố.\" data-original=\"http://channel.mediacdn.vn/prupload/270/2017/10/img20171018110121161.jpg\" src=\"/uploads/images/2018/02/img20171018110121161.jpg\" style=\"max-width: 100%;\" type=\"photo\" /><br />\r\n<em>Cầu vượt ngã ba Huế nối liền nhiều tuyến đường trọng điểm của thành phố.</em></p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\">Chính vì vậy, nếu như khu vực phía Nam thành phố là thiên đường của các dự án bất động sản phục vụ nhu cầu đầu tư và nghỉ dưỡng thì khu vực Tây Bắc lại là địa bàn tập trung nhiều dự án đáp ứng nhu cầu ở thực của người dân Đà Nẵng và người dân ở các tỉnh lân cận đang sinh sống và làm việc tại Đà Nẵng.</p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\">Hiện nay ngoài những khu đất bố trí tái định cư thì thành phố đang đấu giá những khu đất còn trống và nhu cầu người mua là rất cao. Trong năm 2017 thành phố tổ chức đấu giá rất nhiều khu đất nền.</p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\">Nhu cầu đấu giá cũng rất lớn, đối với cả khách hàng là cư dân Đà Nẵng cũng như khách hàng từ các tỉnh khác. Đối với sản phẩm đất nền tại một số dự án đang triển khai ở khu vực Tây Bắc, khi chủ đầu tư rao bán thì giao dịch khá tốt. Điều này chứng tỏ nhu cầu nhà ở của người dân khu vực là rất cao.</p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\">Chứng kiến những bước chuyển mình của Tây Bắc thì mới hiểu được sự tỉnh giấc và vươn mình lớn dậy của khu vực này cùng những tác động của nó tới sự phát triển kinh tế - xã hội toàn diện của Đà Nẵng.</p>\r\n\r\n<p font-size:=\"\" new=\"\" times=\"\">Sự bài bản trong quy hoạch, kiến trúc, đầu tư hạ tầng đô thị, những lợi thế về vị trí, tầm nhìn phát triển kinh tế trong tương lai, kết nối thân thiện, sự hình thành các khu đô thị mới khang trang… tất cả các yếu tố trên đều đang tạo sức lan tỏa cho khu vực Tây Bắc, mở ra nhiều cơ hội, mang lại những lợi ích to lớn mà người dân Đà Nẵng là đối tượng thụ hưởng chính.</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Trích: Cafe F</strong></p>\r\n','','no','[]','[]','1','0','0','1','1515345000','1519837908','25');
INSERT INTO olala_article VALUES('945','455','Golden Hills','golden-hills','','','','golden-hills-1519839229.jpg','','Nguyễn Tất Thành, Liên Chiểu, Đà Nẵng','1270000000','0','0','0','2','2414','Đến và ngất ngây trước vẻ đẹp thiên nhiên, SOM – Công ty thiết kế qui hoạch hàng đầu của Hoa Kỳ, đã kiến tạo nên khu đô thị sinh thái Golden Hills mang bản sắc riêng,  có quy hoạch kiến trúc bậc nhất tại miền Trung.','<p>Hòa điệu cùng thiên nhiên kết hợp với thiết kế hiện đại đẳng cấp Quốc tế</p>\r\n\r\n<p>Xây dựng khu đô thị sinh thái Golden Hills có kết cấu phát triển bền vững.</p>\r\n\r\n<h3>Tránh ảnh hưởng của thủy triều dâng hay ngập lụt từ thượng nguồn bằng cách:</h3>\r\n\r\n<ul>\r\n	<li>Nâng đất nền</li>\r\n	<li>Thiết kế những bức tường chắn sóng nước dâng tạo thành đồi</li>\r\n</ul>\r\n\r\n<p>Do đó tạo được cảnh quan và chắn ngập lụt nhưng vẫn không phá vỡ cảnh quan chung của cả dự án.</p>\r\n\r\n<h3>Có khá nhiều kênh rạch:</h3>\r\n\r\n<ul>\r\n	<li>Thiết kế tận dụng tối đa dòng chảy tự nhiên.</li>\r\n	<li>Tạo những kênh rạch ngay trong thành phố.</li>\r\n</ul>\r\n\r\n<p>Những kênh rạch này sẽ đóng vai trò điều tiết dòng chảy trong dự án.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><u>Phác họa:</u></h2>\r\n\r\n<p><u><img alt=\"\" src=\"/uploads/images/2018/02/1.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/2.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/3.jpg\" style=\"max-width: 100%;\" /></u></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><u>Tiêu chuẩn thiết kế:</u></h2>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/2018/02/-173.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/-175.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/-177.jpg\" style=\"max-width: 100%;\" /></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><u>Minh họa:</u></h2>\r\n\r\n<p><u><img alt=\"\" src=\"/uploads/images/2018/02/minhhoa_1_1.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/minhhoa_2.jpg\" style=\"max-width: 100%;\" /><br />\r\n<img alt=\"\" src=\"/uploads/images/2018/02/minhhoa_3.jpg\" style=\"max-width: 100%;\" /></u></p>\r\n','','no','[]','[]','1','0','0','7','1519493040','1519839229','25');

-- --------------------------------------------------------

CREATE TABLE `olala_article_menu` (
  `article_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `comment` text NOT NULL,
  `icon` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`article_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=467 DEFAULT CHARSET=utf8;

INSERT INTO olala_article_menu VALUES('455','89','Biệt thự nghỉ dưỡng','biet-thu-nghi-duong','','','','0','7','','','1','0','no','1516138087','1519808422','25');
INSERT INTO olala_article_menu VALUES('454','89','Khu dân cư','khu-dan-cu','','','','0','5','','','1','0','no','1516138077','1519808411','1');
INSERT INTO olala_article_menu VALUES('453','89','Khu đô thị','khu-do-thi','','','','0','4','','','1','0','no','1516138068','1519808405','1');
INSERT INTO olala_article_menu VALUES('452','89','Dự án đất nền','du-an-dat-nen','','','','0','3','','','1','0','no','1516138002','1519808400','1');
INSERT INTO olala_article_menu VALUES('433','97','Cảnh quan','canh-quan','','','','0','2','','Nội thất','1','0','no','1512182527','1513524310','25');
INSERT INTO olala_article_menu VALUES('428','94','Về chúng tôi','ve-chung-toi','','','','0','1','','','1','0','no','1512182375','1512313435','25');
INSERT INTO olala_article_menu VALUES('457','89','Căn hộ chung cư','can-ho-chung-cu','','','','0','2','','','1','0','no','1516138116','1519808397','1');
INSERT INTO olala_article_menu VALUES('456','89','Khu tái định cư','khu-tai-dinh-cu','','','','0','6','','','1','0','no','1516138095','1516138095','1');
INSERT INTO olala_article_menu VALUES('432','97','Toà nhà','toa-nha','','','','0','1','','Kiến trúc','1','0','no','1512182514','1514791780','1');
INSERT INTO olala_article_menu VALUES('458','96','Bản tin bất động sản','ban-tin-bat-dong-san','','','','0','1','','','1','0','no','1516138144','1516138144','1');
INSERT INTO olala_article_menu VALUES('459','96','Thông tin nhà đất','thong-tin-nha-dat','','','','0','2','','','1','0','no','1516138161','1516138161','1');
INSERT INTO olala_article_menu VALUES('460','96','Tin hoạt động','tin-hoat-dong','','','','0','4','','','1','0','no','1516138172','1516138260','1');
INSERT INTO olala_article_menu VALUES('461','96','Tin tuyển dụng','tin-tuyen-dung','','','','0','5','','','1','0','no','1516138182','1516138264','1');
INSERT INTO olala_article_menu VALUES('462','96','Tin dự án','tin-du-an','','','','0','3','','','1','0','no','1516138249','1516138256','1');
INSERT INTO olala_article_menu VALUES('466','89','Nhà phố - Nhà mặt tiền','nha-pho-nha-mat-tien','','','','0','1','','','1','0','no','1519808388','1519808393','25');

-- --------------------------------------------------------

CREATE TABLE `olala_car` (
  `car_id` int(11) NOT NULL AUTO_INCREMENT,
  `car_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `upload_id` bigint(20) NOT NULL,
  `model` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `seat` varchar(255) NOT NULL,
  `seat_sort` int(11) NOT NULL DEFAULT '0',
  `color` varchar(255) NOT NULL,
  `price` bigint(15) NOT NULL,
  `sale` int(3) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `content` longtext NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`car_id`)
) ENGINE=MyISAM AUTO_INCREMENT=312 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_car_menu` (
  `car_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `comment` text NOT NULL,
  `icon` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`car_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=188 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(30) NOT NULL,
  `plus` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `comment` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `menu_main` int(1) NOT NULL DEFAULT '0',
  `sort_hide` int(11) NOT NULL DEFAULT '1',
  `menu_sm` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `icon` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=102 DEFAULT CHARSET=utf8;

INSERT INTO olala_category VALUES('89','1','Dự án','du-an','','','','','','1','1','2','1','2','1','no','','0','1516138386','1');
INSERT INTO olala_category VALUES('91','2','Slider','slider','','','','','','1','0','1','0','0','0','no','','0','0','0');
INSERT INTO olala_category VALUES('95','15','Thành phố','city','','','','','','1','0','2','0','0','0','no','','0','1516987394','1');
INSERT INTO olala_category VALUES('94','1','Giới thiệu','gioi-thieu','','','','','','1','0','1','1','1','1','no','','0','1516037693','25');
INSERT INTO olala_category VALUES('99','6','Nhà đất bán','nha-dat-ban','','','','','','1','0','1','1','3','0','no','','0','1518025049','1');
INSERT INTO olala_category VALUES('96','1','Tin tức','blog','','','','','','1','1','3','1','6','1','no','','0','1519837082','25');
INSERT INTO olala_category VALUES('101','6','Nhà đất cho thuê','cho-thue','','','','','','1','0','3','1','5','0','no','','0','1518025055','1');
INSERT INTO olala_category VALUES('88','15','Trường bổ sung','plus','','','','','','1','0','1','0','1','0','no','','0','0','0');

-- --------------------------------------------------------

CREATE TABLE `olala_category_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(30) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO olala_category_type VALUES('1','Bài viết','article_manager','1','1');
INSERT INTO olala_category_type VALUES('2','Hình ảnh','gallery_manager','2','1');
INSERT INTO olala_category_type VALUES('7','Đăng ký thông tin','newsletter','9','1');
INSERT INTO olala_category_type VALUES('6','Sản phẩm','product_manager','3','1');
INSERT INTO olala_category_type VALUES('8','Booking online','order_list','7','0');
INSERT INTO olala_category_type VALUES('9','Tour du lịch','tour_manager','5','0');
INSERT INTO olala_category_type VALUES('10','Đồ lưu niệm','gift_manager','0','0');
INSERT INTO olala_category_type VALUES('11','Thuê xe','car_manager','6','0');
INSERT INTO olala_category_type VALUES('12','Vị trí địa lý','location_manager','0','0');
INSERT INTO olala_category_type VALUES('13','Dữ liệu đường phố','street_manager','0','0');
INSERT INTO olala_category_type VALUES('14','Dữ liệu phương hướng','direction_manager','0','0');
INSERT INTO olala_category_type VALUES('15','Dữ liệu khác','others_manager','4','1');
INSERT INTO olala_category_type VALUES('16','Chiều rộng đường','road_manager','0','0');
INSERT INTO olala_category_type VALUES('17','Dự án','project_manager','0','0');
INSERT INTO olala_category_type VALUES('18','BĐS kinh doanh','bds_business_manager','0','0');
INSERT INTO olala_category_type VALUES('19','Dữ liệu tên dự án','prjname_manager','0','0');
INSERT INTO olala_category_type VALUES('20','Thư liên hệ','contact_list','8','1');
INSERT INTO olala_category_type VALUES('21','Văn bản / Tài liệu','document_manager','3','0');
INSERT INTO olala_category_type VALUES('22','Khách hàng','customer_list','10','0');

-- --------------------------------------------------------

CREATE TABLE `olala_constant` (
  `constant_id` int(11) NOT NULL AUTO_INCREMENT,
  `constant` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` int(2) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`constant_id`)
) ENGINE=MyISAM AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;

INSERT INTO olala_constant VALUES('1','date','d/m/Y','Kiểu hiển thị ngày tháng năm','3','1');
INSERT INTO olala_constant VALUES('2','time','H:i','Kiểu hiển thị giờ phút','3','2');
INSERT INTO olala_constant VALUES('3','timezone','Asia/Bangkok','Múi giờ','3','4');
INSERT INTO olala_constant VALUES('4','title','Nhà phố Đà Nẵng - Trang thông tin bất động sản Đà Nẵng','Title (trang chủ)','0','1');
INSERT INTO olala_constant VALUES('5','description','Kênh thông tin mua bán nhà đất tại Đà Nẵng, thông tin về: mua bán nhà đất, cho thuê nhà đất, văn phòng, căn hộ và các lĩnh vực bất động sản.','Description (trang chủ)','0','2');
INSERT INTO olala_constant VALUES('6','keywords','Nhà phố Đà Nẵng,Bất động sản Đà Nẵng,mua bán nhà đất,cho thuê nhà đất,văn phòng,căn hộ,bất động sản,nhà đất Đà Nẵng,nhaphodanang.com.vn,nhaphodanang,NhaPhoDaNang.com.vn','Keywords (trang chủ)','0','3');
INSERT INTO olala_constant VALUES('74','script_body','<div id=\"fb-root\"></div>\r\n<script>(function(d, s, id) {\r\n  var js, fjs = d.getElementsByTagName(s)[0];\r\n  if (d.getElementById(id)) return;\r\n  js = d.createElement(s); js.id = id;\r\n  js.src = \"//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.5\";\r\n  fjs.parentNode.insertBefore(js, fjs);\r\n}(document, \'script\', \'facebook-jssdk\'));</script>\r\n','Script sau body','4','6');
INSERT INTO olala_constant VALUES('76','link_linkedin','','LinkedIn','5','6');
INSERT INTO olala_constant VALUES('7','email_contact','huyto.qng@gmail.com','Email','0','8');
INSERT INTO olala_constant VALUES('8','tell_contact','0974 779 085','Điện thoại','0','9');
INSERT INTO olala_constant VALUES('9','fulldate','D, d/m/Y','Kiểu hiển ngày đầy đủ','3','3');
INSERT INTO olala_constant VALUES('10','SMTP_username','olala.3w@gmail.com','Tài khoản email','1','0');
INSERT INTO olala_constant VALUES('11','SMTP_password','cdreodvwrbpbugso','Mật khẩu email','1','0');
INSERT INTO olala_constant VALUES('12','error_page','<p>Vì lý do kỹ&nbsp;thuật website tạm ngưng&nbsp;hoạt động. Thành thật xin lỗi các bạn&nbsp;vì sự bất tiện này!</p>\r\n','Thông báo ngừng hoạt động','0','19');
INSERT INTO olala_constant VALUES('13','file_logo','/uploads/images/site/logo.png','Logo front-end','0','4');
INSERT INTO olala_constant VALUES('14','SMTP_secure','ssl','Sử dụng xác thực','1','0');
INSERT INTO olala_constant VALUES('15','SMTP_host','smtp.gmail.com','Máy chủ (SMTP) Thư gửi đi','1','0');
INSERT INTO olala_constant VALUES('16','SMTP_port','465','Cổng gửi mail','1','0');
INSERT INTO olala_constant VALUES('17','backup_auto','','Tự động sao lưu','2','0');
INSERT INTO olala_constant VALUES('18','backup_filetype','sql.gz','Định dạng lưu file CSDL','2','0');
INSERT INTO olala_constant VALUES('19','backup_filecount','5','Số file CSDL lưu lại','2','0');
INSERT INTO olala_constant VALUES('20','backup_email','olala.3w@gmail.com','Email nhận thông báo và file','2','0');
INSERT INTO olala_constant VALUES('21','SMTP_mailname','Nhà phố Đà Nẵng | NhaPhoDaNang.com.vn','Tên tài khoản email','1','0');
INSERT INTO olala_constant VALUES('22','link_facebook','https://www.facebook.com','Facebook','5','1');
INSERT INTO olala_constant VALUES('23','link_googleplus','https://plus.google.com','Google+','5','3');
INSERT INTO olala_constant VALUES('24','link_twitter','https://twitter.com','Twitter','5','4');
INSERT INTO olala_constant VALUES('25','address_contact','Đà Nẵng, Việt Nam','Địa chỉ','0','11');
INSERT INTO olala_constant VALUES('73','script_bottom','<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?\'http\':\'https\';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+\'://platform.twitter.com/widgets.js\';fjs.parentNode.insertBefore(js,fjs);}}(document, \'script\', \'twitter-wjs\');</script>\r\n<script src=\"https://apis.google.com/js/platform.js\" async defer>\r\n  {lang: \'vi\'}\r\n</script>\r\n','Script cuối trang','4','7');
INSERT INTO olala_constant VALUES('26','content_registertry','','Email đăng ký học thử','13','17');
INSERT INTO olala_constant VALUES('27','author_google','','ID profile Google+','4','1');
INSERT INTO olala_constant VALUES('28','google_analytics','','Google analytics','4','4');
INSERT INTO olala_constant VALUES('29','chat_online','','Script Chat Online','4','5');
INSERT INTO olala_constant VALUES('30','english_test','','Kiểm tra tiếng Anh của bạn','13','18');
INSERT INTO olala_constant VALUES('31','google_calendar','','Google Calendar (Account)','4','3');
INSERT INTO olala_constant VALUES('32','help_address','killlllme@gmail.com,0974.779.085,huy.to.bsn,mr.killlllme','Tư vấn - Địa chỉ','13','8');
INSERT INTO olala_constant VALUES('33','help_icon','fa-envelope-o,fa-phone,fa-skype,fa-facebook','Tư vấn - Icon','13','9');
INSERT INTO olala_constant VALUES('34','link_youtube','','Youtube','5','5');
INSERT INTO olala_constant VALUES('35','search_destination','Hà Nội,Đà Nẵng,Hồ Chí Minh,Phú Quốc,Nha Trang,Hạ Long,Đà Lạt,Phong Nha Kẻ Bàng,Côn đảo Vũng Tàu,Thái Lan,Singapore,Malaysia,Campuchia,Trung Quốc,Nhật Bản,Hàn Quốc,Hà Lan,Myanmar,Úc,Hong Kong,Philippines,Indonesia,Đài Loan,Châu Á,Châu Âu,Châu Mỹ,Châu Phi,Châu Úc','Điểm đến (Tìm kiếm tour)','13','8');
INSERT INTO olala_constant VALUES('36','search_day','1 Ngày,1 Ngày 1 Đêm,2 Ngày,2 Ngày 1 Đêm,3 Ngày,3 Ngày 2 Đêm,4 Ngày,4 Ngày 3 Đêm,5 Ngày,5 Ngày 4 Đêm,6 Ngày,6 Ngày 5 Đêm,7 Ngày,7 Ngày 6 Đêm,8 Ngày,8 Ngày 7 Đêm,9 Ngày,9 Ngày 8 Đêm,10 Ngày,10 Ngày 9 Đêm,11 Ngày,11 Ngày 10 Đêm,12 Ngày,12 Ngày 11 Đêm,1 Tuần,2 Tuần,3 Tuần,1 Tháng,2 Tháng,3 Tháng','Thời gian (Tìm kiếm tour)','13','9');
INSERT INTO olala_constant VALUES('75','fb_app_id','','Facebook App ID','4','2');
INSERT INTO olala_constant VALUES('77','upload_img_max_w','1900','Kích thước ảnh tối đa','6','1');
INSERT INTO olala_constant VALUES('78','upload_max_size','52428800','Dung lượng tối đa','6','2');
INSERT INTO olala_constant VALUES('79','upload_checking_mode','mild','Kiểu kiểm tra file tải lên','6','3');
INSERT INTO olala_constant VALUES('80','upload_type','1,4,5,6,7,8,9,10,11','Loại files cho phép','6','4');
INSERT INTO olala_constant VALUES('81','upload_ext','','Phần mở rộng bị cấm','6','5');
INSERT INTO olala_constant VALUES('82','upload_mime','','Loại mime bị cấm','6','6');
INSERT INTO olala_constant VALUES('83','upload_img_max_h','594','Kích thước ảnh tối đa','6','1');
INSERT INTO olala_constant VALUES('84','upload_auto_resize','1','Tự động resize ảnh','6','1');
INSERT INTO olala_constant VALUES('85','article_author','','Property = article:author','4','2');
INSERT INTO olala_constant VALUES('86','meta_author','Nhà phố Đà Nẵng | NhaPhoDaNang.com.vn','Meta author','0','4');
INSERT INTO olala_constant VALUES('88','meta_site_name','Nhà phố Đà Nẵng | NhaPhoDaNang.com.vn','Meta site name','0','5');
INSERT INTO olala_constant VALUES('89','meta_copyright','Copyright © 2018 Nhà phố Đà Nẵng | NhaPhoDaNang.com.vn','Meta copyright','0','6');
INSERT INTO olala_constant VALUES('90','image_thumbnailUrl','/uploads/images/site/Bat-dong-san-Nha-pho-Da-Nang.jpg','Image : thumbnailUrl','0','7');
INSERT INTO olala_constant VALUES('91','skype_contact','skype_nhaphodanang','Skype','0','10');
INSERT INTO olala_constant VALUES('92','link_instagram','https://www.instagram.com','Instagram','5','2');

-- --------------------------------------------------------

CREATE TABLE `olala_contact` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `content` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `ip` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL DEFAULT 'fa-send-o',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_core_privilege` (
  `privilege_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(30) NOT NULL,
  `privilege_slug` varchar(50) NOT NULL,
  PRIMARY KEY (`privilege_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4869 DEFAULT CHARSET=utf8;

INSERT INTO olala_core_privilege VALUES('2250','1','direction','direction_del');
INSERT INTO olala_core_privilege VALUES('2249','1','direction','direction_edit');
INSERT INTO olala_core_privilege VALUES('2248','1','direction','direction_add');
INSERT INTO olala_core_privilege VALUES('2255','1','pages','plugin_page_edit');
INSERT INTO olala_core_privilege VALUES('1071','1','backup','backup_config');
INSERT INTO olala_core_privilege VALUES('1545','1','config','config_search');
INSERT INTO olala_core_privilege VALUES('4825','1','tool','tool_ipdie');
INSERT INTO olala_core_privilege VALUES('4824','1','tool','tool_keywords');
INSERT INTO olala_core_privilege VALUES('2656','1','bds_business','bds_business_del;50');
INSERT INTO olala_core_privilege VALUES('2103','2','product','product_menu_add;37');
INSERT INTO olala_core_privilege VALUES('2102','2','product','category_edit;37');
INSERT INTO olala_core_privilege VALUES('2101','2','article','article_del;13');
INSERT INTO olala_core_privilege VALUES('2100','2','article','article_edit;13');
INSERT INTO olala_core_privilege VALUES('2099','2','article','article_add;13');
INSERT INTO olala_core_privilege VALUES('2098','2','article','article_list;13');
INSERT INTO olala_core_privilege VALUES('2097','2','article','article_menu_del;13');
INSERT INTO olala_core_privilege VALUES('2096','2','article','article_menu_edit;13');
INSERT INTO olala_core_privilege VALUES('2095','2','article','article_menu_add;13');
INSERT INTO olala_core_privilege VALUES('2094','2','article','category_edit;13');
INSERT INTO olala_core_privilege VALUES('2093','2','article','article_del;9');
INSERT INTO olala_core_privilege VALUES('2092','2','article','article_edit;9');
INSERT INTO olala_core_privilege VALUES('2091','2','article','article_add;9');
INSERT INTO olala_core_privilege VALUES('2090','2','article','article_list;9');
INSERT INTO olala_core_privilege VALUES('2089','2','article','article_menu_del;9');
INSERT INTO olala_core_privilege VALUES('2088','2','article','article_menu_edit;9');
INSERT INTO olala_core_privilege VALUES('2087','2','article','article_menu_add;9');
INSERT INTO olala_core_privilege VALUES('2086','2','article','category_edit;9');
INSERT INTO olala_core_privilege VALUES('273','2','gallery','gallery_menu_add;6');
INSERT INTO olala_core_privilege VALUES('274','2','gallery','gallery_menu_edit;6');
INSERT INTO olala_core_privilege VALUES('275','2','gallery','gallery_menu_del;6');
INSERT INTO olala_core_privilege VALUES('276','2','gallery','gallery_add;6');
INSERT INTO olala_core_privilege VALUES('277','2','gallery','gallery_edit;6');
INSERT INTO olala_core_privilege VALUES('278','2','gallery','gallery_del;6');
INSERT INTO olala_core_privilege VALUES('279','2','pages','pages_add');
INSERT INTO olala_core_privilege VALUES('280','2','pages','pages_edit');
INSERT INTO olala_core_privilege VALUES('281','2','pages','pages_del');
INSERT INTO olala_core_privilege VALUES('287','2','backup','backup_data');
INSERT INTO olala_core_privilege VALUES('288','2','backup','backup_config');
INSERT INTO olala_core_privilege VALUES('289','2','config','config_general');
INSERT INTO olala_core_privilege VALUES('290','2','config','config_search');
INSERT INTO olala_core_privilege VALUES('291','2','config','config_ipdie');
INSERT INTO olala_core_privilege VALUES('292','2','config','config_upload');
INSERT INTO olala_core_privilege VALUES('293','2','tool','tool_delete');
INSERT INTO olala_core_privilege VALUES('294','2','tool','tool_site');
INSERT INTO olala_core_privilege VALUES('295','2','tool','tool_keywords');
INSERT INTO olala_core_privilege VALUES('296','2','tool','tool_update');
INSERT INTO olala_core_privilege VALUES('330','2','core','core_mail');
INSERT INTO olala_core_privilege VALUES('2655','1','bds_business','bds_business_edit;50');
INSERT INTO olala_core_privilege VALUES('2654','1','bds_business','bds_business_add;50');
INSERT INTO olala_core_privilege VALUES('1070','1','backup','backup_data');
INSERT INTO olala_core_privilege VALUES('1544','1','config','config_socialnetwork');
INSERT INTO olala_core_privilege VALUES('4823','1','tool','tool_site');
INSERT INTO olala_core_privilege VALUES('4822','1','tool','tool_delete');
INSERT INTO olala_core_privilege VALUES('3333','1','core','core_dashboard');
INSERT INTO olala_core_privilege VALUES('2653','1','bds_business','bds_business_list;50');
INSERT INTO olala_core_privilege VALUES('3331','1','core','core_role');
INSERT INTO olala_core_privilege VALUES('1543','1','config','config_plugins');
INSERT INTO olala_core_privilege VALUES('3332','1','core','core_user');
INSERT INTO olala_core_privilege VALUES('2254','1','pages','plugin_page_add');
INSERT INTO olala_core_privilege VALUES('2252','1','street','street_edit');
INSERT INTO olala_core_privilege VALUES('2251','1','street','street_add');
INSERT INTO olala_core_privilege VALUES('2208','1','location','location_del;40');
INSERT INTO olala_core_privilege VALUES('2207','1','location','location_edit;40');
INSERT INTO olala_core_privilege VALUES('2206','1','location','location_add;40');
INSERT INTO olala_core_privilege VALUES('2205','1','location','location_list;40');
INSERT INTO olala_core_privilege VALUES('2204','1','location','location_menu_del;40');
INSERT INTO olala_core_privilege VALUES('2203','1','location','location_menu_edit;40');
INSERT INTO olala_core_privilege VALUES('2202','1','location','location_menu_add;40');
INSERT INTO olala_core_privilege VALUES('2201','1','location','category_edit;40');
INSERT INTO olala_core_privilege VALUES('4821','1','tool','tool_ckfinder');
INSERT INTO olala_core_privilege VALUES('1542','1','config','config_datetime');
INSERT INTO olala_core_privilege VALUES('1541','1','config','config_smtp');
INSERT INTO olala_core_privilege VALUES('1540','1','config','config_general');
INSERT INTO olala_core_privilege VALUES('1546','1','config','config_upload');
INSERT INTO olala_core_privilege VALUES('2200','1','location','location_del;39');
INSERT INTO olala_core_privilege VALUES('2198','1','location','location_add;39');
INSERT INTO olala_core_privilege VALUES('2199','1','location','location_edit;39');
INSERT INTO olala_core_privilege VALUES('2197','1','location','location_list;39');
INSERT INTO olala_core_privilege VALUES('2195','1','location','location_menu_edit;39');
INSERT INTO olala_core_privilege VALUES('2196','1','location','location_menu_del;39');
INSERT INTO olala_core_privilege VALUES('2194','1','location','location_menu_add;39');
INSERT INTO olala_core_privilege VALUES('4800','1','article','category_edit;96');
INSERT INTO olala_core_privilege VALUES('3983','1','tour','tour_del;70');
INSERT INTO olala_core_privilege VALUES('3982','1','tour','tour_edit;70');
INSERT INTO olala_core_privilege VALUES('3981','1','tour','tour_add;70');
INSERT INTO olala_core_privilege VALUES('3980','1','tour','tour_list;70');
INSERT INTO olala_core_privilege VALUES('3979','1','tour','tour_menu_del;70');
INSERT INTO olala_core_privilege VALUES('3978','1','tour','tour_menu_edit;70');
INSERT INTO olala_core_privilege VALUES('3977','1','tour','tour_menu_add;70');
INSERT INTO olala_core_privilege VALUES('3976','1','tour','category_edit;70');
INSERT INTO olala_core_privilege VALUES('1712','1','gift','gift_add;22');
INSERT INTO olala_core_privilege VALUES('1711','1','gift','gift_list;22');
INSERT INTO olala_core_privilege VALUES('1710','1','gift','gift_menu_del;22');
INSERT INTO olala_core_privilege VALUES('1709','1','gift','gift_menu_edit;22');
INSERT INTO olala_core_privilege VALUES('1708','1','gift','gift_menu_add;22');
INSERT INTO olala_core_privilege VALUES('1707','1','gift','category_edit;22');
INSERT INTO olala_core_privilege VALUES('3838','1','car','car_list;67');
INSERT INTO olala_core_privilege VALUES('3837','1','car','car_menu_del;67');
INSERT INTO olala_core_privilege VALUES('3836','1','car','car_menu_edit;67');
INSERT INTO olala_core_privilege VALUES('3835','1','car','car_menu_add;67');
INSERT INTO olala_core_privilege VALUES('3834','1','car','category_edit;67');
INSERT INTO olala_core_privilege VALUES('1713','1','gift','gift_edit;22');
INSERT INTO olala_core_privilege VALUES('1714','1','gift','gift_del;22');
INSERT INTO olala_core_privilege VALUES('2193','1','location','category_edit;39');
INSERT INTO olala_core_privilege VALUES('3328','1','info','sys_info_expansion');
INSERT INTO olala_core_privilege VALUES('3327','1','info','sys_info_site');
INSERT INTO olala_core_privilege VALUES('4799','1','article','article_del;89');
INSERT INTO olala_core_privilege VALUES('2085','2','category','article_manager');
INSERT INTO olala_core_privilege VALUES('4841','1','product','product_menu_add;99');
INSERT INTO olala_core_privilege VALUES('2253','1','street','street_del');
INSERT INTO olala_core_privilege VALUES('2256','1','pages','plugin_page_del');
INSERT INTO olala_core_privilege VALUES('2290','1','road','road_add');
INSERT INTO olala_core_privilege VALUES('2291','1','road','road_edit');
INSERT INTO olala_core_privilege VALUES('2292','1','road','road_del');
INSERT INTO olala_core_privilege VALUES('2780','1','project','project_list;13');
INSERT INTO olala_core_privilege VALUES('2779','1','project','project_menu_del;13');
INSERT INTO olala_core_privilege VALUES('2778','1','project','project_menu_edit;13');
INSERT INTO olala_core_privilege VALUES('2777','1','project','project_menu_add;13');
INSERT INTO olala_core_privilege VALUES('2776','1','project','category_edit;13');
INSERT INTO olala_core_privilege VALUES('3841','1','car','car_del;67');
INSERT INTO olala_core_privilege VALUES('3840','1','car','car_edit;67');
INSERT INTO olala_core_privilege VALUES('3839','1','car','car_add;67');
INSERT INTO olala_core_privilege VALUES('4027','1','document','document_add;73');
INSERT INTO olala_core_privilege VALUES('2652','1','bds_business','bds_business_menu_del;50');
INSERT INTO olala_core_privilege VALUES('2651','1','bds_business','bds_business_menu_edit;50');
INSERT INTO olala_core_privilege VALUES('2650','1','bds_business','bds_business_menu_add;50');
INSERT INTO olala_core_privilege VALUES('2649','1','bds_business','category_edit;50');
INSERT INTO olala_core_privilege VALUES('2781','1','project','project_add;13');
INSERT INTO olala_core_privilege VALUES('2782','1','project','project_edit;13');
INSERT INTO olala_core_privilege VALUES('2783','1','project','project_del;13');
INSERT INTO olala_core_privilege VALUES('2784','1','project','category_edit;53');
INSERT INTO olala_core_privilege VALUES('2785','1','project','project_menu_add;53');
INSERT INTO olala_core_privilege VALUES('2786','1','project','project_menu_edit;53');
INSERT INTO olala_core_privilege VALUES('2787','1','project','project_menu_del;53');
INSERT INTO olala_core_privilege VALUES('2788','1','project','project_list;53');
INSERT INTO olala_core_privilege VALUES('2789','1','project','project_add;53');
INSERT INTO olala_core_privilege VALUES('2790','1','project','project_edit;53');
INSERT INTO olala_core_privilege VALUES('2791','1','project','project_del;53');
INSERT INTO olala_core_privilege VALUES('2792','9','category','product_manager');
INSERT INTO olala_core_privilege VALUES('2793','9','product','product_list;37');
INSERT INTO olala_core_privilege VALUES('2794','9','product','product_add;37');
INSERT INTO olala_core_privilege VALUES('2795','9','product','product_edit;37');
INSERT INTO olala_core_privilege VALUES('2796','9','product','product_del;37');
INSERT INTO olala_core_privilege VALUES('2797','11','category','article_manager');
INSERT INTO olala_core_privilege VALUES('2798','11','category','gallery_manager');
INSERT INTO olala_core_privilege VALUES('2799','11','category','project_manager');
INSERT INTO olala_core_privilege VALUES('2800','11','category','product_manager');
INSERT INTO olala_core_privilege VALUES('2801','11','category','location_manager');
INSERT INTO olala_core_privilege VALUES('2802','11','category','street_manager');
INSERT INTO olala_core_privilege VALUES('2803','11','category','road_manager');
INSERT INTO olala_core_privilege VALUES('2804','11','category','direction_manager');
INSERT INTO olala_core_privilege VALUES('2805','11','category','others_manager');
INSERT INTO olala_core_privilege VALUES('2806','11','category','plugin_page');
INSERT INTO olala_core_privilege VALUES('3031','11','article','article_menu_add;9');
INSERT INTO olala_core_privilege VALUES('3030','11','article','category_edit;9');
INSERT INTO olala_core_privilege VALUES('2809','11','config','config_socialnetwork');
INSERT INTO olala_core_privilege VALUES('2815','11','pages','plugin_page_del');
INSERT INTO olala_core_privilege VALUES('2814','11','pages','plugin_page_edit');
INSERT INTO olala_core_privilege VALUES('2813','11','pages','plugin_page_add');
INSERT INTO olala_core_privilege VALUES('2816','1','prjname','prjname_add');
INSERT INTO olala_core_privilege VALUES('2817','1','prjname','prjname_edit');
INSERT INTO olala_core_privilege VALUES('2818','1','prjname','prjname_del');
INSERT INTO olala_core_privilege VALUES('2830','12','category','article_manager');
INSERT INTO olala_core_privilege VALUES('2831','12','category','gallery_manager');
INSERT INTO olala_core_privilege VALUES('2832','12','category','project_manager');
INSERT INTO olala_core_privilege VALUES('2833','12','category','product_manager');
INSERT INTO olala_core_privilege VALUES('2834','12','category','location_manager');
INSERT INTO olala_core_privilege VALUES('2835','12','category','road_manager');
INSERT INTO olala_core_privilege VALUES('2836','12','category','street_manager');
INSERT INTO olala_core_privilege VALUES('2837','12','category','direction_manager');
INSERT INTO olala_core_privilege VALUES('2838','12','category','prjname_manager');
INSERT INTO olala_core_privilege VALUES('2839','12','category','others_manager');
INSERT INTO olala_core_privilege VALUES('2840','12','category','plugin_page');
INSERT INTO olala_core_privilege VALUES('2841','12','pages','plugin_page_add');
INSERT INTO olala_core_privilege VALUES('2842','12','pages','plugin_page_edit');
INSERT INTO olala_core_privilege VALUES('2843','12','pages','plugin_page_del');
INSERT INTO olala_core_privilege VALUES('4798','1','article','article_edit;89');
INSERT INTO olala_core_privilege VALUES('2908','12','article','category_edit;9');
INSERT INTO olala_core_privilege VALUES('2909','12','article','article_menu_add;9');
INSERT INTO olala_core_privilege VALUES('2910','12','article','article_menu_edit;9');
INSERT INTO olala_core_privilege VALUES('2911','12','article','article_menu_del;9');
INSERT INTO olala_core_privilege VALUES('2912','12','article','article_list;9');
INSERT INTO olala_core_privilege VALUES('2913','12','article','article_add;9');
INSERT INTO olala_core_privilege VALUES('2914','12','article','article_edit;9');
INSERT INTO olala_core_privilege VALUES('2915','12','article','article_del;9');
INSERT INTO olala_core_privilege VALUES('2916','12','article','category_edit;51');
INSERT INTO olala_core_privilege VALUES('2917','12','article','article_menu_add;51');
INSERT INTO olala_core_privilege VALUES('2918','12','article','article_menu_edit;51');
INSERT INTO olala_core_privilege VALUES('2919','12','article','article_menu_del;51');
INSERT INTO olala_core_privilege VALUES('2920','12','article','article_list;51');
INSERT INTO olala_core_privilege VALUES('2921','12','article','article_add;51');
INSERT INTO olala_core_privilege VALUES('2922','12','article','article_edit;51');
INSERT INTO olala_core_privilege VALUES('2923','12','article','article_del;51');
INSERT INTO olala_core_privilege VALUES('2924','12','article','category_edit;7');
INSERT INTO olala_core_privilege VALUES('2925','12','article','article_menu_add;7');
INSERT INTO olala_core_privilege VALUES('2926','12','article','article_menu_edit;7');
INSERT INTO olala_core_privilege VALUES('2927','12','article','article_menu_del;7');
INSERT INTO olala_core_privilege VALUES('2928','12','article','article_list;7');
INSERT INTO olala_core_privilege VALUES('2929','12','article','article_add;7');
INSERT INTO olala_core_privilege VALUES('2930','12','article','article_edit;7');
INSERT INTO olala_core_privilege VALUES('2931','12','article','article_del;7');
INSERT INTO olala_core_privilege VALUES('2932','12','project','category_edit;13');
INSERT INTO olala_core_privilege VALUES('2933','12','project','project_menu_add;13');
INSERT INTO olala_core_privilege VALUES('2934','12','project','project_menu_edit;13');
INSERT INTO olala_core_privilege VALUES('2935','12','project','project_menu_del;13');
INSERT INTO olala_core_privilege VALUES('2936','12','project','project_list;13');
INSERT INTO olala_core_privilege VALUES('2937','12','project','project_add;13');
INSERT INTO olala_core_privilege VALUES('2938','12','project','project_edit;13');
INSERT INTO olala_core_privilege VALUES('2939','12','project','project_del;13');
INSERT INTO olala_core_privilege VALUES('2940','12','project','category_edit;53');
INSERT INTO olala_core_privilege VALUES('2941','12','project','project_menu_add;53');
INSERT INTO olala_core_privilege VALUES('2942','12','project','project_menu_edit;53');
INSERT INTO olala_core_privilege VALUES('2943','12','project','project_menu_del;53');
INSERT INTO olala_core_privilege VALUES('2944','12','project','project_list;53');
INSERT INTO olala_core_privilege VALUES('2945','12','project','project_add;53');
INSERT INTO olala_core_privilege VALUES('2946','12','project','project_edit;53');
INSERT INTO olala_core_privilege VALUES('2947','12','project','project_del;53');
INSERT INTO olala_core_privilege VALUES('2948','12','gallery','category_edit;4');
INSERT INTO olala_core_privilege VALUES('2949','12','gallery','gallery_menu_add;4');
INSERT INTO olala_core_privilege VALUES('2950','12','gallery','gallery_menu_edit;4');
INSERT INTO olala_core_privilege VALUES('2951','12','gallery','gallery_menu_del;4');
INSERT INTO olala_core_privilege VALUES('2952','12','gallery','gallery_list;4');
INSERT INTO olala_core_privilege VALUES('2953','12','gallery','gallery_add;4');
INSERT INTO olala_core_privilege VALUES('2954','12','gallery','gallery_edit;4');
INSERT INTO olala_core_privilege VALUES('2955','12','gallery','gallery_del;4');
INSERT INTO olala_core_privilege VALUES('2956','12','gallery','category_edit;52');
INSERT INTO olala_core_privilege VALUES('2957','12','gallery','gallery_menu_add;52');
INSERT INTO olala_core_privilege VALUES('2958','12','gallery','gallery_menu_edit;52');
INSERT INTO olala_core_privilege VALUES('2959','12','gallery','gallery_menu_del;52');
INSERT INTO olala_core_privilege VALUES('2960','12','gallery','gallery_list;52');
INSERT INTO olala_core_privilege VALUES('2961','12','gallery','gallery_add;52');
INSERT INTO olala_core_privilege VALUES('2962','12','gallery','gallery_edit;52');
INSERT INTO olala_core_privilege VALUES('2963','12','gallery','gallery_del;52');
INSERT INTO olala_core_privilege VALUES('2964','12','product','category_edit;37');
INSERT INTO olala_core_privilege VALUES('2965','12','product','product_menu_add;37');
INSERT INTO olala_core_privilege VALUES('2966','12','product','product_menu_edit;37');
INSERT INTO olala_core_privilege VALUES('2967','12','product','product_menu_del;37');
INSERT INTO olala_core_privilege VALUES('2968','12','product','product_list;37');
INSERT INTO olala_core_privilege VALUES('2969','12','product','product_add;37');
INSERT INTO olala_core_privilege VALUES('2970','12','product','product_edit;37');
INSERT INTO olala_core_privilege VALUES('2971','12','product','product_del;37');
INSERT INTO olala_core_privilege VALUES('2985','12','location','location_add;39');
INSERT INTO olala_core_privilege VALUES('2984','12','location','location_list;39');
INSERT INTO olala_core_privilege VALUES('2983','12','location','location_menu_del;39');
INSERT INTO olala_core_privilege VALUES('2982','12','location','location_menu_edit;39');
INSERT INTO olala_core_privilege VALUES('2981','12','location','location_menu_add;39');
INSERT INTO olala_core_privilege VALUES('2980','12','location','category_edit;39');
INSERT INTO olala_core_privilege VALUES('2986','12','location','location_edit;39');
INSERT INTO olala_core_privilege VALUES('2987','12','location','location_del;39');
INSERT INTO olala_core_privilege VALUES('2988','12','location','category_edit;40');
INSERT INTO olala_core_privilege VALUES('2989','12','location','location_menu_add;40');
INSERT INTO olala_core_privilege VALUES('2990','12','location','location_menu_edit;40');
INSERT INTO olala_core_privilege VALUES('2991','12','location','location_menu_del;40');
INSERT INTO olala_core_privilege VALUES('2992','12','location','location_list;40');
INSERT INTO olala_core_privilege VALUES('2993','12','location','location_add;40');
INSERT INTO olala_core_privilege VALUES('2994','12','location','location_edit;40');
INSERT INTO olala_core_privilege VALUES('2995','12','location','location_del;40');
INSERT INTO olala_core_privilege VALUES('2996','12','road','road_add');
INSERT INTO olala_core_privilege VALUES('2997','12','road','road_edit');
INSERT INTO olala_core_privilege VALUES('2998','12','road','road_del');
INSERT INTO olala_core_privilege VALUES('2999','12','street','street_add');
INSERT INTO olala_core_privilege VALUES('3000','12','street','street_edit');
INSERT INTO olala_core_privilege VALUES('3001','12','street','street_del');
INSERT INTO olala_core_privilege VALUES('3002','12','direction','direction_add');
INSERT INTO olala_core_privilege VALUES('3003','12','direction','direction_edit');
INSERT INTO olala_core_privilege VALUES('3004','12','direction','direction_del');
INSERT INTO olala_core_privilege VALUES('3005','12','prjname','prjname_add');
INSERT INTO olala_core_privilege VALUES('3006','12','prjname','prjname_edit');
INSERT INTO olala_core_privilege VALUES('3007','12','prjname','prjname_del');
INSERT INTO olala_core_privilege VALUES('3008','12','backup','backup_data');
INSERT INTO olala_core_privilege VALUES('3009','12','backup','backup_config');
INSERT INTO olala_core_privilege VALUES('3010','12','config','config_general');
INSERT INTO olala_core_privilege VALUES('3011','12','config','config_smtp');
INSERT INTO olala_core_privilege VALUES('3012','12','config','config_datetime');
INSERT INTO olala_core_privilege VALUES('3013','12','config','config_plugins');
INSERT INTO olala_core_privilege VALUES('3014','12','config','config_socialnetwork');
INSERT INTO olala_core_privilege VALUES('3015','12','config','config_search');
INSERT INTO olala_core_privilege VALUES('3016','12','config','config_upload');
INSERT INTO olala_core_privilege VALUES('3017','12','tool','tool_delete');
INSERT INTO olala_core_privilege VALUES('3018','12','tool','tool_site');
INSERT INTO olala_core_privilege VALUES('3019','12','tool','tool_keywords');
INSERT INTO olala_core_privilege VALUES('3020','12','tool','tool_ipdie');
INSERT INTO olala_core_privilege VALUES('3021','12','tool','tool_update');
INSERT INTO olala_core_privilege VALUES('3022','12','core','core_role');
INSERT INTO olala_core_privilege VALUES('3023','12','core','core_user');
INSERT INTO olala_core_privilege VALUES('3024','12','core','core_dashboard');
INSERT INTO olala_core_privilege VALUES('3025','12','core','core_mail');
INSERT INTO olala_core_privilege VALUES('3026','12','info','Info_diary');
INSERT INTO olala_core_privilege VALUES('3027','12','info','Info_php');
INSERT INTO olala_core_privilege VALUES('3028','12','info','Info_site');
INSERT INTO olala_core_privilege VALUES('3029','12','info','Info_expansion');
INSERT INTO olala_core_privilege VALUES('3032','11','article','article_menu_edit;9');
INSERT INTO olala_core_privilege VALUES('3033','11','article','article_menu_del;9');
INSERT INTO olala_core_privilege VALUES('3034','11','article','article_list;9');
INSERT INTO olala_core_privilege VALUES('3035','11','article','article_add;9');
INSERT INTO olala_core_privilege VALUES('3036','11','article','article_edit;9');
INSERT INTO olala_core_privilege VALUES('3037','11','article','article_del;9');
INSERT INTO olala_core_privilege VALUES('3038','11','article','category_edit;51');
INSERT INTO olala_core_privilege VALUES('3039','11','article','article_menu_add;51');
INSERT INTO olala_core_privilege VALUES('3040','11','article','article_menu_edit;51');
INSERT INTO olala_core_privilege VALUES('3041','11','article','article_menu_del;51');
INSERT INTO olala_core_privilege VALUES('3042','11','article','article_list;51');
INSERT INTO olala_core_privilege VALUES('3043','11','article','article_add;51');
INSERT INTO olala_core_privilege VALUES('3044','11','article','article_edit;51');
INSERT INTO olala_core_privilege VALUES('3045','11','article','article_del;51');
INSERT INTO olala_core_privilege VALUES('3046','11','article','category_edit;7');
INSERT INTO olala_core_privilege VALUES('3047','11','article','article_menu_add;7');
INSERT INTO olala_core_privilege VALUES('3048','11','article','article_menu_edit;7');
INSERT INTO olala_core_privilege VALUES('3049','11','article','article_menu_del;7');
INSERT INTO olala_core_privilege VALUES('3050','11','article','article_list;7');
INSERT INTO olala_core_privilege VALUES('3051','11','article','article_add;7');
INSERT INTO olala_core_privilege VALUES('3052','11','article','article_edit;7');
INSERT INTO olala_core_privilege VALUES('3053','11','article','article_del;7');
INSERT INTO olala_core_privilege VALUES('3054','11','gallery','category_edit;4');
INSERT INTO olala_core_privilege VALUES('3055','11','gallery','gallery_menu_add;4');
INSERT INTO olala_core_privilege VALUES('3056','11','gallery','gallery_menu_edit;4');
INSERT INTO olala_core_privilege VALUES('3057','11','gallery','gallery_menu_del;4');
INSERT INTO olala_core_privilege VALUES('3058','11','gallery','gallery_list;4');
INSERT INTO olala_core_privilege VALUES('3059','11','gallery','gallery_add;4');
INSERT INTO olala_core_privilege VALUES('3060','11','gallery','gallery_edit;4');
INSERT INTO olala_core_privilege VALUES('3061','11','gallery','gallery_del;4');
INSERT INTO olala_core_privilege VALUES('3062','11','gallery','category_edit;52');
INSERT INTO olala_core_privilege VALUES('3063','11','gallery','gallery_menu_add;52');
INSERT INTO olala_core_privilege VALUES('3064','11','gallery','gallery_menu_edit;52');
INSERT INTO olala_core_privilege VALUES('3065','11','gallery','gallery_menu_del;52');
INSERT INTO olala_core_privilege VALUES('3066','11','gallery','gallery_list;52');
INSERT INTO olala_core_privilege VALUES('3067','11','gallery','gallery_add;52');
INSERT INTO olala_core_privilege VALUES('3068','11','gallery','gallery_edit;52');
INSERT INTO olala_core_privilege VALUES('3069','11','gallery','gallery_del;52');
INSERT INTO olala_core_privilege VALUES('3070','11','project','category_edit;13');
INSERT INTO olala_core_privilege VALUES('3071','11','project','project_menu_add;13');
INSERT INTO olala_core_privilege VALUES('3072','11','project','project_menu_edit;13');
INSERT INTO olala_core_privilege VALUES('3073','11','project','project_menu_del;13');
INSERT INTO olala_core_privilege VALUES('3074','11','project','project_list;13');
INSERT INTO olala_core_privilege VALUES('3075','11','project','project_add;13');
INSERT INTO olala_core_privilege VALUES('3076','11','project','project_edit;13');
INSERT INTO olala_core_privilege VALUES('3077','11','project','project_del;13');
INSERT INTO olala_core_privilege VALUES('3078','11','project','category_edit;53');
INSERT INTO olala_core_privilege VALUES('3079','11','project','project_menu_add;53');
INSERT INTO olala_core_privilege VALUES('3080','11','project','project_menu_edit;53');
INSERT INTO olala_core_privilege VALUES('3081','11','project','project_menu_del;53');
INSERT INTO olala_core_privilege VALUES('3082','11','project','project_list;53');
INSERT INTO olala_core_privilege VALUES('3083','11','project','project_add;53');
INSERT INTO olala_core_privilege VALUES('3084','11','project','project_edit;53');
INSERT INTO olala_core_privilege VALUES('3085','11','project','project_del;53');
INSERT INTO olala_core_privilege VALUES('3137','11','product','owner_real;37');
INSERT INTO olala_core_privilege VALUES('3136','11','product','product_del;37');
INSERT INTO olala_core_privilege VALUES('3135','11','product','product_edit;37');
INSERT INTO olala_core_privilege VALUES('3134','11','product','product_add;37');
INSERT INTO olala_core_privilege VALUES('4840','1','product','category_edit;99');
INSERT INTO olala_core_privilege VALUES('4839','1','product','product_del;100');
INSERT INTO olala_core_privilege VALUES('4838','1','product','product_edit;100');
INSERT INTO olala_core_privilege VALUES('3133','11','product','product_list;37');
INSERT INTO olala_core_privilege VALUES('3138','11','product','owner_cus;37');
INSERT INTO olala_core_privilege VALUES('3326','1','info','sys_info_php');
INSERT INTO olala_core_privilege VALUES('3325','1','info','sys_info_diary');
INSERT INTO olala_core_privilege VALUES('3334','1','core','core_mail');
INSERT INTO olala_core_privilege VALUES('4639','1','gallery','gallery_del;92');
INSERT INTO olala_core_privilege VALUES('4638','1','gallery','gallery_edit;92');
INSERT INTO olala_core_privilege VALUES('4637','1','gallery','gallery_add;92');
INSERT INTO olala_core_privilege VALUES('4636','1','gallery','gallery_list;92');
INSERT INTO olala_core_privilege VALUES('4635','1','gallery','gallery_menu_del;92');
INSERT INTO olala_core_privilege VALUES('4634','1','gallery','gallery_menu_edit;92');
INSERT INTO olala_core_privilege VALUES('4633','1','gallery','gallery_menu_add;92');
INSERT INTO olala_core_privilege VALUES('4632','1','gallery','category_edit;92');
INSERT INTO olala_core_privilege VALUES('4631','1','gallery','gallery_del;91');
INSERT INTO olala_core_privilege VALUES('4630','1','gallery','gallery_edit;91');
INSERT INTO olala_core_privilege VALUES('4629','1','gallery','gallery_add;91');
INSERT INTO olala_core_privilege VALUES('4628','1','gallery','gallery_list;91');
INSERT INTO olala_core_privilege VALUES('4627','1','gallery','gallery_menu_del;91');
INSERT INTO olala_core_privilege VALUES('4626','1','gallery','gallery_menu_edit;91');
INSERT INTO olala_core_privilege VALUES('4624','1','gallery','category_edit;91');
INSERT INTO olala_core_privilege VALUES('4625','1','gallery','gallery_menu_add;91');
INSERT INTO olala_core_privilege VALUES('4695','1','others','others_del;88');
INSERT INTO olala_core_privilege VALUES('4026','1','document','document_list;73');
INSERT INTO olala_core_privilege VALUES('4025','1','document','document_menu_del;73');
INSERT INTO olala_core_privilege VALUES('4024','1','document','document_menu_edit;73');
INSERT INTO olala_core_privilege VALUES('4023','1','document','document_menu_add;73');
INSERT INTO olala_core_privilege VALUES('4022','1','document','category_edit;73');
INSERT INTO olala_core_privilege VALUES('4028','1','document','document_edit;73');
INSERT INTO olala_core_privilege VALUES('4029','1','document','document_del;73');
INSERT INTO olala_core_privilege VALUES('4866','1','category','contact_list');
INSERT INTO olala_core_privilege VALUES('4837','1','product','product_add;100');
INSERT INTO olala_core_privilege VALUES('4836','1','product','product_list;100');
INSERT INTO olala_core_privilege VALUES('4835','1','product','product_menu_del;100');
INSERT INTO olala_core_privilege VALUES('4834','1','product','product_menu_edit;100');
INSERT INTO olala_core_privilege VALUES('4833','1','product','product_menu_add;100');
INSERT INTO olala_core_privilege VALUES('4832','1','product','category_edit;100');
INSERT INTO olala_core_privilege VALUES('4797','1','article','article_add;89');
INSERT INTO olala_core_privilege VALUES('4796','1','article','article_list;89');
INSERT INTO olala_core_privilege VALUES('4795','1','article','article_menu_del;89');
INSERT INTO olala_core_privilege VALUES('4794','1','article','article_menu_edit;89');
INSERT INTO olala_core_privilege VALUES('4793','1','article','article_menu_add;89');
INSERT INTO olala_core_privilege VALUES('4792','1','article','category_edit;89');
INSERT INTO olala_core_privilege VALUES('4791','1','article','article_del;97');
INSERT INTO olala_core_privilege VALUES('4790','1','article','article_edit;97');
INSERT INTO olala_core_privilege VALUES('4789','1','article','article_add;97');
INSERT INTO olala_core_privilege VALUES('4788','1','article','article_list;97');
INSERT INTO olala_core_privilege VALUES('4694','1','others','others_edit;88');
INSERT INTO olala_core_privilege VALUES('4693','1','others','others_add;88');
INSERT INTO olala_core_privilege VALUES('4692','1','others','others_list;88');
INSERT INTO olala_core_privilege VALUES('4691','1','others','others_menu_del;88');
INSERT INTO olala_core_privilege VALUES('4690','1','others','others_menu_edit;88');
INSERT INTO olala_core_privilege VALUES('4689','1','others','others_menu_add;88');
INSERT INTO olala_core_privilege VALUES('4688','1','others','category_edit;88');
INSERT INTO olala_core_privilege VALUES('4687','1','others','others_del;95');
INSERT INTO olala_core_privilege VALUES('4686','1','others','others_edit;95');
INSERT INTO olala_core_privilege VALUES('4685','1','others','others_add;95');
INSERT INTO olala_core_privilege VALUES('4684','1','others','others_list;95');
INSERT INTO olala_core_privilege VALUES('4683','1','others','others_menu_del;95');
INSERT INTO olala_core_privilege VALUES('4682','1','others','others_menu_edit;95');
INSERT INTO olala_core_privilege VALUES('4681','1','others','others_menu_add;95');
INSERT INTO olala_core_privilege VALUES('4680','1','others','category_edit;95');
INSERT INTO olala_core_privilege VALUES('4864','1','category','product_manager');
INSERT INTO olala_core_privilege VALUES('4865','1','category','others_manager');
INSERT INTO olala_core_privilege VALUES('4787','1','article','article_menu_del;97');
INSERT INTO olala_core_privilege VALUES('4786','1','article','article_menu_edit;97');
INSERT INTO olala_core_privilege VALUES('4785','1','article','article_menu_add;97');
INSERT INTO olala_core_privilege VALUES('4784','1','article','category_edit;97');
INSERT INTO olala_core_privilege VALUES('4783','1','article','article_del;94');
INSERT INTO olala_core_privilege VALUES('4781','1','article','article_add;94');
INSERT INTO olala_core_privilege VALUES('4782','1','article','article_edit;94');
INSERT INTO olala_core_privilege VALUES('4780','1','article','article_list;94');
INSERT INTO olala_core_privilege VALUES('4779','1','article','article_menu_del;94');
INSERT INTO olala_core_privilege VALUES('4778','1','article','article_menu_edit;94');
INSERT INTO olala_core_privilege VALUES('4777','1','article','article_menu_add;94');
INSERT INTO olala_core_privilege VALUES('4776','1','article','category_edit;94');
INSERT INTO olala_core_privilege VALUES('4775','1','article','article_del;98');
INSERT INTO olala_core_privilege VALUES('4774','1','article','article_edit;98');
INSERT INTO olala_core_privilege VALUES('4773','1','article','article_add;98');
INSERT INTO olala_core_privilege VALUES('4772','1','article','article_list;98');
INSERT INTO olala_core_privilege VALUES('4771','1','article','article_menu_del;98');
INSERT INTO olala_core_privilege VALUES('4770','1','article','article_menu_edit;98');
INSERT INTO olala_core_privilege VALUES('4769','1','article','article_menu_add;98');
INSERT INTO olala_core_privilege VALUES('4768','1','article','category_edit;98');
INSERT INTO olala_core_privilege VALUES('4801','1','article','article_menu_add;96');
INSERT INTO olala_core_privilege VALUES('4802','1','article','article_menu_edit;96');
INSERT INTO olala_core_privilege VALUES('4803','1','article','article_menu_del;96');
INSERT INTO olala_core_privilege VALUES('4804','1','article','article_list;96');
INSERT INTO olala_core_privilege VALUES('4805','1','article','article_add;96');
INSERT INTO olala_core_privilege VALUES('4806','1','article','article_edit;96');
INSERT INTO olala_core_privilege VALUES('4807','1','article','article_del;96');
INSERT INTO olala_core_privilege VALUES('4808','1','article','category_edit;90');
INSERT INTO olala_core_privilege VALUES('4809','1','article','article_menu_add;90');
INSERT INTO olala_core_privilege VALUES('4810','1','article','article_menu_edit;90');
INSERT INTO olala_core_privilege VALUES('4811','1','article','article_menu_del;90');
INSERT INTO olala_core_privilege VALUES('4812','1','article','article_list;90');
INSERT INTO olala_core_privilege VALUES('4813','1','article','article_add;90');
INSERT INTO olala_core_privilege VALUES('4814','1','article','article_edit;90');
INSERT INTO olala_core_privilege VALUES('4815','1','article','article_del;90');
INSERT INTO olala_core_privilege VALUES('4826','1','tool','tool_update');
INSERT INTO olala_core_privilege VALUES('4863','1','category','gallery_manager');
INSERT INTO olala_core_privilege VALUES('4842','1','product','product_menu_edit;99');
INSERT INTO olala_core_privilege VALUES('4843','1','product','product_menu_del;99');
INSERT INTO olala_core_privilege VALUES('4844','1','product','product_list;99');
INSERT INTO olala_core_privilege VALUES('4845','1','product','product_add;99');
INSERT INTO olala_core_privilege VALUES('4846','1','product','product_edit;99');
INSERT INTO olala_core_privilege VALUES('4847','1','product','product_del;99');
INSERT INTO olala_core_privilege VALUES('4848','1','product','category_edit;101');
INSERT INTO olala_core_privilege VALUES('4849','1','product','product_menu_add;101');
INSERT INTO olala_core_privilege VALUES('4850','1','product','product_menu_edit;101');
INSERT INTO olala_core_privilege VALUES('4851','1','product','product_menu_del;101');
INSERT INTO olala_core_privilege VALUES('4852','1','product','product_list;101');
INSERT INTO olala_core_privilege VALUES('4853','1','product','product_add;101');
INSERT INTO olala_core_privilege VALUES('4854','1','product','product_edit;101');
INSERT INTO olala_core_privilege VALUES('4855','1','product','product_del;101');
INSERT INTO olala_core_privilege VALUES('4862','1','category','article_manager');
INSERT INTO olala_core_privilege VALUES('4867','1','category','newsletter');
INSERT INTO olala_core_privilege VALUES('4868','1','category','plugin_page');

-- --------------------------------------------------------

CREATE TABLE `olala_core_role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO olala_core_role VALUES('1','Administrator','Nhóm quản trị tối cao','1','1441786254','1');
INSERT INTO olala_core_role VALUES('2','Tester','Nhóm kiểm thử','1','1441851198','1');
INSERT INTO olala_core_role VALUES('9','Broker','Nhân viên môi giới. Chỉ nhập và quản lý thông tin BĐS.','1','1439055844','1');

-- --------------------------------------------------------

CREATE TABLE `olala_core_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `user_name` varchar(16) NOT NULL,
  `password` varchar(50) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `gender` int(1) NOT NULL DEFAULT '0',
  `birthday` int(11) NOT NULL DEFAULT '0',
  `apply` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `is_show` int(1) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `vote` bigint(20) NOT NULL DEFAULT '1',
  `click_vote` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id_edit` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

INSERT INTO olala_core_user VALUES('1','1','admin','ca4c0178da5c3219c4150c77b16c935d','Phan Thị Thục Quỳnh','2','694198800','Chuyên viên BĐS','phanthucquynh@gmail.com','0935400483','Thanh Khê - Đà Nẵng','','1','1','u_1519840412_e7522d0352c8e97dbc03fa10300c48b1.jpg','1','1','1','1408159832','1519840412','25');
INSERT INTO olala_core_user VALUES('25','1','dev','35622d129658338262443a22a9c7bac5','Tô Thái Huy','1','694198800','Kỹ thuật & phát triển','huyto.qng@gmail.com','0974 779 805','','','0','4','u_1437075987_ffbbbf570157f5aa239cf98d7caa354a.jpg','1','1','1','0','1519840237','1');

-- --------------------------------------------------------

CREATE TABLE `olala_direction` (
  `direction_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`direction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_document` (
  `document_id` int(11) NOT NULL AUTO_INCREMENT,
  `document_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `release_date` int(11) NOT NULL DEFAULT '0',
  `effective_date` int(11) NOT NULL DEFAULT '0',
  `file` varchar(255) NOT NULL DEFAULT 'no',
  `type` varchar(5) NOT NULL DEFAULT 'unk',
  `size` int(11) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `content` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`document_id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_document_menu` (
  `document_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL DEFAULT 'not-found',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `comment` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`document_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_gallery` (
  `gallery_id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `upload_id` bigint(20) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `content` text NOT NULL,
  `link` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gallery_id`)
) ENGINE=MyISAM AUTO_INCREMENT=641 DEFAULT CHARSET=utf8;

INSERT INTO olala_gallery VALUES('628','84','IMG 01','img-1','','','','247land-1518025932.jpg','1793','','','','1','1','1','1495295400','1518025968','1');
INSERT INTO olala_gallery VALUES('636','84','IMG 02','img-02','','','','img-02-1518025985.jpg','2230','','','','1','0','1','1486489920','1518025984','1');
INSERT INTO olala_gallery VALUES('637','84','IMG 03','img-03','','','','img-03-1518026138.jpg','2231','','','','1','0','1','1486488000','1518026138','1');
INSERT INTO olala_gallery VALUES('638','84','IMG 04','img-04','','','','img-04-1518026168.jpg','2232','','','','1','0','1','1486487400','1518026168','1');
INSERT INTO olala_gallery VALUES('639','84','IMG 05','img-05','','','','img-05-1518026209.jpg','2233','','','','1','0','1','1486486800','1518026209','1');
INSERT INTO olala_gallery VALUES('640','84','IMG 06','img-06','','','','img-06-1518026243.jpg','2234','','','','1','0','1','1483808400','1518026243','1');

-- --------------------------------------------------------

CREATE TABLE `olala_gallery_menu` (
  `gallery_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `comment` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gallery_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;

INSERT INTO olala_gallery_menu VALUES('84','91','Slider home','slider-home','','','','0','1','','1','0','no','1495095137','1495095137','1');

-- --------------------------------------------------------

CREATE TABLE `olala_gift` (
  `gift_id` int(11) NOT NULL AUTO_INCREMENT,
  `gift_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `price` bigint(15) NOT NULL DEFAULT '0',
  `made` varchar(255) NOT NULL,
  `material` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `content` longtext NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gift_id`)
) ENGINE=MyISAM AUTO_INCREMENT=132 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_gift_menu` (
  `gift_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gift_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=144 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_link` (
  `link_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `link` varchar(255) NOT NULL,
  `category` int(11) NOT NULL DEFAULT '0',
  `menu` int(11) NOT NULL DEFAULT '0',
  `post` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`link_id`)
) ENGINE=InnoDB AUTO_INCREMENT=440 DEFAULT CHARSET=utf8;

INSERT INTO olala_link VALUES('1','gioi-thieu','94','0','0','1513527252');
INSERT INTO olala_link VALUES('2','slider','91','0','0','0');
INSERT INTO olala_link VALUES('5','du-an','89','0','0','1516138386');
INSERT INTO olala_link VALUES('54','city','95','0','0','1494961394');
INSERT INTO olala_link VALUES('59','da-nang','95','3','0','1494961453');
INSERT INTO olala_link VALUES('60','quang-nam','95','4','0','1494961457');
INSERT INTO olala_link VALUES('61','quang-ngai','95','5','0','1494961461');
INSERT INTO olala_link VALUES('192','hai-chau','95','3','131','1495043231');
INSERT INTO olala_link VALUES('193','thanh-khe','95','3','132','1495043241');
INSERT INTO olala_link VALUES('194','lien-chieu','95','3','133','1495043251');
INSERT INTO olala_link VALUES('195','cam-le','95','3','134','1495043259');
INSERT INTO olala_link VALUES('196','son-tra','95','3','135','1495043267');
INSERT INTO olala_link VALUES('197','ngu-hanh-son','95','3','136','1495043278');
INSERT INTO olala_link VALUES('198','hoa-vang','95','3','137','1495043293');
INSERT INTO olala_link VALUES('199','hoang-sa','95','3','138','1495043633');
INSERT INTO olala_link VALUES('200','tam-ky','95','4','139','1495043672');
INSERT INTO olala_link VALUES('201','hoi-an','95','4','140','1495043679');
INSERT INTO olala_link VALUES('202','tay-giang','95','4','141','1495043687');
INSERT INTO olala_link VALUES('203','phu-ninh','95','4','142','1495043731');
INSERT INTO olala_link VALUES('204','dai-loc','95','4','143','1495043737');
INSERT INTO olala_link VALUES('205','nam-giang','95','4','144','1495043743');
INSERT INTO olala_link VALUES('206','dong-giang','95','4','145','1495043835');
INSERT INTO olala_link VALUES('207','nong-son','95','4','146','1495043849');
INSERT INTO olala_link VALUES('208','hiep-duc','95','4','147','1495043854');
INSERT INTO olala_link VALUES('209','que-son','95','4','148','1495043860');
INSERT INTO olala_link VALUES('210','tien-phuoc','95','4','149','1495043869');
INSERT INTO olala_link VALUES('211','phuoc-son','95','4','150','1495043876');
INSERT INTO olala_link VALUES('212','nui-thanh','95','4','151','1495043917');
INSERT INTO olala_link VALUES('213','nam-tra-my','95','4','152','1495043926');
INSERT INTO olala_link VALUES('214','dien-ban','95','4','153','1495043934');
INSERT INTO olala_link VALUES('215','duy-xuyen','95','4','154','1495043942');
INSERT INTO olala_link VALUES('216','thang-binh','95','4','155','1495043951');
INSERT INTO olala_link VALUES('217','bac-tra-my','95','4','156','1495043958');
INSERT INTO olala_link VALUES('218','slider-home','91','84','0','1495095137');
INSERT INTO olala_link VALUES('237','blog','96','0','0','1519837082');
INSERT INTO olala_link VALUES('258','img-1','91','84','628','1518025968');
INSERT INTO olala_link VALUES('267','olala','0','0','0','0');
INSERT INTO olala_link VALUES('269','lien-he','0','0','0','0');
INSERT INTO olala_link VALUES('318','ve-chung-toi','94','428','0','1512313435');
INSERT INTO olala_link VALUES('350','tags','0','0','0','0');
INSERT INTO olala_link VALUES('351','page','0','0','0','0');
INSERT INTO olala_link VALUES('359','nha-dat-ban','99','0','0','1518025049');
INSERT INTO olala_link VALUES('360','dat-tho-cu','99','255','0','1517849853');
INSERT INTO olala_link VALUES('361','dat-nong-nghiep','99','256','0','1516136188');
INSERT INTO olala_link VALUES('362','dat-cong-nghiep','99','257','0','1516136196');
INSERT INTO olala_link VALUES('363','dat-loai-khac','99','258','0','1516136204');
INSERT INTO olala_link VALUES('364','nha-ban','100','0','0','1517631447');
INSERT INTO olala_link VALUES('367','cho-thue','101','0','0','1518025055');
INSERT INTO olala_link VALUES('368','cho-thue-nha','101','263','0','1516136339');
INSERT INTO olala_link VALUES('369','dat-cho-thue','101','264','0','1516136348');
INSERT INTO olala_link VALUES('370','mat-bang-cho-thue','101','265','0','1516136359');
INSERT INTO olala_link VALUES('371','kho-xuong-cho-thue','101','266','0','1516136367');
INSERT INTO olala_link VALUES('373','du-an-dat-nen','89','452','0','1516138002');
INSERT INTO olala_link VALUES('374','khu-do-thi','89','453','0','1516138068');
INSERT INTO olala_link VALUES('375','khu-dan-cu','89','454','0','1516138766');
INSERT INTO olala_link VALUES('376','biet-thu-nghi-duong','89','455','0','1516309992');
INSERT INTO olala_link VALUES('377','khu-tai-dinh-cu','89','456','0','1516138095');
INSERT INTO olala_link VALUES('378','can-ho-chung-cu','89','457','0','1516138116');
INSERT INTO olala_link VALUES('379','ban-tin-bat-dong-san','96','458','0','1516138145');
INSERT INTO olala_link VALUES('380','thong-tin-nha-dat','96','459','0','1516138161');
INSERT INTO olala_link VALUES('381','tin-hoat-dong','96','460','0','1516138172');
INSERT INTO olala_link VALUES('382','tin-tuyen-dung','96','461','0','1516138182');
INSERT INTO olala_link VALUES('383','tin-du-an','96','462','0','1516138249');
INSERT INTO olala_link VALUES('388','trang-tu-van-thong-tin-ve-cac-du-an-bat-dong-san-nha-pho-da-nang','94','428','916','1519704337');
INSERT INTO olala_link VALUES('389','90-can-ho-phong-cach-chuan-nhat-da-co-chu','96','458','917','1518196074');
INSERT INTO olala_link VALUES('390','bat-dong-san-nghi-duong-da-lat-phat-trien-cung-du-lich','96','458','918','1518196043');
INSERT INTO olala_link VALUES('391','bat-dong-san-sai-gon-thuong-tet-tien-ty','96','458','919','1518196015');
INSERT INTO olala_link VALUES('395','hoang-sa-tveqa78hjh','88','6','157','1516987043');
INSERT INTO olala_link VALUES('396','ban-3-lo-dat-mat-bien-gan-cong-vien-dai-duong-duong-hoang-sa-phuong-tho-quang-son-tra-da-nang','99','255','664','1519876925');
INSERT INTO olala_link VALUES('397','ban-lo-dat-duong-nguyen-tat-thanh-cach-bien-800m-135m2-7-5-x18-2','99','255','665','1517814728');
INSERT INTO olala_link VALUES('398','can-ban-cap-dat-duong-le-quang-dao-rat-dep-gan-bien-my-khe-duong-7-5m-gia-17-7-ty','99','255','666','1517848912');
INSERT INTO olala_link VALUES('399','long-giang-land-tang-lai-8-lan-sau-3-thang','96','458','923','1518195977');
INSERT INTO olala_link VALUES('400','hai-khach-trung-xe-mercedes-tai-le-tri-an-hado-centrosa-garden','96','458','924','1518195952');
INSERT INTO olala_link VALUES('402','the-panorama-da-lat-thu-hut-khach-hang-ngay-mo-ban','96','458','926','1518195933');
INSERT INTO olala_link VALUES('411','can-ban-dat-tai-mat-tien-duong-an-thuong-30-dt-162m2-huong-nam-hop-xay-khach-san-homestay','99','255','667','1517848920');
INSERT INTO olala_link VALUES('412','dat-nen-du-an','99','254','0','1518197752');
INSERT INTO olala_link VALUES('413','dat-nam-viet-a-dat-nghiem-xuan-yem-gia-huu-nghi-cuoi-nam','99','254','669','1517850586');
INSERT INTO olala_link VALUES('420','bat-dong-san','0','0','0','0');
INSERT INTO olala_link VALUES('421','img-02','91','84','636','1518025984');
INSERT INTO olala_link VALUES('422','img-03','91','84','637','1518026138');
INSERT INTO olala_link VALUES('423','img-04','91','84','638','1518026168');
INSERT INTO olala_link VALUES('424','img-05','91','84','639','1518026209');
INSERT INTO olala_link VALUES('425','img-06','91','84','640','1518026243');
INSERT INTO olala_link VALUES('426','khu-do-thi-fpt-city-da-nang-phuong-hoa-hai-quan-ngu-hanh-son-da-nang','99','254','668','1518197758');
INSERT INTO olala_link VALUES('427','nha-pho-nha-mat-tien','89','466','0','1519808388');
INSERT INTO olala_link VALUES('428','the-sunrise-bay','89','457','935','1519876572');
INSERT INTO olala_link VALUES('429','phu-gia-compound','89','466','936','1519876830');
INSERT INTO olala_link VALUES('430','monarchy','89','457','937','1519839676');
INSERT INTO olala_link VALUES('431','hiyori-garden-tower','89','457','938','1519839685');
INSERT INTO olala_link VALUES('432','the-ocean-estates','89','455','939','1519839736');
INSERT INTO olala_link VALUES('433','mua-nha-tang-vang-tai-prosper-plaza','96','458','940','1519836675');
INSERT INTO olala_link VALUES('434','bat-dong-san-da-nang-dong-tien-do-vao-dau-trong-nam-2018','96','458','941','1519836977');
INSERT INTO olala_link VALUES('435','song-manh-do-ve-bat-dong-san-tay-bac-da-nang','96','458','942','1519837530');
INSERT INTO olala_link VALUES('436','bat-dong-san-da-nang-khu-vuc-nao-dang-hut-nha-dau-tu','96','458','943','1519837822');
INSERT INTO olala_link VALUES('437','tay-bac-cuc-phat-trien-moi-cua-da-nang','96','458','944','1519837908');
INSERT INTO olala_link VALUES('438','golden-hills','89','455','945','1519839229');
INSERT INTO olala_link VALUES('439','home','0','0','0','0');

-- --------------------------------------------------------

CREATE TABLE `olala_location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_location_menu` (
  `location_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`location_menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_newsletter` (
  `newsletter_id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(15) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`newsletter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO olala_newsletter VALUES('1','0974779085','127.0.0.1','0','1517848149');
INSERT INTO olala_newsletter VALUES('2','01675338434','127.0.0.1','0','1517848379');

-- --------------------------------------------------------

CREATE TABLE `olala_online` (
  `online_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `site` varchar(255) NOT NULL,
  `agent` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`online_id`)
) ENGINE=InnoDB AUTO_INCREMENT=915 DEFAULT CHARSET=latin1;

INSERT INTO olala_online VALUES('914','127.0.0.1','1524565487','url=olala-admin/js/jquery.popup/jquery.boxes.repopup.js','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36','0');

-- --------------------------------------------------------

CREATE TABLE `olala_online_daily` (
  `online_daily_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`online_daily_id`)
) ENGINE=MyISAM AUTO_INCREMENT=761 DEFAULT CHARSET=utf8;

INSERT INTO olala_online_daily VALUES('1','2014-08-18','3');
INSERT INTO olala_online_daily VALUES('2','2014-08-17','1');
INSERT INTO olala_online_daily VALUES('3','2014-08-14','102');
INSERT INTO olala_online_daily VALUES('4','2014-08-06','100');
INSERT INTO olala_online_daily VALUES('5','2014-08-16','3');
INSERT INTO olala_online_daily VALUES('6','2014-08-13','10');
INSERT INTO olala_online_daily VALUES('7','2014-08-11','40');
INSERT INTO olala_online_daily VALUES('8','2014-08-09','90');
INSERT INTO olala_online_daily VALUES('9','2014-08-15','82');
INSERT INTO olala_online_daily VALUES('10','2014-08-12','207');
INSERT INTO olala_online_daily VALUES('11','2014-08-10','10');
INSERT INTO olala_online_daily VALUES('12','2014-08-08','7');
INSERT INTO olala_online_daily VALUES('13','2014-08-07','13');
INSERT INTO olala_online_daily VALUES('14','2014-08-19','13');
INSERT INTO olala_online_daily VALUES('15','2014-08-20','9');
INSERT INTO olala_online_daily VALUES('16','2014-08-21','135');
INSERT INTO olala_online_daily VALUES('17','2014-08-22','5');
INSERT INTO olala_online_daily VALUES('18','2014-09-27','7');
INSERT INTO olala_online_daily VALUES('19','2014-09-28','16');
INSERT INTO olala_online_daily VALUES('20','2014-09-29','5');
INSERT INTO olala_online_daily VALUES('21','2014-09-30','14');
INSERT INTO olala_online_daily VALUES('22','2014-10-01','16');
INSERT INTO olala_online_daily VALUES('23','2014-10-02','12');
INSERT INTO olala_online_daily VALUES('24','2014-10-03','7');
INSERT INTO olala_online_daily VALUES('25','2014-10-04','1');
INSERT INTO olala_online_daily VALUES('26','2014-10-05','2');
INSERT INTO olala_online_daily VALUES('27','2014-10-07','4');
INSERT INTO olala_online_daily VALUES('28','2014-10-08','11');
INSERT INTO olala_online_daily VALUES('29','2014-10-14','1');
INSERT INTO olala_online_daily VALUES('30','2014-10-20','1');
INSERT INTO olala_online_daily VALUES('31','2014-10-26','4');
INSERT INTO olala_online_daily VALUES('32','2014-10-27','9');
INSERT INTO olala_online_daily VALUES('33','2014-10-28','11');
INSERT INTO olala_online_daily VALUES('34','2014-10-29','13');
INSERT INTO olala_online_daily VALUES('35','2014-10-30','10');
INSERT INTO olala_online_daily VALUES('36','2014-10-31','14');
INSERT INTO olala_online_daily VALUES('37','2014-11-01','8');
INSERT INTO olala_online_daily VALUES('38','2014-11-02','12');
INSERT INTO olala_online_daily VALUES('39','2014-11-03','2');
INSERT INTO olala_online_daily VALUES('40','2014-11-05','4');
INSERT INTO olala_online_daily VALUES('41','2014-11-06','2');
INSERT INTO olala_online_daily VALUES('42','2014-11-07','4');
INSERT INTO olala_online_daily VALUES('43','2014-11-08','1');
INSERT INTO olala_online_daily VALUES('44','2014-11-09','1');
INSERT INTO olala_online_daily VALUES('45','2014-11-10','11');
INSERT INTO olala_online_daily VALUES('46','2014-11-11','8');
INSERT INTO olala_online_daily VALUES('47','2014-11-12','3');
INSERT INTO olala_online_daily VALUES('48','2014-11-13','5');
INSERT INTO olala_online_daily VALUES('49','2014-11-14','6');
INSERT INTO olala_online_daily VALUES('50','2014-11-15','1');
INSERT INTO olala_online_daily VALUES('51','2014-11-16','1');
INSERT INTO olala_online_daily VALUES('52','2014-11-17','4');
INSERT INTO olala_online_daily VALUES('53','2014-11-18','1');
INSERT INTO olala_online_daily VALUES('54','2014-11-19','4');
INSERT INTO olala_online_daily VALUES('55','2014-11-20','1');
INSERT INTO olala_online_daily VALUES('56','2014-11-21','4');
INSERT INTO olala_online_daily VALUES('57','2014-11-22','1');
INSERT INTO olala_online_daily VALUES('58','2014-11-23','16');
INSERT INTO olala_online_daily VALUES('59','2014-11-24','1');
INSERT INTO olala_online_daily VALUES('60','2014-11-25','5');
INSERT INTO olala_online_daily VALUES('61','2014-11-27','15');
INSERT INTO olala_online_daily VALUES('62','2014-11-28','18');
INSERT INTO olala_online_daily VALUES('63','2014-11-29','10');
INSERT INTO olala_online_daily VALUES('64','2014-11-30','10');
INSERT INTO olala_online_daily VALUES('65','2014-12-01','6');
INSERT INTO olala_online_daily VALUES('66','2014-12-02','13');
INSERT INTO olala_online_daily VALUES('67','2014-12-03','9');
INSERT INTO olala_online_daily VALUES('68','2014-12-04','9');
INSERT INTO olala_online_daily VALUES('69','2014-12-05','7');
INSERT INTO olala_online_daily VALUES('70','2014-12-06','1');
INSERT INTO olala_online_daily VALUES('71','2014-12-08','5');
INSERT INTO olala_online_daily VALUES('72','2014-12-09','2');
INSERT INTO olala_online_daily VALUES('73','2014-12-10','5');
INSERT INTO olala_online_daily VALUES('74','2014-12-11','13');
INSERT INTO olala_online_daily VALUES('75','2014-12-12','4');
INSERT INTO olala_online_daily VALUES('76','2014-12-16','2');
INSERT INTO olala_online_daily VALUES('77','2014-12-20','11');
INSERT INTO olala_online_daily VALUES('78','2014-12-21','6');
INSERT INTO olala_online_daily VALUES('79','2014-12-22','5');
INSERT INTO olala_online_daily VALUES('80','2014-12-23','3');
INSERT INTO olala_online_daily VALUES('81','2014-12-24','1');
INSERT INTO olala_online_daily VALUES('82','2014-12-26','2');
INSERT INTO olala_online_daily VALUES('83','2014-12-27','10');
INSERT INTO olala_online_daily VALUES('84','0000-00-00','1');
INSERT INTO olala_online_daily VALUES('85','2014-12-28','15');
INSERT INTO olala_online_daily VALUES('86','2014-12-29','11');
INSERT INTO olala_online_daily VALUES('87','2014-12-30','1');
INSERT INTO olala_online_daily VALUES('88','2015-01-02','11');
INSERT INTO olala_online_daily VALUES('89','2015-01-03','4');
INSERT INTO olala_online_daily VALUES('90','2015-01-04','2');
INSERT INTO olala_online_daily VALUES('91','2015-01-05','9');
INSERT INTO olala_online_daily VALUES('92','2015-01-06','7');
INSERT INTO olala_online_daily VALUES('93','2015-01-07','1');
INSERT INTO olala_online_daily VALUES('94','2015-01-08','7');
INSERT INTO olala_online_daily VALUES('95','2015-01-09','13');
INSERT INTO olala_online_daily VALUES('96','2015-01-10','2');
INSERT INTO olala_online_daily VALUES('97','2015-01-12','1');
INSERT INTO olala_online_daily VALUES('98','2015-01-19','2');
INSERT INTO olala_online_daily VALUES('99','2015-01-20','12');
INSERT INTO olala_online_daily VALUES('100','2015-01-21','8');
INSERT INTO olala_online_daily VALUES('101','2015-01-22','43');
INSERT INTO olala_online_daily VALUES('102','2015-01-23','36');
INSERT INTO olala_online_daily VALUES('103','2015-01-24','34');
INSERT INTO olala_online_daily VALUES('104','2015-01-24','34');
INSERT INTO olala_online_daily VALUES('105','2015-01-25','46');
INSERT INTO olala_online_daily VALUES('106','2015-01-26','51');
INSERT INTO olala_online_daily VALUES('107','2015-01-27','53');
INSERT INTO olala_online_daily VALUES('108','2015-01-28','46');
INSERT INTO olala_online_daily VALUES('109','2015-01-29','471');
INSERT INTO olala_online_daily VALUES('110','2015-01-30','191');
INSERT INTO olala_online_daily VALUES('111','2015-01-31','106');
INSERT INTO olala_online_daily VALUES('112','2015-02-01','61');
INSERT INTO olala_online_daily VALUES('113','2015-02-02','37');
INSERT INTO olala_online_daily VALUES('114','2015-02-03','53');
INSERT INTO olala_online_daily VALUES('115','2015-02-04','66');
INSERT INTO olala_online_daily VALUES('116','2015-02-05','63');
INSERT INTO olala_online_daily VALUES('117','2015-02-06','86');
INSERT INTO olala_online_daily VALUES('118','2015-02-07','63');
INSERT INTO olala_online_daily VALUES('119','2015-02-08','68');
INSERT INTO olala_online_daily VALUES('120','2015-02-09','64');
INSERT INTO olala_online_daily VALUES('121','2015-02-10','46');
INSERT INTO olala_online_daily VALUES('122','2015-02-11','53');
INSERT INTO olala_online_daily VALUES('123','2015-02-12','28');
INSERT INTO olala_online_daily VALUES('124','2015-02-13','155');
INSERT INTO olala_online_daily VALUES('125','2015-02-14','43');
INSERT INTO olala_online_daily VALUES('126','2015-02-15','27');
INSERT INTO olala_online_daily VALUES('127','2015-02-16','22');
INSERT INTO olala_online_daily VALUES('128','2015-02-17','20');
INSERT INTO olala_online_daily VALUES('129','2015-02-18','19');
INSERT INTO olala_online_daily VALUES('130','2015-02-19','16');
INSERT INTO olala_online_daily VALUES('131','2015-02-20','18');
INSERT INTO olala_online_daily VALUES('132','2015-02-21','33');
INSERT INTO olala_online_daily VALUES('133','2015-02-22','31');
INSERT INTO olala_online_daily VALUES('134','2015-02-23','34');
INSERT INTO olala_online_daily VALUES('135','2015-02-24','22');
INSERT INTO olala_online_daily VALUES('136','2015-02-25','26');
INSERT INTO olala_online_daily VALUES('137','2015-02-26','34');
INSERT INTO olala_online_daily VALUES('138','2015-02-27','19');
INSERT INTO olala_online_daily VALUES('139','2015-02-28','5');
INSERT INTO olala_online_daily VALUES('140','2015-03-01','12');
INSERT INTO olala_online_daily VALUES('141','2015-03-02','24');
INSERT INTO olala_online_daily VALUES('142','2015-03-03','48');
INSERT INTO olala_online_daily VALUES('143','2015-03-04','49');
INSERT INTO olala_online_daily VALUES('144','2015-03-05','43');
INSERT INTO olala_online_daily VALUES('145','2015-03-06','33');
INSERT INTO olala_online_daily VALUES('146','2015-03-07','52');
INSERT INTO olala_online_daily VALUES('147','2015-03-08','26');
INSERT INTO olala_online_daily VALUES('148','2015-03-09','46');
INSERT INTO olala_online_daily VALUES('149','2015-03-10','37');
INSERT INTO olala_online_daily VALUES('150','2015-03-11','47');
INSERT INTO olala_online_daily VALUES('151','2015-03-12','33');
INSERT INTO olala_online_daily VALUES('152','2015-03-13','28');
INSERT INTO olala_online_daily VALUES('153','2015-03-14','2');
INSERT INTO olala_online_daily VALUES('154','2015-03-16','5');
INSERT INTO olala_online_daily VALUES('155','2015-03-17','18');
INSERT INTO olala_online_daily VALUES('156','2015-03-18','11');
INSERT INTO olala_online_daily VALUES('157','2015-03-19','21');
INSERT INTO olala_online_daily VALUES('158','2015-03-20','18');
INSERT INTO olala_online_daily VALUES('159','2015-03-21','3');
INSERT INTO olala_online_daily VALUES('160','2015-05-06','5');
INSERT INTO olala_online_daily VALUES('161','2015-05-07','4');
INSERT INTO olala_online_daily VALUES('162','2015-05-08','3');
INSERT INTO olala_online_daily VALUES('163','2015-05-09','2');
INSERT INTO olala_online_daily VALUES('164','2015-05-10','8');
INSERT INTO olala_online_daily VALUES('165','2015-05-11','3');
INSERT INTO olala_online_daily VALUES('166','2015-05-12','4');
INSERT INTO olala_online_daily VALUES('167','2015-05-15','1');
INSERT INTO olala_online_daily VALUES('168','2015-05-16','2');
INSERT INTO olala_online_daily VALUES('169','2015-05-17','2');
INSERT INTO olala_online_daily VALUES('170','2015-05-18','1');
INSERT INTO olala_online_daily VALUES('171','2015-05-19','3');
INSERT INTO olala_online_daily VALUES('172','2015-05-23','1');
INSERT INTO olala_online_daily VALUES('173','2015-05-24','1');
INSERT INTO olala_online_daily VALUES('174','2015-05-25','2');
INSERT INTO olala_online_daily VALUES('175','2015-05-26','2');
INSERT INTO olala_online_daily VALUES('176','2015-05-27','4');
INSERT INTO olala_online_daily VALUES('177','2015-05-28','4');
INSERT INTO olala_online_daily VALUES('178','2015-05-29','3');
INSERT INTO olala_online_daily VALUES('179','2015-05-31','3');
INSERT INTO olala_online_daily VALUES('180','2015-06-01','1');
INSERT INTO olala_online_daily VALUES('181','2015-06-02','2');
INSERT INTO olala_online_daily VALUES('182','2015-06-03','3');
INSERT INTO olala_online_daily VALUES('183','2015-06-04','3');
INSERT INTO olala_online_daily VALUES('184','2015-06-05','1');
INSERT INTO olala_online_daily VALUES('185','2015-06-06','1');
INSERT INTO olala_online_daily VALUES('186','2015-06-08','1');
INSERT INTO olala_online_daily VALUES('187','2015-06-09','2');
INSERT INTO olala_online_daily VALUES('188','2015-06-10','1');
INSERT INTO olala_online_daily VALUES('189','2015-06-11','2');
INSERT INTO olala_online_daily VALUES('190','2015-06-12','3');
INSERT INTO olala_online_daily VALUES('191','2015-06-13','2');
INSERT INTO olala_online_daily VALUES('192','2015-06-14','1');
INSERT INTO olala_online_daily VALUES('193','2015-06-15','4');
INSERT INTO olala_online_daily VALUES('194','2015-06-16','1');
INSERT INTO olala_online_daily VALUES('195','2015-06-17','1');
INSERT INTO olala_online_daily VALUES('196','2015-06-18','1');
INSERT INTO olala_online_daily VALUES('197','2015-06-21','1');
INSERT INTO olala_online_daily VALUES('198','2015-06-22','3');
INSERT INTO olala_online_daily VALUES('199','2015-06-23','1');
INSERT INTO olala_online_daily VALUES('200','2015-06-24','8');
INSERT INTO olala_online_daily VALUES('201','2015-06-28','1');
INSERT INTO olala_online_daily VALUES('202','2015-06-29','3');
INSERT INTO olala_online_daily VALUES('203','2015-06-30','4');
INSERT INTO olala_online_daily VALUES('204','2015-07-01','4');
INSERT INTO olala_online_daily VALUES('205','2015-07-02','3');
INSERT INTO olala_online_daily VALUES('206','2015-07-03','3');
INSERT INTO olala_online_daily VALUES('207','2015-07-06','1');
INSERT INTO olala_online_daily VALUES('208','2015-07-07','1');
INSERT INTO olala_online_daily VALUES('209','2015-07-12','4');
INSERT INTO olala_online_daily VALUES('210','2015-07-13','6');
INSERT INTO olala_online_daily VALUES('211','2015-07-14','29');
INSERT INTO olala_online_daily VALUES('212','2015-07-15','190');
INSERT INTO olala_online_daily VALUES('213','2015-07-16','361');
INSERT INTO olala_online_daily VALUES('214','2015-07-17','354');
INSERT INTO olala_online_daily VALUES('215','2015-07-18','238');
INSERT INTO olala_online_daily VALUES('216','2015-07-19','343');
INSERT INTO olala_online_daily VALUES('217','2015-07-20','802');
INSERT INTO olala_online_daily VALUES('218','2015-07-21','1926');
INSERT INTO olala_online_daily VALUES('219','2015-07-22','1349');
INSERT INTO olala_online_daily VALUES('220','2015-07-23','1648');
INSERT INTO olala_online_daily VALUES('221','2015-07-24','2370');
INSERT INTO olala_online_daily VALUES('222','2015-07-25','4986');
INSERT INTO olala_online_daily VALUES('223','2015-07-26','2251');
INSERT INTO olala_online_daily VALUES('224','2015-07-27','3882');
INSERT INTO olala_online_daily VALUES('225','2015-07-28','3496');
INSERT INTO olala_online_daily VALUES('226','2015-07-29','3603');
INSERT INTO olala_online_daily VALUES('227','2015-07-30','2778');
INSERT INTO olala_online_daily VALUES('228','2015-07-31','5');
INSERT INTO olala_online_daily VALUES('229','2015-08-01','2');
INSERT INTO olala_online_daily VALUES('230','2015-08-02','3');
INSERT INTO olala_online_daily VALUES('231','2015-08-03','2');
INSERT INTO olala_online_daily VALUES('232','2015-08-05','5');
INSERT INTO olala_online_daily VALUES('233','2015-08-06','1');
INSERT INTO olala_online_daily VALUES('234','2015-08-07','5');
INSERT INTO olala_online_daily VALUES('235','2015-08-08','8');
INSERT INTO olala_online_daily VALUES('236','2015-08-09','7');
INSERT INTO olala_online_daily VALUES('237','2015-08-10','6');
INSERT INTO olala_online_daily VALUES('238','2015-08-11','1');
INSERT INTO olala_online_daily VALUES('239','2015-08-12','2');
INSERT INTO olala_online_daily VALUES('240','2015-08-13','3');
INSERT INTO olala_online_daily VALUES('241','2015-08-14','1');
INSERT INTO olala_online_daily VALUES('242','2015-08-16','2');
INSERT INTO olala_online_daily VALUES('243','2015-08-17','2');
INSERT INTO olala_online_daily VALUES('244','2015-08-18','1');
INSERT INTO olala_online_daily VALUES('245','2015-08-28','2');
INSERT INTO olala_online_daily VALUES('246','2015-08-29','1');
INSERT INTO olala_online_daily VALUES('247','2015-08-30','1');
INSERT INTO olala_online_daily VALUES('248','2015-08-31','3');
INSERT INTO olala_online_daily VALUES('249','2015-09-01','1');
INSERT INTO olala_online_daily VALUES('250','2015-09-04','1');
INSERT INTO olala_online_daily VALUES('251','2015-09-05','1');
INSERT INTO olala_online_daily VALUES('252','2015-09-06','1');
INSERT INTO olala_online_daily VALUES('253','2015-09-07','1');
INSERT INTO olala_online_daily VALUES('254','2015-09-08','1');
INSERT INTO olala_online_daily VALUES('255','2015-09-09','3');
INSERT INTO olala_online_daily VALUES('256','2015-09-10','3');
INSERT INTO olala_online_daily VALUES('257','2015-09-11','2');
INSERT INTO olala_online_daily VALUES('258','2015-09-17','1');
INSERT INTO olala_online_daily VALUES('259','2015-09-27','3');
INSERT INTO olala_online_daily VALUES('260','2015-09-28','2');
INSERT INTO olala_online_daily VALUES('261','2015-10-19','1');
INSERT INTO olala_online_daily VALUES('262','2015-10-20','4');
INSERT INTO olala_online_daily VALUES('263','2015-10-21','1');
INSERT INTO olala_online_daily VALUES('264','2015-10-24','1');
INSERT INTO olala_online_daily VALUES('265','2015-10-25','5');
INSERT INTO olala_online_daily VALUES('266','2015-10-26','22');
INSERT INTO olala_online_daily VALUES('267','2015-10-27','36');
INSERT INTO olala_online_daily VALUES('268','2015-11-10','1');
INSERT INTO olala_online_daily VALUES('269','2015-11-11','3');
INSERT INTO olala_online_daily VALUES('270','2015-11-12','22');
INSERT INTO olala_online_daily VALUES('271','2015-11-13','45');
INSERT INTO olala_online_daily VALUES('272','2015-11-14','9');
INSERT INTO olala_online_daily VALUES('273','2015-11-15','27');
INSERT INTO olala_online_daily VALUES('274','2015-11-16','36');
INSERT INTO olala_online_daily VALUES('275','2015-11-17','24');
INSERT INTO olala_online_daily VALUES('276','2015-11-18','10');
INSERT INTO olala_online_daily VALUES('277','2015-11-19','14');
INSERT INTO olala_online_daily VALUES('278','2015-11-20','7');
INSERT INTO olala_online_daily VALUES('279','2015-11-21','5');
INSERT INTO olala_online_daily VALUES('280','2015-11-22','1');
INSERT INTO olala_online_daily VALUES('281','2015-11-23','12');
INSERT INTO olala_online_daily VALUES('282','2015-11-24','5');
INSERT INTO olala_online_daily VALUES('283','2015-11-27','1');
INSERT INTO olala_online_daily VALUES('284','2015-11-28','2');
INSERT INTO olala_online_daily VALUES('285','2015-11-29','1');
INSERT INTO olala_online_daily VALUES('286','2015-11-30','4');
INSERT INTO olala_online_daily VALUES('287','2015-12-01','38');
INSERT INTO olala_online_daily VALUES('288','2015-12-02','34');
INSERT INTO olala_online_daily VALUES('289','2015-12-03','41');
INSERT INTO olala_online_daily VALUES('290','2015-12-04','34');
INSERT INTO olala_online_daily VALUES('291','2015-12-09','1');
INSERT INTO olala_online_daily VALUES('292','2015-12-19','1');
INSERT INTO olala_online_daily VALUES('293','2015-12-20','2');
INSERT INTO olala_online_daily VALUES('294','2015-12-21','7');
INSERT INTO olala_online_daily VALUES('295','2015-12-22','5');
INSERT INTO olala_online_daily VALUES('296','2015-12-23','52');
INSERT INTO olala_online_daily VALUES('297','2015-12-24','37');
INSERT INTO olala_online_daily VALUES('298','2015-12-25','39');
INSERT INTO olala_online_daily VALUES('299','2015-12-26','13');
INSERT INTO olala_online_daily VALUES('300','2015-12-27','2');
INSERT INTO olala_online_daily VALUES('301','2015-12-28','18');
INSERT INTO olala_online_daily VALUES('302','2015-12-29','9');
INSERT INTO olala_online_daily VALUES('303','2015-12-30','16');
INSERT INTO olala_online_daily VALUES('304','2015-12-31','6');
INSERT INTO olala_online_daily VALUES('305','2016-01-07','3');
INSERT INTO olala_online_daily VALUES('306','2016-01-08','3');
INSERT INTO olala_online_daily VALUES('307','2016-01-09','7');
INSERT INTO olala_online_daily VALUES('308','2016-01-10','1');
INSERT INTO olala_online_daily VALUES('309','2016-01-12','7');
INSERT INTO olala_online_daily VALUES('310','2016-01-13','4');
INSERT INTO olala_online_daily VALUES('311','2016-01-14','4');
INSERT INTO olala_online_daily VALUES('312','2016-01-15','14');
INSERT INTO olala_online_daily VALUES('313','2016-01-16','66');
INSERT INTO olala_online_daily VALUES('314','2016-01-17','45');
INSERT INTO olala_online_daily VALUES('315','2016-01-18','31');
INSERT INTO olala_online_daily VALUES('316','2016-01-19','7');
INSERT INTO olala_online_daily VALUES('317','2016-01-20','12');
INSERT INTO olala_online_daily VALUES('318','2016-01-21','5');
INSERT INTO olala_online_daily VALUES('319','2016-01-22','7');
INSERT INTO olala_online_daily VALUES('320','2016-01-23','4');
INSERT INTO olala_online_daily VALUES('321','2016-01-24','1');
INSERT INTO olala_online_daily VALUES('322','2016-01-25','25');
INSERT INTO olala_online_daily VALUES('323','2016-01-26','1');
INSERT INTO olala_online_daily VALUES('324','2016-01-27','11');
INSERT INTO olala_online_daily VALUES('325','2016-01-28','40');
INSERT INTO olala_online_daily VALUES('326','2016-01-29','35');
INSERT INTO olala_online_daily VALUES('327','2016-01-30','6');
INSERT INTO olala_online_daily VALUES('328','2016-02-01','14');
INSERT INTO olala_online_daily VALUES('329','2016-02-02','40');
INSERT INTO olala_online_daily VALUES('330','2016-02-03','163');
INSERT INTO olala_online_daily VALUES('331','2016-02-04','81');
INSERT INTO olala_online_daily VALUES('332','2016-02-05','63');
INSERT INTO olala_online_daily VALUES('333','2016-02-06','52');
INSERT INTO olala_online_daily VALUES('334','2016-02-07','38');
INSERT INTO olala_online_daily VALUES('335','2016-02-08','35');
INSERT INTO olala_online_daily VALUES('336','2016-02-09','48');
INSERT INTO olala_online_daily VALUES('337','2016-02-10','39');
INSERT INTO olala_online_daily VALUES('338','2016-02-11','34');
INSERT INTO olala_online_daily VALUES('339','2016-02-12','74');
INSERT INTO olala_online_daily VALUES('340','2016-02-13','56');
INSERT INTO olala_online_daily VALUES('341','2016-02-14','60');
INSERT INTO olala_online_daily VALUES('342','2016-02-15','104');
INSERT INTO olala_online_daily VALUES('343','2016-02-16','59');
INSERT INTO olala_online_daily VALUES('344','2016-02-17','58');
INSERT INTO olala_online_daily VALUES('345','2016-02-18','43');
INSERT INTO olala_online_daily VALUES('346','2016-02-19','2');
INSERT INTO olala_online_daily VALUES('347','2016-02-20','2');
INSERT INTO olala_online_daily VALUES('348','2016-02-22','3');
INSERT INTO olala_online_daily VALUES('349','2016-03-01','1');
INSERT INTO olala_online_daily VALUES('350','2016-03-04','3');
INSERT INTO olala_online_daily VALUES('351','2016-03-04','3');
INSERT INTO olala_online_daily VALUES('352','2016-03-07','1');
INSERT INTO olala_online_daily VALUES('353','2016-03-08','1');
INSERT INTO olala_online_daily VALUES('354','2016-03-09','14');
INSERT INTO olala_online_daily VALUES('355','2016-03-10','5');
INSERT INTO olala_online_daily VALUES('356','2016-03-11','6');
INSERT INTO olala_online_daily VALUES('357','2016-03-13','2');
INSERT INTO olala_online_daily VALUES('358','2016-03-14','1');
INSERT INTO olala_online_daily VALUES('359','2016-03-20','1');
INSERT INTO olala_online_daily VALUES('360','2016-03-26','8');
INSERT INTO olala_online_daily VALUES('361','2016-03-27','8');
INSERT INTO olala_online_daily VALUES('362','2016-03-28','46');
INSERT INTO olala_online_daily VALUES('363','2016-03-29','1');
INSERT INTO olala_online_daily VALUES('364','2016-03-30','11');
INSERT INTO olala_online_daily VALUES('365','2016-03-31','2');
INSERT INTO olala_online_daily VALUES('366','2016-04-02','1');
INSERT INTO olala_online_daily VALUES('367','2016-04-03','5');
INSERT INTO olala_online_daily VALUES('368','2016-04-04','10');
INSERT INTO olala_online_daily VALUES('369','2016-04-05','31');
INSERT INTO olala_online_daily VALUES('370','2016-04-06','65');
INSERT INTO olala_online_daily VALUES('371','2016-04-07','35');
INSERT INTO olala_online_daily VALUES('372','2016-04-08','15');
INSERT INTO olala_online_daily VALUES('373','2016-04-09','1');
INSERT INTO olala_online_daily VALUES('374','2016-04-20','2');
INSERT INTO olala_online_daily VALUES('375','2016-04-22','2');
INSERT INTO olala_online_daily VALUES('376','2016-04-23','7');
INSERT INTO olala_online_daily VALUES('377','2016-04-24','8');
INSERT INTO olala_online_daily VALUES('378','2016-04-25','1');
INSERT INTO olala_online_daily VALUES('379','2016-04-26','2');
INSERT INTO olala_online_daily VALUES('380','2016-04-27','4');
INSERT INTO olala_online_daily VALUES('381','2016-04-28','3');
INSERT INTO olala_online_daily VALUES('382','2016-05-05','1');
INSERT INTO olala_online_daily VALUES('383','2016-05-08','9');
INSERT INTO olala_online_daily VALUES('384','2016-05-09','3');
INSERT INTO olala_online_daily VALUES('385','2016-05-10','2');
INSERT INTO olala_online_daily VALUES('386','2016-05-11','5');
INSERT INTO olala_online_daily VALUES('387','2016-05-12','6');
INSERT INTO olala_online_daily VALUES('388','2016-05-13','11');
INSERT INTO olala_online_daily VALUES('389','2016-05-15','3');
INSERT INTO olala_online_daily VALUES('390','2016-05-16','8');
INSERT INTO olala_online_daily VALUES('391','2016-05-17','7');
INSERT INTO olala_online_daily VALUES('392','2016-05-19','3');
INSERT INTO olala_online_daily VALUES('393','2016-05-19','3');
INSERT INTO olala_online_daily VALUES('394','2016-05-20','2');
INSERT INTO olala_online_daily VALUES('395','2016-05-22','5');
INSERT INTO olala_online_daily VALUES('396','2016-05-23','1');
INSERT INTO olala_online_daily VALUES('397','2016-05-24','1');
INSERT INTO olala_online_daily VALUES('398','2016-05-30','5');
INSERT INTO olala_online_daily VALUES('399','2016-06-16','1');
INSERT INTO olala_online_daily VALUES('400','2016-06-24','5');
INSERT INTO olala_online_daily VALUES('401','2016-06-25','12');
INSERT INTO olala_online_daily VALUES('402','2016-06-26','5');
INSERT INTO olala_online_daily VALUES('403','2016-08-08','6');
INSERT INTO olala_online_daily VALUES('404','2016-08-09','4');
INSERT INTO olala_online_daily VALUES('405','2016-08-10','5');
INSERT INTO olala_online_daily VALUES('406','2016-08-11','2');
INSERT INTO olala_online_daily VALUES('407','2016-08-12','6');
INSERT INTO olala_online_daily VALUES('408','2016-08-14','1');
INSERT INTO olala_online_daily VALUES('409','2016-08-16','12');
INSERT INTO olala_online_daily VALUES('410','2016-08-17','39');
INSERT INTO olala_online_daily VALUES('411','2016-08-18','157');
INSERT INTO olala_online_daily VALUES('412','2016-08-19','196');
INSERT INTO olala_online_daily VALUES('413','2016-08-20','227');
INSERT INTO olala_online_daily VALUES('414','2016-08-21','190');
INSERT INTO olala_online_daily VALUES('415','2016-08-22','545');
INSERT INTO olala_online_daily VALUES('416','2016-08-23','367');
INSERT INTO olala_online_daily VALUES('417','2016-08-24','369');
INSERT INTO olala_online_daily VALUES('418','2016-08-25','418');
INSERT INTO olala_online_daily VALUES('419','2016-08-26','512');
INSERT INTO olala_online_daily VALUES('420','2016-08-27','614');
INSERT INTO olala_online_daily VALUES('421','2016-08-28','631');
INSERT INTO olala_online_daily VALUES('422','2016-08-29','728');
INSERT INTO olala_online_daily VALUES('423','2016-08-30','579');
INSERT INTO olala_online_daily VALUES('424','2016-08-31','333');
INSERT INTO olala_online_daily VALUES('425','2016-09-01','219');
INSERT INTO olala_online_daily VALUES('426','2016-09-02','108');
INSERT INTO olala_online_daily VALUES('427','2016-09-03','157');
INSERT INTO olala_online_daily VALUES('428','2016-09-04','156');
INSERT INTO olala_online_daily VALUES('429','2016-09-05','662');
INSERT INTO olala_online_daily VALUES('430','2016-09-06','744');
INSERT INTO olala_online_daily VALUES('431','2016-09-07','504');
INSERT INTO olala_online_daily VALUES('432','2016-09-08','571');
INSERT INTO olala_online_daily VALUES('433','2016-09-09','516');
INSERT INTO olala_online_daily VALUES('434','2016-09-10','484');
INSERT INTO olala_online_daily VALUES('435','2016-09-11','384');
INSERT INTO olala_online_daily VALUES('436','2016-09-12','332');
INSERT INTO olala_online_daily VALUES('437','2016-09-13','371');
INSERT INTO olala_online_daily VALUES('438','2016-09-14','338');
INSERT INTO olala_online_daily VALUES('439','2016-09-15','366');
INSERT INTO olala_online_daily VALUES('440','2016-09-16','536');
INSERT INTO olala_online_daily VALUES('441','2016-09-17','345');
INSERT INTO olala_online_daily VALUES('442','2016-09-18','363');
INSERT INTO olala_online_daily VALUES('443','2016-09-19','354');
INSERT INTO olala_online_daily VALUES('444','2016-09-20','359');
INSERT INTO olala_online_daily VALUES('445','2016-09-21','471');
INSERT INTO olala_online_daily VALUES('446','2016-09-22','405');
INSERT INTO olala_online_daily VALUES('447','2016-09-23','460');
INSERT INTO olala_online_daily VALUES('448','2016-09-24','461');
INSERT INTO olala_online_daily VALUES('449','2016-09-25','426');
INSERT INTO olala_online_daily VALUES('450','2016-09-26','432');
INSERT INTO olala_online_daily VALUES('451','2016-09-27','447');
INSERT INTO olala_online_daily VALUES('452','2016-09-28','324');
INSERT INTO olala_online_daily VALUES('453','2016-09-29','167');
INSERT INTO olala_online_daily VALUES('454','2016-09-30','265');
INSERT INTO olala_online_daily VALUES('455','2016-10-01','334');
INSERT INTO olala_online_daily VALUES('456','2016-10-02','272');
INSERT INTO olala_online_daily VALUES('457','2016-10-03','217');
INSERT INTO olala_online_daily VALUES('458','2016-10-04','214');
INSERT INTO olala_online_daily VALUES('459','2016-10-05','367');
INSERT INTO olala_online_daily VALUES('460','2016-10-06','462');
INSERT INTO olala_online_daily VALUES('461','2016-10-07','394');
INSERT INTO olala_online_daily VALUES('462','2016-10-08','321');
INSERT INTO olala_online_daily VALUES('463','2016-10-09','247');
INSERT INTO olala_online_daily VALUES('464','2016-10-10','268');
INSERT INTO olala_online_daily VALUES('465','2016-10-11','348');
INSERT INTO olala_online_daily VALUES('466','2016-10-12','471');
INSERT INTO olala_online_daily VALUES('467','2016-10-13','451');
INSERT INTO olala_online_daily VALUES('468','2016-10-14','502');
INSERT INTO olala_online_daily VALUES('469','2016-10-15','300');
INSERT INTO olala_online_daily VALUES('470','2016-10-16','228');
INSERT INTO olala_online_daily VALUES('471','2016-10-17','234');
INSERT INTO olala_online_daily VALUES('472','2016-10-18','272');
INSERT INTO olala_online_daily VALUES('473','2016-10-19','276');
INSERT INTO olala_online_daily VALUES('474','2016-10-20','366');
INSERT INTO olala_online_daily VALUES('475','2016-10-21','205');
INSERT INTO olala_online_daily VALUES('476','2016-10-22','228');
INSERT INTO olala_online_daily VALUES('477','2016-10-23','304');
INSERT INTO olala_online_daily VALUES('478','2016-10-24','286');
INSERT INTO olala_online_daily VALUES('479','2016-10-25','383');
INSERT INTO olala_online_daily VALUES('480','2016-10-26','338');
INSERT INTO olala_online_daily VALUES('481','2016-10-27','249');
INSERT INTO olala_online_daily VALUES('482','2016-10-28','295');
INSERT INTO olala_online_daily VALUES('483','2016-10-29','542');
INSERT INTO olala_online_daily VALUES('484','2016-10-30','468');
INSERT INTO olala_online_daily VALUES('485','2016-10-31','473');
INSERT INTO olala_online_daily VALUES('486','2016-11-01','300');
INSERT INTO olala_online_daily VALUES('487','2016-11-02','263');
INSERT INTO olala_online_daily VALUES('488','2016-11-03','369');
INSERT INTO olala_online_daily VALUES('489','2016-11-04','320');
INSERT INTO olala_online_daily VALUES('490','2016-11-05','202');
INSERT INTO olala_online_daily VALUES('491','2016-11-06','216');
INSERT INTO olala_online_daily VALUES('492','2016-11-07','243');
INSERT INTO olala_online_daily VALUES('493','2016-11-08','228');
INSERT INTO olala_online_daily VALUES('494','2016-11-09','200');
INSERT INTO olala_online_daily VALUES('495','2016-11-10','335');
INSERT INTO olala_online_daily VALUES('496','2016-11-11','189');
INSERT INTO olala_online_daily VALUES('497','2016-11-12','199');
INSERT INTO olala_online_daily VALUES('498','2016-11-13','476');
INSERT INTO olala_online_daily VALUES('499','2016-11-14','748');
INSERT INTO olala_online_daily VALUES('500','2016-11-15','384');
INSERT INTO olala_online_daily VALUES('501','2016-11-16','535');
INSERT INTO olala_online_daily VALUES('502','2016-11-17','669');
INSERT INTO olala_online_daily VALUES('503','2016-11-18','714');
INSERT INTO olala_online_daily VALUES('504','2016-11-19','778');
INSERT INTO olala_online_daily VALUES('505','2016-11-20','472');
INSERT INTO olala_online_daily VALUES('506','2016-11-21','339');
INSERT INTO olala_online_daily VALUES('507','2016-11-22','489');
INSERT INTO olala_online_daily VALUES('508','2016-11-23','283');
INSERT INTO olala_online_daily VALUES('509','2016-11-24','246');
INSERT INTO olala_online_daily VALUES('510','2016-11-25','276');
INSERT INTO olala_online_daily VALUES('511','2016-11-26','288');
INSERT INTO olala_online_daily VALUES('512','2016-11-27','268');
INSERT INTO olala_online_daily VALUES('513','2016-11-28','504');
INSERT INTO olala_online_daily VALUES('514','2016-11-29','478');
INSERT INTO olala_online_daily VALUES('515','2016-11-30','694');
INSERT INTO olala_online_daily VALUES('516','2016-12-01','524');
INSERT INTO olala_online_daily VALUES('517','2016-12-02','456');
INSERT INTO olala_online_daily VALUES('518','2016-12-03','450');
INSERT INTO olala_online_daily VALUES('519','2016-12-04','248');
INSERT INTO olala_online_daily VALUES('520','2016-12-05','99');
INSERT INTO olala_online_daily VALUES('521','2016-12-06','406');
INSERT INTO olala_online_daily VALUES('522','2016-12-07','508');
INSERT INTO olala_online_daily VALUES('523','2016-12-08','343');
INSERT INTO olala_online_daily VALUES('524','2016-12-09','452');
INSERT INTO olala_online_daily VALUES('525','2016-12-10','356');
INSERT INTO olala_online_daily VALUES('526','2016-12-11','415');
INSERT INTO olala_online_daily VALUES('527','2016-12-12','405');
INSERT INTO olala_online_daily VALUES('528','2016-12-13','260');
INSERT INTO olala_online_daily VALUES('529','2016-12-14','328');
INSERT INTO olala_online_daily VALUES('530','2016-12-15','697');
INSERT INTO olala_online_daily VALUES('531','2016-12-16','506');
INSERT INTO olala_online_daily VALUES('532','2016-12-17','388');
INSERT INTO olala_online_daily VALUES('533','2016-12-18','289');
INSERT INTO olala_online_daily VALUES('534','2016-12-19','312');
INSERT INTO olala_online_daily VALUES('535','2016-12-20','345');
INSERT INTO olala_online_daily VALUES('536','2016-12-21','349');
INSERT INTO olala_online_daily VALUES('537','2016-12-22','228');
INSERT INTO olala_online_daily VALUES('538','2016-12-23','374');
INSERT INTO olala_online_daily VALUES('539','2016-12-24','270');
INSERT INTO olala_online_daily VALUES('540','2016-12-25','201');
INSERT INTO olala_online_daily VALUES('541','2016-12-26','163');
INSERT INTO olala_online_daily VALUES('542','2016-12-27','178');
INSERT INTO olala_online_daily VALUES('543','2016-12-28','204');
INSERT INTO olala_online_daily VALUES('544','2016-12-29','244');
INSERT INTO olala_online_daily VALUES('545','2016-12-30','291');
INSERT INTO olala_online_daily VALUES('546','2016-12-31','535');
INSERT INTO olala_online_daily VALUES('547','2017-01-01','432');
INSERT INTO olala_online_daily VALUES('548','2017-01-02','383');
INSERT INTO olala_online_daily VALUES('549','2017-01-03','456');
INSERT INTO olala_online_daily VALUES('550','2017-01-04','324');
INSERT INTO olala_online_daily VALUES('551','2017-01-05','269');
INSERT INTO olala_online_daily VALUES('552','2017-01-06','117');
INSERT INTO olala_online_daily VALUES('553','2017-01-07','211');
INSERT INTO olala_online_daily VALUES('554','2017-01-08','282');
INSERT INTO olala_online_daily VALUES('555','2017-01-09','259');
INSERT INTO olala_online_daily VALUES('556','2017-01-10','270');
INSERT INTO olala_online_daily VALUES('557','2017-01-11','287');
INSERT INTO olala_online_daily VALUES('558','2017-01-12','287');
INSERT INTO olala_online_daily VALUES('559','2017-01-13','310');
INSERT INTO olala_online_daily VALUES('560','2017-01-14','96');
INSERT INTO olala_online_daily VALUES('561','2017-01-15','138');
INSERT INTO olala_online_daily VALUES('562','2017-01-16','173');
INSERT INTO olala_online_daily VALUES('563','2017-01-17','120');
INSERT INTO olala_online_daily VALUES('564','2017-01-18','206');
INSERT INTO olala_online_daily VALUES('565','2017-01-19','179');
INSERT INTO olala_online_daily VALUES('566','2017-01-20','136');
INSERT INTO olala_online_daily VALUES('567','2017-01-21','152');
INSERT INTO olala_online_daily VALUES('568','2017-01-22','257');
INSERT INTO olala_online_daily VALUES('569','2017-01-23','206');
INSERT INTO olala_online_daily VALUES('570','2017-01-24','226');
INSERT INTO olala_online_daily VALUES('571','2017-01-25','291');
INSERT INTO olala_online_daily VALUES('572','2017-01-26','154');
INSERT INTO olala_online_daily VALUES('573','2017-01-27','64');
INSERT INTO olala_online_daily VALUES('574','2017-01-28','118');
INSERT INTO olala_online_daily VALUES('575','2017-01-29','61');
INSERT INTO olala_online_daily VALUES('576','2017-01-30','89');
INSERT INTO olala_online_daily VALUES('577','2017-01-31','121');
INSERT INTO olala_online_daily VALUES('578','2017-02-01','98');
INSERT INTO olala_online_daily VALUES('579','2017-02-02','229');
INSERT INTO olala_online_daily VALUES('580','2017-02-03','310');
INSERT INTO olala_online_daily VALUES('581','2017-02-04','219');
INSERT INTO olala_online_daily VALUES('582','2017-02-05','254');
INSERT INTO olala_online_daily VALUES('583','2017-02-06','348');
INSERT INTO olala_online_daily VALUES('584','2017-02-07','279');
INSERT INTO olala_online_daily VALUES('585','2017-02-08','249');
INSERT INTO olala_online_daily VALUES('586','2017-02-09','215');
INSERT INTO olala_online_daily VALUES('587','2017-02-10','155');
INSERT INTO olala_online_daily VALUES('588','2017-02-11','140');
INSERT INTO olala_online_daily VALUES('589','2017-02-12','120');
INSERT INTO olala_online_daily VALUES('590','2017-02-13','154');
INSERT INTO olala_online_daily VALUES('591','2017-02-14','327');
INSERT INTO olala_online_daily VALUES('592','2017-02-15','314');
INSERT INTO olala_online_daily VALUES('593','2017-02-16','292');
INSERT INTO olala_online_daily VALUES('594','2017-02-17','183');
INSERT INTO olala_online_daily VALUES('595','2017-02-18','276');
INSERT INTO olala_online_daily VALUES('596','2017-02-19','211');
INSERT INTO olala_online_daily VALUES('597','2017-02-20','247');
INSERT INTO olala_online_daily VALUES('598','2017-02-21','141');
INSERT INTO olala_online_daily VALUES('599','2017-02-22','138');
INSERT INTO olala_online_daily VALUES('600','2017-02-23','166');
INSERT INTO olala_online_daily VALUES('601','2017-02-24','100');
INSERT INTO olala_online_daily VALUES('602','2017-02-25','175');
INSERT INTO olala_online_daily VALUES('603','2017-02-26','163');
INSERT INTO olala_online_daily VALUES('604','2017-02-27','6');
INSERT INTO olala_online_daily VALUES('605','2017-02-28','1');
INSERT INTO olala_online_daily VALUES('606','2017-03-01','3');
INSERT INTO olala_online_daily VALUES('607','2017-03-05','6');
INSERT INTO olala_online_daily VALUES('608','2017-03-06','1');
INSERT INTO olala_online_daily VALUES('609','2017-03-07','4');
INSERT INTO olala_online_daily VALUES('610','2017-03-08','97');
INSERT INTO olala_online_daily VALUES('611','2017-03-09','6');
INSERT INTO olala_online_daily VALUES('612','2017-03-10','1');
INSERT INTO olala_online_daily VALUES('613','2017-03-11','1');
INSERT INTO olala_online_daily VALUES('614','2017-03-11','1');
INSERT INTO olala_online_daily VALUES('615','2017-03-13','2');
INSERT INTO olala_online_daily VALUES('616','2017-03-14','2');
INSERT INTO olala_online_daily VALUES('617','2017-03-15','3');
INSERT INTO olala_online_daily VALUES('618','2017-03-20','3');
INSERT INTO olala_online_daily VALUES('619','2017-03-21','2');
INSERT INTO olala_online_daily VALUES('620','2017-04-16','1');
INSERT INTO olala_online_daily VALUES('621','2017-04-17','5');
INSERT INTO olala_online_daily VALUES('622','2017-04-21','3');
INSERT INTO olala_online_daily VALUES('623','2017-04-22','1');
INSERT INTO olala_online_daily VALUES('624','2017-04-26','1');
INSERT INTO olala_online_daily VALUES('625','2017-04-28','6');
INSERT INTO olala_online_daily VALUES('626','2017-04-29','3');
INSERT INTO olala_online_daily VALUES('627','2017-05-03','4');
INSERT INTO olala_online_daily VALUES('628','2017-05-04','2');
INSERT INTO olala_online_daily VALUES('629','2017-05-05','7');
INSERT INTO olala_online_daily VALUES('630','2017-05-07','9');
INSERT INTO olala_online_daily VALUES('631','2017-05-08','1');
INSERT INTO olala_online_daily VALUES('632','2017-05-09','6');
INSERT INTO olala_online_daily VALUES('633','2017-05-10','6');
INSERT INTO olala_online_daily VALUES('634','2017-05-12','1');
INSERT INTO olala_online_daily VALUES('635','2017-05-16','2');
INSERT INTO olala_online_daily VALUES('636','2017-05-17','11');
INSERT INTO olala_online_daily VALUES('637','2017-05-18','30');
INSERT INTO olala_online_daily VALUES('638','2017-05-19','10');
INSERT INTO olala_online_daily VALUES('639','2017-05-20','8');
INSERT INTO olala_online_daily VALUES('640','2017-05-21','20');
INSERT INTO olala_online_daily VALUES('641','2017-05-22','3');
INSERT INTO olala_online_daily VALUES('642','2017-05-23','3');
INSERT INTO olala_online_daily VALUES('643','2017-05-29','1');
INSERT INTO olala_online_daily VALUES('644','2017-05-30','2');
INSERT INTO olala_online_daily VALUES('645','2017-05-31','3');
INSERT INTO olala_online_daily VALUES('646','2017-06-01','1');
INSERT INTO olala_online_daily VALUES('647','2017-06-03','1');
INSERT INTO olala_online_daily VALUES('648','2017-06-07','1');
INSERT INTO olala_online_daily VALUES('649','2017-06-08','3');
INSERT INTO olala_online_daily VALUES('650','2017-06-09','6');
INSERT INTO olala_online_daily VALUES('651','2017-06-11','1');
INSERT INTO olala_online_daily VALUES('652','2017-06-12','6');
INSERT INTO olala_online_daily VALUES('653','2017-06-13','16');
INSERT INTO olala_online_daily VALUES('654','2017-06-14','1');
INSERT INTO olala_online_daily VALUES('655','2017-06-15','2');
INSERT INTO olala_online_daily VALUES('656','2017-06-16','1');
INSERT INTO olala_online_daily VALUES('657','2017-06-17','2');
INSERT INTO olala_online_daily VALUES('658','2017-06-18','5');
INSERT INTO olala_online_daily VALUES('659','2017-06-21','1');
INSERT INTO olala_online_daily VALUES('660','2017-06-22','1');
INSERT INTO olala_online_daily VALUES('661','2017-06-23','2');
INSERT INTO olala_online_daily VALUES('662','2017-06-24','1');
INSERT INTO olala_online_daily VALUES('663','2017-06-26','4');
INSERT INTO olala_online_daily VALUES('664','2017-06-27','12');
INSERT INTO olala_online_daily VALUES('665','2017-06-28','25');
INSERT INTO olala_online_daily VALUES('666','2017-06-29','36');
INSERT INTO olala_online_daily VALUES('667','2017-06-30','50');
INSERT INTO olala_online_daily VALUES('668','2017-07-01','46');
INSERT INTO olala_online_daily VALUES('669','2017-07-02','55');
INSERT INTO olala_online_daily VALUES('670','2017-07-03','83');
INSERT INTO olala_online_daily VALUES('671','2017-07-04','60');
INSERT INTO olala_online_daily VALUES('672','2017-07-05','3');
INSERT INTO olala_online_daily VALUES('673','2017-07-06','10');
INSERT INTO olala_online_daily VALUES('674','2017-07-07','1');
INSERT INTO olala_online_daily VALUES('675','2017-07-09','1');
INSERT INTO olala_online_daily VALUES('676','2017-07-11','12');
INSERT INTO olala_online_daily VALUES('677','2017-07-12','8');
INSERT INTO olala_online_daily VALUES('678','2017-07-13','3');
INSERT INTO olala_online_daily VALUES('679','2017-07-17','2');
INSERT INTO olala_online_daily VALUES('680','2017-07-18','1');
INSERT INTO olala_online_daily VALUES('681','2017-07-21','1');
INSERT INTO olala_online_daily VALUES('682','2017-07-28','1');
INSERT INTO olala_online_daily VALUES('683','2017-08-04','1');
INSERT INTO olala_online_daily VALUES('684','2017-08-05','5');
INSERT INTO olala_online_daily VALUES('685','2017-08-06','2');
INSERT INTO olala_online_daily VALUES('686','2017-08-07','3');
INSERT INTO olala_online_daily VALUES('687','2017-08-08','2');
INSERT INTO olala_online_daily VALUES('688','2017-08-09','1');
INSERT INTO olala_online_daily VALUES('689','2017-08-10','3');
INSERT INTO olala_online_daily VALUES('690','2017-08-11','1');
INSERT INTO olala_online_daily VALUES('691','2017-08-12','1');
INSERT INTO olala_online_daily VALUES('692','2017-08-13','1');
INSERT INTO olala_online_daily VALUES('693','2017-11-27','1');
INSERT INTO olala_online_daily VALUES('694','2017-11-29','4');
INSERT INTO olala_online_daily VALUES('695','2017-11-30','5');
INSERT INTO olala_online_daily VALUES('696','2017-12-01','5');
INSERT INTO olala_online_daily VALUES('697','2017-12-02','4');
INSERT INTO olala_online_daily VALUES('698','2017-12-03','4');
INSERT INTO olala_online_daily VALUES('699','2017-12-04','4');
INSERT INTO olala_online_daily VALUES('700','2017-12-05','2');
INSERT INTO olala_online_daily VALUES('701','2017-12-06','3');
INSERT INTO olala_online_daily VALUES('702','2017-12-07','1');
INSERT INTO olala_online_daily VALUES('703','2017-12-08','2');
INSERT INTO olala_online_daily VALUES('704','2017-12-09','3');
INSERT INTO olala_online_daily VALUES('705','2017-12-13','1');
INSERT INTO olala_online_daily VALUES('706','2017-12-16','2');
INSERT INTO olala_online_daily VALUES('707','2017-12-17','1');
INSERT INTO olala_online_daily VALUES('708','2017-12-18','5');
INSERT INTO olala_online_daily VALUES('709','2017-12-19','6');
INSERT INTO olala_online_daily VALUES('710','2017-12-20','6');
INSERT INTO olala_online_daily VALUES('711','2017-12-21','1');
INSERT INTO olala_online_daily VALUES('712','2017-12-22','1');
INSERT INTO olala_online_daily VALUES('713','2017-12-24','4');
INSERT INTO olala_online_daily VALUES('714','2017-12-25','3');
INSERT INTO olala_online_daily VALUES('715','2017-12-27','2');
INSERT INTO olala_online_daily VALUES('716','2017-12-28','1');
INSERT INTO olala_online_daily VALUES('717','2017-12-30','5');
INSERT INTO olala_online_daily VALUES('718','2017-12-31','1');
INSERT INTO olala_online_daily VALUES('719','2018-01-01','4');
INSERT INTO olala_online_daily VALUES('720','2018-01-06','1');
INSERT INTO olala_online_daily VALUES('721','2018-01-08','1');
INSERT INTO olala_online_daily VALUES('722','2018-01-09','6');
INSERT INTO olala_online_daily VALUES('723','2018-01-10','6');
INSERT INTO olala_online_daily VALUES('724','2018-01-11','4');
INSERT INTO olala_online_daily VALUES('725','2018-01-12','2');
INSERT INTO olala_online_daily VALUES('726','2018-01-14','3');
INSERT INTO olala_online_daily VALUES('727','2018-01-15','21');
INSERT INTO olala_online_daily VALUES('728','2018-01-16','13');
INSERT INTO olala_online_daily VALUES('729','2018-01-17','14');
INSERT INTO olala_online_daily VALUES('730','2018-01-18','2');
INSERT INTO olala_online_daily VALUES('731','2018-01-19','8');
INSERT INTO olala_online_daily VALUES('732','2018-01-20','3');
INSERT INTO olala_online_daily VALUES('733','2018-01-23','4');
INSERT INTO olala_online_daily VALUES('734','2018-01-24','1');
INSERT INTO olala_online_daily VALUES('735','2018-01-25','15');
INSERT INTO olala_online_daily VALUES('736','2018-01-26','8');
INSERT INTO olala_online_daily VALUES('737','2018-01-27','3');
INSERT INTO olala_online_daily VALUES('738','2018-01-28','5');
INSERT INTO olala_online_daily VALUES('739','2018-01-29','6');
INSERT INTO olala_online_daily VALUES('740','2018-01-31','3');
INSERT INTO olala_online_daily VALUES('741','2018-02-01','2');
INSERT INTO olala_online_daily VALUES('742','2018-02-02','1');
INSERT INTO olala_online_daily VALUES('743','2018-02-03','2');
INSERT INTO olala_online_daily VALUES('744','2018-02-05','4');
INSERT INTO olala_online_daily VALUES('745','2018-02-06','5');
INSERT INTO olala_online_daily VALUES('746','2018-02-07','1');
INSERT INTO olala_online_daily VALUES('747','2018-02-08','6');
INSERT INTO olala_online_daily VALUES('748','2018-02-09','4');
INSERT INTO olala_online_daily VALUES('749','2018-02-10','10');
INSERT INTO olala_online_daily VALUES('750','2018-02-11','2');
INSERT INTO olala_online_daily VALUES('751','2018-02-23','5');
INSERT INTO olala_online_daily VALUES('752','2018-02-24','3');
INSERT INTO olala_online_daily VALUES('753','2018-02-26','4');
INSERT INTO olala_online_daily VALUES('754','2018-02-27','9');
INSERT INTO olala_online_daily VALUES('755','2018-02-28','9');
INSERT INTO olala_online_daily VALUES('756','2018-03-01','1');
INSERT INTO olala_online_daily VALUES('757','2018-03-05','1');
INSERT INTO olala_online_daily VALUES('758','2018-03-10','7');
INSERT INTO olala_online_daily VALUES('759','2018-03-19','2');
INSERT INTO olala_online_daily VALUES('760','2018-04-24','1');

-- --------------------------------------------------------

CREATE TABLE `olala_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `ip` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL DEFAULT 'fa-shopping-cart',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_others` (
  `others_id` int(11) NOT NULL AUTO_INCREMENT,
  `others_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `p_from` double NOT NULL DEFAULT '0',
  `p_to` double NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`others_id`)
) ENGINE=InnoDB AUTO_INCREMENT=188 DEFAULT CHARSET=utf8;

INSERT INTO olala_others VALUES('1','1','Đông','huong-dong','0','0','1','1','0','1493924049','1495564275','1');
INSERT INTO olala_others VALUES('2','1','Tây','huong-tay','0','0','2','1','0','1493924055','1495564280','1');
INSERT INTO olala_others VALUES('3','1','Nam','huong-nam','0','0','3','1','0','1493924080','1495564287','1');
INSERT INTO olala_others VALUES('4','1','Bắc','huong-bac','0','0','4','1','0','1493924087','1495564294','1');
INSERT INTO olala_others VALUES('5','1','Đông Bắc','huong-dong-bac','0','0','5','1','0','1493924548','1495564300','1');
INSERT INTO olala_others VALUES('6','1','Đông Nam','huong-dong-nam','0','0','6','1','0','1493924554','1495564306','1');
INSERT INTO olala_others VALUES('7','1','Tây Bắc','huong-tay-bac','0','0','7','1','0','1493924560','1495564312','1');
INSERT INTO olala_others VALUES('8','1','Tây Nam','huong-tay-nam','0','0','8','1','0','1493924580','1495564320','1');
INSERT INTO olala_others VALUES('9','1','(không xác định)','huong-khong-xac-dinh','0','0','9','1','0','1493924585','1494962163','1');
INSERT INTO olala_others VALUES('10','2','3m75','3m75','0','0','1','1','0','1493924665','1494962014','1');
INSERT INTO olala_others VALUES('11','2','5m5','5m5','0','0','2','1','0','1493924674','1494962014','1');
INSERT INTO olala_others VALUES('12','2','7m5','7m5','0','0','3','1','0','1493924685','1494962014','1');
INSERT INTO olala_others VALUES('13','2','10m5','10m5','0','0','4','1','0','1493924699','1494962014','1');
INSERT INTO olala_others VALUES('14','2','11m5','11m5','0','0','5','1','0','1493924709','1494962014','1');
INSERT INTO olala_others VALUES('15','2','15m','15m','0','0','6','1','0','1493924717','1494962014','1');
INSERT INTO olala_others VALUES('16','2','21m','21m','0','0','7','1','0','1493924721','1494962015','1');
INSERT INTO olala_others VALUES('17','2','24m','24m','0','0','8','1','0','1493924727','1494962015','1');
INSERT INTO olala_others VALUES('18','2','30m','30m','0','0','9','1','0','1493924735','1494962015','1');
INSERT INTO olala_others VALUES('19','2','33m','33m','0','0','10','1','0','1493924748','1494962015','1');
INSERT INTO olala_others VALUES('20','2','42m','42m','0','0','11','1','0','1493924753','1494962015','1');
INSERT INTO olala_others VALUES('21','2','48m','48m','0','0','12','1','0','1493924825','1494962016','1');
INSERT INTO olala_others VALUES('22','2','60m','60m','0','0','13','1','0','1493924830','1494962016','1');
INSERT INTO olala_others VALUES('23','2','(không xác định)','duong-khong-xac-dinh','0','0','14','1','0','1493924837','1494962229','1');
INSERT INTO olala_others VALUES('24','6','(không xác định)','khong-xac-dinh','0','0','1','1','0','0','1494962255','1');
INSERT INTO olala_others VALUES('25','6','Lê Duẩn','le-duan','0','0','2','1','0','0','1494962017','1');
INSERT INTO olala_others VALUES('26','6','Phan Chu Trinh','phan-chu-trinh','0','0','3','1','0','0','1494962017','1');
INSERT INTO olala_others VALUES('27','6','Hàm Nghi','ham-nghi','0','0','4','1','0','0','1494962017','1');
INSERT INTO olala_others VALUES('28','6','Hùng Vương','hung-vuong','0','0','5','1','0','0','1494962017','1');
INSERT INTO olala_others VALUES('29','6','Trần Hưng Đạo','tran-hung-dao','0','0','6','1','0','0','1494962017','1');
INSERT INTO olala_others VALUES('30','6','Phan Thanh','phan-thanh','0','0','7','1','0','0','1494962017','1');
INSERT INTO olala_others VALUES('31','6','Võ Nguyên Giáp','vo-nguyen-giap','0','0','8','1','0','0','1494962017','1');
INSERT INTO olala_others VALUES('32','6','Nguyễn Chí Thanh','nguyen-chi-thanh','0','0','9','1','0','0','1494962017','1');
INSERT INTO olala_others VALUES('33','6','Nguyễn Văn Linh','nguyen-van-linh','0','0','10','1','0','0','1494962017','1');
INSERT INTO olala_others VALUES('34','6','Nguyễn Sinh Sắc','nguyen-sinh-sac','0','0','11','1','0','0','1494962476','1');
INSERT INTO olala_others VALUES('35','6','Lê Bôi','le-boi','0','0','13','1','0','0','1494962017','1');
INSERT INTO olala_others VALUES('36','6','Đống Đa','dong-da','0','0','14','1','0','0','1494962018','1');
INSERT INTO olala_others VALUES('37','6','Trần Quốc Hoàn','tran-quoc-hoan','0','0','15','1','0','0','1494962018','1');
INSERT INTO olala_others VALUES('38','6','Nguyễn Tất Thành','nguyen-tat-thanh','0','0','16','1','0','0','1494962545','1');
INSERT INTO olala_others VALUES('39','6','Hoài Thanh','hoai-thanh','0','0','17','1','0','0','1494962018','1');
INSERT INTO olala_others VALUES('40','6','Mỹ Đa Tây 2','my-da-tay-2','0','0','17','1','0','0','1494962018','1');
INSERT INTO olala_others VALUES('41','6','Trưng Nữ Vương','trung-nu-vuong','0','0','18','1','0','0','1494962018','1');
INSERT INTO olala_others VALUES('42','6','2 Tháng 9','2-thang-9','0','0','20','1','0','0','1494962018','1');
INSERT INTO olala_others VALUES('43','6','Nguyễn Lộ Trạc','nguyen-lo-trac','0','0','21','1','0','0','1494962019','1');
INSERT INTO olala_others VALUES('44','6','Tuệ Tĩnh','tue-tinh','0','0','22','1','0','0','1494962019','1');
INSERT INTO olala_others VALUES('45','6','Kinh Dương Vương','kinh-duong-vuong','0','0','23','1','0','0','1494962019','1');
INSERT INTO olala_others VALUES('46','6','Tiểu La','tieu-la','0','0','24','1','0','0','1494962019','1');
INSERT INTO olala_others VALUES('47','6','Trần Bình Trọng','tran-binh-trong','0','0','25','1','0','0','1494962019','1');
INSERT INTO olala_others VALUES('48','6','Trưng Nhị','trung-nhi','0','0','26','1','0','0','1494962019','1');
INSERT INTO olala_others VALUES('49','6','Anh Thơ','anh-tho','0','0','27','1','0','0','1494962019','1');
INSERT INTO olala_others VALUES('50','6','Núi Thành','dg-nui-thanh','0','0','28','1','0','0','1495043912','1');
INSERT INTO olala_others VALUES('51','6','Lương Ngọc Quyến','luong-ngoc-quyen','0','0','29','1','0','0','1494962020','1');
INSERT INTO olala_others VALUES('52','6','Bàu Hạc 1','bau-hac-1','0','0','30','1','0','0','1494962020','1');
INSERT INTO olala_others VALUES('53','6','Đỗ Quang','do-quang','0','0','31','1','0','0','1494962020','1');
INSERT INTO olala_others VALUES('54','6','Lê Đình Dương','le-dinh-duong','0','0','32','1','0','0','1494962020','1');
INSERT INTO olala_others VALUES('55','6','Hồ Xuân Hương','ho-xuan-huong','0','0','33','1','0','0','1494962020','1');
INSERT INTO olala_others VALUES('56','6','Cù Chính Lan','cu-chinh-lan','0','0','34','1','0','0','1494962020','1');
INSERT INTO olala_others VALUES('57','6','Phạm Văn Nghị','pham-van-nghi','0','0','35','1','0','0','1494962020','1');
INSERT INTO olala_others VALUES('58','6','Nguyễn Trung Trực','nguyen-trung-truc','0','0','36','1','0','0','1494962020','1');
INSERT INTO olala_others VALUES('59','6','Hoàng Hoa Thám','hoang-hoa-tham','0','0','37','1','0','0','1494962020','1');
INSERT INTO olala_others VALUES('60','6','Nguyễn Chí Diễu ','nguyen-chi-dieu','0','0','38','1','0','0','1494962020','1');
INSERT INTO olala_others VALUES('61','6','Điện Biên Phủ','dien-bien-phu','0','0','39','1','0','0','1494962020','1');
INSERT INTO olala_others VALUES('62','6','Đa Phước 4','da-phuoc-4','0','0','40','1','0','0','1494962020','1');
INSERT INTO olala_others VALUES('63','6','3 Tháng 2','3-thang-2','0','0','40','1','0','0','1494962020','1');
INSERT INTO olala_others VALUES('64','6','30 Tháng 4','30-thang-4','0','0','41','1','0','0','1494962021','1');
INSERT INTO olala_others VALUES('65','6','Hoàng Sa','dg-hoang-sa','0','0','42','1','0','0','1495043506','1');
INSERT INTO olala_others VALUES('66','6','Trường Sa','truong-sa','0','0','43','1','0','0','1494962021','1');
INSERT INTO olala_others VALUES('67','6','Võ Văn Kiệt','vo-van-kiet','0','0','44','1','0','0','1494962021','1');
INSERT INTO olala_others VALUES('68','6','Tô Hiến Thành','to-hien-thanh','0','0','45','1','0','0','1494962021','1');
INSERT INTO olala_others VALUES('69','6','Huỳnh Thúc Kháng','huynh-thuc-khang','0','0','46','1','0','0','1494962021','1');
INSERT INTO olala_others VALUES('70','6','Ngọc Hân','ngoc-han','0','0','47','1','0','0','1494962021','1');
INSERT INTO olala_others VALUES('71','6','Mai Hắc Đế','mai-hac-de','0','0','48','1','0','0','1494962021','1');
INSERT INTO olala_others VALUES('72','6','Lê Chân','le-chan','0','0','49','1','0','0','1494962022','1');
INSERT INTO olala_others VALUES('73','6','Nguyễn Thiếp','nguyen-thiep','0','0','50','1','0','0','1494962022','1');
INSERT INTO olala_others VALUES('74','6','Trục 42m','truc-42m','0','0','51','1','0','0','1494962022','1');
INSERT INTO olala_others VALUES('75','6','An Cư 7','an-cu-7','0','0','52','1','0','0','1494962022','1');
INSERT INTO olala_others VALUES('76','6','Tản Đà','tan-da','0','0','53','1','0','0','1494962023','1');
INSERT INTO olala_others VALUES('77','6','Hồ Thấu','ho-thau','0','0','54','1','0','0','1494962023','1');
INSERT INTO olala_others VALUES('78','6','Nguyễn Lộ Trạch','nguyen-lo-trach','0','0','55','1','0','0','1494962023','1');
INSERT INTO olala_others VALUES('79','6','Phạm Văn Đồng','pham-van-dong','0','0','56','1','0','0','1494962023','1');
INSERT INTO olala_others VALUES('80','6','Phước Trường','phuoc-truong','0','0','57','1','0','0','1494962024','1');
INSERT INTO olala_others VALUES('81','6','Nguyễn Cao Luyện','nguyen-cao-luyen','0','0','58','1','0','0','1494962024','1');
INSERT INTO olala_others VALUES('82','6','Lê Đình Lý','le-dinh-ly','0','0','59','1','0','0','1494962024','1');
INSERT INTO olala_others VALUES('83','6','Mỹ An 5','my-an-5','0','0','60','1','0','0','1494962024','1');
INSERT INTO olala_others VALUES('84','6','Đỗ Bí','do-bi','0','0','61','1','0','0','1494962024','1');
INSERT INTO olala_others VALUES('85','6','Hoàng Diệu','hoang-dieu','0','0','62','1','0','0','1494962024','1');
INSERT INTO olala_others VALUES('86','6','Nam Sơn','nam-son','0','0','63','1','0','0','1494962024','1');
INSERT INTO olala_others VALUES('87','6','Ung Văn Khiêm','ung-van-khiem','0','0','64','1','0','0','1494962025','1');
INSERT INTO olala_others VALUES('88','6','Tống Phước Phổ','tong-phuoc-pho','0','0','65','1','0','0','1494962025','1');
INSERT INTO olala_others VALUES('89','6','Trần Phú','tran-phu','0','0','66','1','0','0','1494962025','1');
INSERT INTO olala_others VALUES('90','6','Dương Trí Trạch','duong-tri-trach','0','0','68','1','0','0','1494962025','1');
INSERT INTO olala_others VALUES('91','6','Hàn Thuyên','han-thuyen','0','0','69','1','0','0','1494962025','1');
INSERT INTO olala_others VALUES('92','6','Trần Nguyên Hãn','tran-nguyen-han','0','0','70','1','0','0','1494962025','1');
INSERT INTO olala_others VALUES('93','6','Lê Lợi','le-loi','0','0','71','1','0','0','1494962026','1');
INSERT INTO olala_others VALUES('94','6','Sơn Thủy Đông 4','son-thuy-dong-4','0','0','73','1','0','0','1494962026','1');
INSERT INTO olala_others VALUES('95','6','Võ Văn Tần','vo-van-tan','0','0','73','1','0','0','1494962026','1');
INSERT INTO olala_others VALUES('96','6','Phước Trường 14','phuoc-truong-14','0','0','74','1','0','0','1494962026','1');
INSERT INTO olala_others VALUES('97','6','Thanh Long','thanh-long','0','0','75','1','0','0','1494962026','1');
INSERT INTO olala_others VALUES('98','6','Cô Giang','co-giang','0','0','76','1','0','0','1494962026','1');
INSERT INTO olala_others VALUES('99','6','Lê Quang Đạo','le-quang-dao','0','0','77','1','0','0','1494962026','1');
INSERT INTO olala_others VALUES('100','6','An Thượng 30','an-thuong-30','0','0','78','1','0','0','1494962027','1');
INSERT INTO olala_others VALUES('101','6','Phan Tôn','phan-ton','0','0','78','1','0','0','1494962027','1');
INSERT INTO olala_others VALUES('102','6','Hoàng Văn Thụ','hoang-van-thu','0','0','79','1','0','0','1494962027','1');
INSERT INTO olala_others VALUES('103','6','Nguyễn Khuyến','nguyen-khuyen','0','0','80','1','0','0','1494962680','1');
INSERT INTO olala_others VALUES('104','6','Lưu Quý Kỳ','luu-quy-ky','0','0','81','1','0','0','1494962027','1');
INSERT INTO olala_others VALUES('105','6','Đầm Rong 2','dam-rong-2','0','0','82','1','0','0','1494962028','1');
INSERT INTO olala_others VALUES('106','6','Hoàng Bích Sơn','hoang-bich-son','0','0','83','1','0','0','1494962028','1');
INSERT INTO olala_others VALUES('107','6','Phạm Như Xương','pham-nhu-xuong','0','0','84','1','0','0','1494962769','1');
INSERT INTO olala_others VALUES('108','6','Võ Như Hưng','vo-nhu-hung','0','0','85','1','0','0','1494962028','1');
INSERT INTO olala_others VALUES('109','6','Tùng Thiên Vương','tung-thien-vuong','0','0','86','1','0','0','1494962028','1');
INSERT INTO olala_others VALUES('110','6','Nguyễn Hữu Thọ','nguyen-huu-tho','0','0','87','1','0','0','1494962028','1');
INSERT INTO olala_others VALUES('111','6','Đặng Văn Ngữ','dang-van-ngu','0','0','88','1','0','0','1494962028','1');
INSERT INTO olala_others VALUES('112','6','Tân Thuận','tan-thuan','0','0','89','1','0','0','1494962029','1');
INSERT INTO olala_others VALUES('113','6','Thanh Thủy ','thanh-thuy','0','0','90','1','0','0','1494962029','1');
INSERT INTO olala_others VALUES('114','6','Lê Hữu Trác','le-huu-trac','0','0','91','1','0','0','1494962029','1');
INSERT INTO olala_others VALUES('115','6','Đa Mặn 3','da-man-3','0','0','92','1','0','0','1494962029','1');
INSERT INTO olala_others VALUES('116','6','Trần Đức Thông','tran-duc-thong','0','0','93','1','0','0','1494962029','1');
INSERT INTO olala_others VALUES('117','6','Lê Văn Hiến','le-van-hien','0','0','94','1','0','0','1494962029','1');
INSERT INTO olala_others VALUES('118','6','Khúc Hạo','khuc-hao','0','0','95','1','0','0','1494962029','1');
INSERT INTO olala_others VALUES('119','6','Đông Giang','dg-dong-giang','0','0','96','1','0','0','1495043830','1');
INSERT INTO olala_others VALUES('120','6','Hải Phòng','hai-phong','0','0','97','1','0','0','1494962029','1');
INSERT INTO olala_others VALUES('121','6','Hồ Nghinh','ho-nghinh','0','0','98','1','0','0','1494962029','1');
INSERT INTO olala_others VALUES('122','6','Dương Tự Minh','duong-tu-minh','0','0','99','1','0','0','1494962029','1');
INSERT INTO olala_others VALUES('123','6','Nguyễn Văn Huyên','nguyen-van-huyen','0','0','100','1','0','0','1494962030','1');
INSERT INTO olala_others VALUES('124','6','Phùng Hưng','phung-hung','0','0','101','1','0','0','1494962030','1');
INSERT INTO olala_others VALUES('125','6','Phan Châu Trinh','phan-chau-trinh','0','0','102','1','0','0','1494962030','1');
INSERT INTO olala_others VALUES('126','6','Bàu Năng 3','bau-nang-3','0','0','103','1','0','0','1494962030','1');
INSERT INTO olala_others VALUES('127','6','Nguyễn Đức An','nguyen-duc-an','0','0','104','1','0','0','1494962030','1');
INSERT INTO olala_others VALUES('128','6','Lê Thước','le-thuoc','0','0','105','1','0','0','1494962030','1');
INSERT INTO olala_others VALUES('129','6','Đông Kinh Nghĩa Thục','dong-kinh-nghia-thuc','0','0','106','1','0','0','1494962030','1');
INSERT INTO olala_others VALUES('130','6','Dương Đình Nghệ','duong-dinh-nghe','0','0','107','1','0','0','1494962030','1');
INSERT INTO olala_others VALUES('131','3','Hải Châu','hai-chau','0','0','1','1','0','1495043231','1495043231','1');
INSERT INTO olala_others VALUES('132','3','Thanh Khê','thanh-khe','0','0','2','1','0','1495043240','1495043240','1');
INSERT INTO olala_others VALUES('133','3','Liên Chiểu','lien-chieu','0','0','3','1','0','1495043251','1495043251','1');
INSERT INTO olala_others VALUES('134','3','Cẩm Lệ','cam-le','0','0','4','1','0','1495043259','1495043259','1');
INSERT INTO olala_others VALUES('135','3','Sơn Trà','son-tra','0','0','5','1','0','1495043267','1495043267','1');
INSERT INTO olala_others VALUES('136','3','Ngũ Hành Sơn','ngu-hanh-son','0','0','6','1','0','1495043278','1495043278','1');
INSERT INTO olala_others VALUES('137','3','Hòa Vang','hoa-vang','0','0','7','1','0','1495043293','1495043293','1');
INSERT INTO olala_others VALUES('138','3','Hoàng Sa','hoang-sa','0','0','8','1','0','1495043633','1495043633','1');
INSERT INTO olala_others VALUES('139','4','Tam Kỳ','tam-ky','0','0','1','1','0','1495043672','1495043672','1');
INSERT INTO olala_others VALUES('140','4','Hội An','hoi-an','0','0','2','1','0','1495043679','1495043679','1');
INSERT INTO olala_others VALUES('141','4','Tây Giang','tay-giang','0','0','3','1','0','1495043686','1495043686','1');
INSERT INTO olala_others VALUES('142','4','Phú Ninh','phu-ninh','0','0','4','1','0','1495043731','1495043731','1');
INSERT INTO olala_others VALUES('143','4','Đại Lộc','dai-loc','0','0','5','1','0','1495043737','1495043737','1');
INSERT INTO olala_others VALUES('144','4','Nam Giang','nam-giang','0','0','6','1','0','1495043743','1495043743','1');
INSERT INTO olala_others VALUES('145','4','Đông Giang','dong-giang','0','0','7','1','0','1495043787','1495043835','1');
INSERT INTO olala_others VALUES('146','4','Nông Sơn','nong-son','0','0','8','1','0','1495043848','1495043848','1');
INSERT INTO olala_others VALUES('147','4','Hiệp Đức','hiep-duc','0','0','9','1','0','1495043854','1495043854','1');
INSERT INTO olala_others VALUES('148','4','Quế Sơn','que-son','0','0','10','1','0','1495043860','1495043860','1');
INSERT INTO olala_others VALUES('149','4','Tiên Phước','tien-phuoc','0','0','11','1','0','1495043869','1495043869','1');
INSERT INTO olala_others VALUES('150','4','Phước Sơn','phuoc-son','0','0','12','1','0','1495043876','1495043876','1');
INSERT INTO olala_others VALUES('151','4','Núi Thành','nui-thanh','0','0','13','1','0','1495043916','1495043916','1');
INSERT INTO olala_others VALUES('152','4','Nam Trà My','nam-tra-my','0','0','14','1','0','1495043925','1495043925','1');
INSERT INTO olala_others VALUES('153','4','Điện Bàn','dien-ban','0','0','15','1','0','1495043934','1495043934','1');
INSERT INTO olala_others VALUES('154','4','Duy Xuyên','duy-xuyen','0','0','16','1','0','1495043942','1495043942','1');
INSERT INTO olala_others VALUES('155','4','Thăng Bình','thang-binh','0','0','17','1','0','1495043951','1495043951','1');
INSERT INTO olala_others VALUES('156','4','Bắc Trà My','bac-tra-my','0','0','18','1','0','1495043958','1495043958','1');
INSERT INTO olala_others VALUES('161','6','Trường Chinh','truong-chinh','0','0','108','1','0','1495218192','1495218192','1');
INSERT INTO olala_others VALUES('164','6','Con Đường Màu Xanh','con-duong-mau-xanh','0','0','109','1','0','1495222047','1495222047','1');
INSERT INTO olala_others VALUES('165','6','','','0','0','110','1','0','1495222128','1495222128','1');
INSERT INTO olala_others VALUES('166','6','Bình Hòa','binh-hoa','0','0','111','1','0','1495381088','1495381088','1');
INSERT INTO olala_others VALUES('167','6','Khuê Mỹ Đông','khue-my-dong','0','0','112','1','0','1498926932','1498926932','1');
INSERT INTO olala_others VALUES('168','6','Lê Ninh','le-ninh','0','0','113','1','0','1498928147','1498928147','1');
INSERT INTO olala_others VALUES('169','6','Lê Mạnh Trinh','le-manh-trinh','0','0','114','1','0','1498928519','1498928519','1');
INSERT INTO olala_others VALUES('170','6','An Thượng 4','an-thuong-4','0','0','115','1','0','1498928766','1498928766','1');
INSERT INTO olala_others VALUES('171','6','Hoàng Kế Viêm','hoang-ke-viem','0','0','116','1','0','1498929615','1498929615','1');
INSERT INTO olala_others VALUES('172','6','Bà Huyện Thanh Quan','ba-huyen-thanh-quan','0','0','117','1','0','1499008385','1499008385','27');
INSERT INTO olala_others VALUES('173','6','Đỗ Bí','do-bi-yqvusr6aby','0','0','118','1','0','1499008657','1499008657','27');
INSERT INTO olala_others VALUES('174','6','Lê Văn Lương','le-van-luong','0','0','119','1','0','1499008863','1499008863','27');
INSERT INTO olala_others VALUES('175','6','Quốc Lộ 1A','quoc-lo-1a','0','0','120','1','0','1499009230','1499009230','27');
INSERT INTO olala_others VALUES('176','6','An Thượng 29','an-thuong-29','0','0','121','1','0','1499009642','1499009642','27');
INSERT INTO olala_others VALUES('177','6','Châu Thị Vĩnh Tế','chau-thi-vinh-te','0','0','122','1','0','1499010011','1499010011','27');
INSERT INTO olala_others VALUES('178','6','Nguyễn Khoa Chiêm','nguyen-khoa-chiem','0','0','123','1','0','1499010152','1499010152','27');
INSERT INTO olala_others VALUES('179','6','Bùi Thị Xuân','bui-thi-xuan','0','0','124','1','0','1499010306','1499010306','27');
INSERT INTO olala_others VALUES('180','6','Hồ Nghinh','ho-nghinh-vjhkihq6pl','0','0','125','1','0','1499010480','1499010480','27');
INSERT INTO olala_others VALUES('181','6','Phước Trường 2','phuoc-truong-2','0','0','126','1','0','1499061085','1499061085','27');
INSERT INTO olala_others VALUES('182','6','Tâm Chơn 6','tam-chon-6','0','0','127','1','0','1517641666','1517641666','25');
INSERT INTO olala_others VALUES('183','6','Thăng Long','thang-long','0','0','128','1','0','1517642417','1517642417','25');
INSERT INTO olala_others VALUES('184','6','Nghiêm Xuân Yêm','nghiem-xuan-yem','0','0','129','1','0','1517814454','1517814454','25');
INSERT INTO olala_others VALUES('185','6','Nguyễn Tất Thành','nguyen-tat-thanh-q4h4v','0','0','130','1','0','1517814727','1517814727','25');
INSERT INTO olala_others VALUES('186','6','Hoang-Sa-Tveqa78Hjh','hoang-sa-tveqa78hjh','0','0','131','1','0','1517814752','1517814752','25');
INSERT INTO olala_others VALUES('187','6','Ngô Quyền','ngo-quyen','0','0','132','1','0','1517814833','1517814833','25');

-- --------------------------------------------------------

CREATE TABLE `olala_others_menu` (
  `others_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `plus` varchar(255) NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`others_menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO olala_others_menu VALUES('1','88','Hướng','huong','','0','1','1','0','1470944854','1517024264','1');
INSERT INTO olala_others_menu VALUES('2','88','Loại đường','loai-duong','','0','2','1','0','1493371968','1517024268','1');
INSERT INTO olala_others_menu VALUES('3','95','Đà Nẵng','da-nang','','0','1','1','0','1493371980','1494961453','1');
INSERT INTO olala_others_menu VALUES('4','95','Quảng Nam','quang-nam','','0','2','1','0','1493371987','1494961457','1');
INSERT INTO olala_others_menu VALUES('5','95','Quảng Ngãi','quang-ngai','','0','3','1','0','1493371994','1494961461','1');
INSERT INTO olala_others_menu VALUES('6','88','Tên đường','ten-duong','','0','4','1','0','1493924265','1495204126','1');
INSERT INTO olala_others_menu VALUES('7','88','Mức giá','muc-gia','','0','3','1','0','1493924502','1517024272','1');

-- --------------------------------------------------------

CREATE TABLE `olala_page` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `content` longtext NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`page_id`)
) ENGINE=MyISAM AUTO_INCREMENT=115 DEFAULT CHARSET=utf8;

INSERT INTO olala_page VALUES('27','copyright','Copyright','','<p><strong>Trang thông tin bất động sản Nhà phố&nbsp;Đà Nẵng</strong></p>\r\n\r\n<p><u><label>Địa chỉ:</label></u>&nbsp;Tòa nhà PVcombank - Đường 30/4,&nbsp;TP. Đà Nẵng<br />\r\n<label><u>Điện thoại:</u></label>&nbsp;0935 40 04 83<br />\r\n<label><u>Email:</u></label>&nbsp;phanthucquynh@gmail.com</p>\r\n\r\n<p>© Copyright 2016 NhaPhoDaNang.com.vn, All rights reserved.</p>\r\n','1','1','1519747307','25');
INSERT INTO olala_page VALUES('110','contact','Thông tin liên hệ cuối trang chủ','','<p>TƯ VẤN: <strong>7:30 - 22:00</strong><br />\r\n(Mrs. Loan): <strong>0935 40 04 83</strong><br />\r\n(Mr. Huy): <strong>0974 779 085</strong></p>\r\n','1','1','1519840543','25');
INSERT INTO olala_page VALUES('106','contact_page','Thông tin liên hệ Nhà phố Đà Nẵng','','<h3>Trang thông tin bất động sản <span style=\"color:#39b54a;\">Nhà phố Đà Nẵng</span></h3>\r\n\r\n<p><span style=\"color:#a57529;\"><strong>Dự án bất động sản nhà phố tại thành phố Đà Nẵng</strong></span><br />\r\n<u>Địa chỉ:</u> Tòa nhà PVcombank - Đường 30/4, TP. Đà Nẵng<br />\r\n<u>Điện thoại:</u> 0935 40 04 83 &nbsp;-&nbsp; <u>Email:</u> phanthucquynh@gmail.com &nbsp;-&nbsp; <u>Website:</u> www.NhaPhoDaNang.com.vn</p>\r\n','1','1','1519747446','25');
INSERT INTO olala_page VALUES('107','adv','Đăng quảng cáo','','<p><img alt=\"\" src=\"/uploads/images/site/img_201703090909551209.gif\" style=\"max-width: 100%;\" /></p>\r\n','1','1','1518058590','25');
INSERT INTO olala_page VALUES('112','project','Dự án bất động sản nổi bật','','<h1 class=\"title\">Dự án bất động sản nổi bật</h1>\r\n\r\n<p class=\"f-space10\">Nhà phố Đà Nẵng mang đến cho bạn đầy đủ thông tin các dự án bất động sản nổi bật nhất hiện nay.</p>\r\n','1','1','1518191811','25');
INSERT INTO olala_page VALUES('113','realty','Nhà đất bán nổi bật','','<h1 class=\"title\">Bất động sản nổi bật</h1>\r\n\r\n<p>Với Nhà phố Đà Nẵng, bạn sẽ trải nghiệm sự phong phú về sản phẩm và thông minh trong giao diện hiển thị.</p>\r\n','1','1','1518191812','25');
INSERT INTO olala_page VALUES('114','post','Tin tức thị trường','','<h1 class=\"title\">Tin tức thị trường</h1>\r\n\r\n<p>Nhận định thị trường, thông tin hoạt động bất động sản và góc chia sẻ kiến thức.</p>\r\n','1','1','1518194375','25');

-- --------------------------------------------------------

CREATE TABLE `olala_prjname` (
  `prjname_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`prjname_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_menu_id` int(11) NOT NULL,
  `project` int(11) NOT NULL DEFAULT '0',
  `owner` int(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `upload_id` bigint(20) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `acreage` float NOT NULL DEFAULT '0',
  `price` double NOT NULL DEFAULT '0',
  `price_unit` varchar(255) NOT NULL,
  `direction` varchar(255) NOT NULL,
  `direction_2` varchar(255) NOT NULL,
  `road` varchar(255) NOT NULL,
  `road_2` varchar(255) NOT NULL,
  `bedroom` int(11) NOT NULL DEFAULT '0',
  `bathroom` int(11) NOT NULL DEFAULT '0',
  `city` varchar(255) NOT NULL,
  `city_2` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `district_2` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `comment` text CHARACTER SET utf8mb4 NOT NULL,
  `content` text CHARACTER SET utf8mb4 NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `youtube_img` varchar(255) NOT NULL DEFAULT 'no',
  `tags` varchar(255) NOT NULL,
  `tags_2` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `pin` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=676 DEFAULT CHARSET=utf8;

INSERT INTO olala_product VALUES('664','255','0','0','Đại Dương, đường Hoàng Sa, phường Thọ Quang, Sơn Trà, Đà Nẵng','ban-3-lo-dat-mat-bien-gan-cong-vien-dai-duong-duong-hoang-sa-phuong-tho-quang-son-tra-da-nang','dai-duong-duong-hoang-sa-phuong-tho-quang-son-tra-da-nang-1517814753.png','','2183','1','372','0','','[]','[]','[]','[]','0','0','da-nang','Đà Nẵng','son-tra','Sơn Trà','hoang-sa-tveqa78hjh','Hoang-Sa-Tveqa78Hjh','Chính chủ bán 3 lô đất B2.8 ô 33, 34, 35, tổng diện tích 372,4m2 đường Hoàng Sa, phường Thọ Quang, Sơn Trà, Đà Nẵng.','<p>Chính chủ bán 3 lô đất B2.8 ô 33, 34, 35, tổng diện tích 372,4m2 đường Hoàng Sa,&nbsp;phường Thọ Quang, Sơn Trà, Đà Nẵng, giá 150tr/m2 ô ba mặt 35 nhân hệ số 1,2.<br />\r\nĐất ở Đô thị.<br />\r\nHướng Đông Nam.<br />\r\n<strong>Liên hệ chính chủ 0905779085</strong></p>\r\n','','no','[]','[]','1','0','0','22','','','','1516985760','1519876925','25');
INSERT INTO olala_product VALUES('665','255','0','0','Bán lô đất đường nguyễn tất thành, cách biển 800m - 135m2 (7.5 x18.2)','ban-lo-dat-duong-nguyen-tat-thanh-cach-bien-800m-135m2-7-5-x18-2','ban-lo-dat-duong-nguyen-tat-thanh-cach-bien-800m-135m2-7-5-x18-2-1517814728.jpg','','2206','1','135.8','9300000','/m<sup>2</sup>','[\"huong-nam\",\"huong-dong-bac\"]','[\"Nam\",\"Đông Bắc\"]','[\"15m\",\"21m\"]','[\"15m\",\"21m\"]','0','0','da-nang','Đà Nẵng','lien-chieu','Liên Chiểu','nguyen-tat-thanh-q4h4v','Nguyễn Tất Thành','Cuối năm, cần bán lô đất ở quận Liên Chiểu, gần cảng biển Liên Chiểu, nằm ngay khu phố đặc khu kinh tế Tây Bắc của Đà Nẵng.','<p>Cuối năm, cần bán lô đất ở quận Liên Chiểu, gần cảng biển Liên Chiểu, nằm ngay khu phố đặc khu kinh tế&nbsp;Tây Bắc&nbsp;của Đà Nẵng.<br />\r\nVị trí cách biển 800m, cách đường Nguyễn Tất Thành khoảng 50m, bao quanh hồ thoáng mát rất tiện để đầu tư hoặc nghỉ dưỡng.<br />\r\nDiện tích: 7.5 x 18.2 = 135m2.<br />\r\nGiá: 9.3 triệu/m2.<br />\r\nMặt tiền đường 17.5m - lề 4m.<br />\r\nCó hỗ trợ vay vốn ngân hàng 50% giá trị sản phẩm, ưu đãi không lãi suất trong năm đầu tiên.<br />\r\nLiên hệ SĐT: 0941.50.42.05.<br />\r\nVui lòng liên hệ trước 30p khi đi xem đất.<br />\r\nCảm ơn!</p>\r\n','','no','[\"Đất bán\",\"Đất thổ cư\"]','[\"dat-ban\",\"dat-tho-cu\"]','1','0','0','31','','','','1517218560','1517814728','25');
INSERT INTO olala_product VALUES('666','255','0','0','Cần bán cặp đất đường lê quang đạo rất đẹp, gần biển mỹ khê. đường 7,5m, giá 17,7 tỷ','can-ban-cap-dat-duong-le-quang-dao-rat-dep-gan-bien-my-khe-duong-7-5m-gia-17-7-ty','can-ban-cap-dat-duong-le-quang-dao-rat-dep-gan-bien-my-khe-duong-7-1517814653.jpg','','2207','1','164','17700000000','','[\"huong-tay\"]','[\"Tây\"]','[\"7m5\"]','[\"7m5\"]','0','0','da-nang','Đà Nẵng','ngu-hanh-son','Ngũ Hành Sơn','le-quang-dao','Lê Quang Đạo','Tôi bán cặp đất đường Lê Quang Đạo vị trí đẹp quận Ngũ Hành Sơn, Đà Nẵng - Gần biển Mỹ Khê, 1 trong 10 bãi biển đẹp nhất thế giới.','<p>Tôi bán cặp đất đường Lê Quang Đạo vị trí đẹp quận&nbsp;Ngũ Hành Sơn, Đà Nẵng - Gần biển Mỹ Khê, 1 trong 10 bãi biển đẹp nhất thế giới.<br />\r\n<br />\r\nKhu dân cư đông đúc dân trí cao, khu 387 quy hoạch phố Tây.<br />\r\n<br />\r\nĐông khách du lịch, kinh doanh nhà nghỉ khách sạn sầm uất.<br />\r\n<br />\r\nDiện tích 9*18,3m = 164,8m2, hướng Tây, đường 7.5m.<br />\r\n<br />\r\nGiá 17,7 tỷ.</p>\r\n','','no','[\"Đất bán\",\"Đất thổ cư\"]','[\"dat-ban\",\"dat-tho-cu\"]','1','0','1','93','','','','1517220060','1518195168','25');
INSERT INTO olala_product VALUES('667','255','0','0','Cần bán đất tại mặt tiền đường an thượng 30, dt 162m2, hướng nam, hợp xây khách sạn, homestay','can-ban-dat-tai-mat-tien-duong-an-thuong-30-dt-162m2-huong-nam-hop-xay-khach-san-homestay','can-ban-dat-tai-mat-tien-duong-an-thuong-30-dt-162m2-huong-nam-hop-xay-k-1517814494.jpg','','2220','1','162','19500000000','','[\"huong-nam\"]','[\"Nam\"]','[\"5m5\"]','[\"5m5\"]','0','0','da-nang','Đà Nẵng','ngu-hanh-son','Ngũ Hành Sơn','an-thuong-30','An Thượng 30','Tôi bán đất tại mặt tiền đường An Thượng 30, khu biển 387 du lịch đông đúc. Gái cả hợp lý.','<p>- DT: 162m2 = 9 x 18m.<br />\r\n- Đường quy hoạch 5m5, vỉa hè 3m.<br />\r\n- Hướng: Nam.<br />\r\n- Thích hợp xây KD khách sạn, homestay.<br />\r\n- Giá: 19,5 tỷ&nbsp;<br />\r\n&nbsp;</p>\r\n','','no','[\"Đất bán\",\"Đất thổ cư\"]','[\"dat-ban\",\"dat-tho-cu\"]','1','0','1','67','','','','1517629020','1517848920','25');
INSERT INTO olala_product VALUES('668','254','0','0','Khu đô thị FPT City Đà Nẵng - Phường Hòa Hải, Quận Ngũ Hành Sơn, Đà Nẵng','khu-do-thi-fpt-city-da-nang-phuong-hoa-hai-quan-ngu-hanh-son-da-nang','khu-do-thi-fpt-city-da-nang-phuong-hoa-hai-quan-ngu-hanh-son-da-nang-1517814467.jpg','','2221','1','500','10000000','/m<sup>2</sup>','[]','[]','[\"10m5\"]','[\"10m5\"]','0','0','da-nang','Đà Nẵng','ngu-hanh-son','Ngũ Hành Sơn','','','Mở bán đất nền biệt thự ven sông Đà Nẵng, bên cạnh đại học FPT, 6,5 triệu/m2, chiết khấu đến 8%','<p><strong>ĐẤT BIỂN ĐÀ NẴNG - KHU ĐÔ THỊ FPT.</strong></p>\r\n\r\n<p><strong>1, Vị trí:</strong></p>\r\n\r\n<p>- Đất Hòa Hải Đà Nẵng - Đất nền&nbsp;<strong>biệt thự</strong>&nbsp;ven sông vị trí trung tâm khu kinh tế trọng điểm phía Nam Đà Nẵng.</p>\r\n\r\n<p>- Cách cầu Rồng Đà Nẵng chỉ 10km, cách bệnh viện 600 giường 5km.</p>\r\n\r\n<p>- Nằm trên tuyến đường ven biển kết nối phố cổ Hội An và Đà Nẵng. Cách phố cổ Hội An 15km.</p>\r\n\r\n<p><strong>2, Lý do chọn&nbsp;<strong>đất nền</strong>&nbsp;biệt thự ven sông để đầu tư ở thời điểm hiện tại:</strong></p>\r\n\r\n<p>- Đất FPT Đà Nẵng- Vị trí kim cương, kết nối các khu đô thị lớn xung quanh.</p>\r\n\r\n<p>- Hạ tầng hoàn thiện đã có sổ đỏ.</p>\r\n\r\n<p>- Giá đầu tư đất Hòa Quý Đà Nẵng chỉ từ: 6,5&nbsp;tr/m2.</p>\r\n\r\n<p>- Hạ tầng xung quanh hoàn thiện tốt.</p>\r\n\r\n<p><strong>3, Chính sách bán hàng đất Ngũ Hành Sơn.</strong></p>\r\n\r\n<p>Đất Đà Nẵng giá rẻ, chiết khấu cao lên đến 8% cho khách hàng giao dịch trước ngày 21/1.</p>\r\n\r\n<p>Hỗ trợ làm sổ hồng nhanh trong vòng 24h.</p>\r\n\r\n<p><strong>Liên hệ: Mr Thái khi mua đất làng đại học Đà Nẵng.</strong></p>\r\n','','no','[]','[]','1','0','0','27','','','','1517630400','1518197758','25');
INSERT INTO olala_product VALUES('669','254','0','0','Đất Nam Việt Á - Đất Nghiêm Xuân Yêm giá hữu nghị cuối năm','dat-nam-viet-a-dat-nghiem-xuan-yem-gia-huu-nghi-cuoi-nam','dat-nam-viet-a-dat-nghiem-xuan-yem-gia-huu-nghi-cuoi-nam-1517814455.jpg','','2222','1','100','3000000000','','[]','[]','[]','[]','0','0','da-nang','Đà Nẵng','hai-chau','Hải Châu','nghiem-xuan-yem','Nghiêm Xuân Yêm','Đất Nam Việt Á giá hữu nghị Đường Nghiêm Xuân Yêm  Diện tích 100m2. 5x20m Giá 3 tỷ  Nhanh tay liên hệ để biết thêm thông tin. Cuối năm hốt lẹ qua năm có thêm thu nhập lớn.','<p>Đất Nam Việt Á giá hữu nghị</p>\r\n\r\n<p>Đường&nbsp;Nghiêm Xuân Yêm&nbsp;</p>\r\n\r\n<p>Diện tích 100m2. 5x20m</p>\r\n\r\n<p>Giá 3 tỷ&nbsp;</p>\r\n\r\n<p>Nhanh tay liên hệ để biết thêm thông tin.</p>\r\n\r\n<p>Cuối năm hốt lẹ qua năm có thêm thu nhập lớn</p>\r\n\r\n<p>Rất hân hạnh được đón tiếp quý khách.</p>\r\n','','no','[\"Đất bán\",\"Đất nền dự án\"]','[\"dat-ban\",\"dat-nen-du-an\"]','1','0','0','17','','','','1517630640','1517850586','25');

-- --------------------------------------------------------

CREATE TABLE `olala_product_menu` (
  `product_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `plus` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=267 DEFAULT CHARSET=utf8;

INSERT INTO olala_product_menu VALUES('254','99','Đất nền dự án','dat-nen-du-an','','','','','0','1','1','0','no','1516136086','1518197752','25');
INSERT INTO olala_product_menu VALUES('255','99','Đất thổ cư','dat-tho-cu','','','','','0','2','1','0','no','1516136176','1517849853','25');
INSERT INTO olala_product_menu VALUES('256','99','Đất nông nghiệp','dat-nong-nghiep','','','','','0','3','1','0','no','1516136188','1516136188','1');
INSERT INTO olala_product_menu VALUES('257','99','Đất công nghiệp','dat-cong-nghiep','','','','','0','4','1','0','no','1516136196','1516136196','1');
INSERT INTO olala_product_menu VALUES('258','99','Đất loại khác','dat-loai-khac','','','','','0','5','1','0','no','1516136204','1516136204','1');
INSERT INTO olala_product_menu VALUES('262','101','Căn hộ cho thuê','can-ho-cho-thue','','','','','0','1','1','0','no','1516136331','1516136331','1');
INSERT INTO olala_product_menu VALUES('263','101','Cho thuê nhà','cho-thue-nha','','','','','0','2','1','0','no','1516136339','1516136339','1');
INSERT INTO olala_product_menu VALUES('264','101','Đất cho thuê','dat-cho-thue','','','','','0','3','1','0','no','1516136348','1516136348','1');
INSERT INTO olala_product_menu VALUES('265','101','Mặt bằng cho thuê','mat-bang-cho-thue','','','','','0','4','1','0','no','1516136359','1516136359','1');
INSERT INTO olala_product_menu VALUES('266','101','Kho xưởng cho thuê','kho-xuong-cho-thue','','','','','0','5','1','0','no','1516136367','1516136367','1');

-- --------------------------------------------------------

CREATE TABLE `olala_project` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `content` longtext NOT NULL,
  `upload_id` bigint(20) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`project_id`)
) ENGINE=MyISAM AUTO_INCREMENT=206 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_project_menu` (
  `project_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `comment` text NOT NULL,
  `project_type` int(11) NOT NULL DEFAULT '0',
  `price_max` bigint(20) NOT NULL DEFAULT '0',
  `price_min` bigint(20) NOT NULL DEFAULT '0',
  `legal` int(1) NOT NULL DEFAULT '0',
  `location` int(11) NOT NULL DEFAULT '0',
  `geo_radius` int(11) NOT NULL DEFAULT '0',
  `project_use` varchar(255) NOT NULL,
  `project_hot` varchar(255) NOT NULL,
  `project_involve` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`project_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=217 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_road` (
  `road_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`road_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_share` (
  `share_id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `session` varchar(255) NOT NULL,
  `count` bigint(20) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`share_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

INSERT INTO olala_share VALUES('15','915','Tô Thái Huy','0974779085','killlllme@gmail.com','1e161bb14eb5e2af1394b954c9a6f1bc','11','1513784557','1513779767');
INSERT INTO olala_share VALUES('18','895','Thái Huy','0905779085','huyto.qng@gmail.com','bd5add404333f2b7cce53a75ca1fb1ef','4','1514617549','1514621167');
INSERT INTO olala_share VALUES('19','895','Huy Tô','0905779085','killlllme@gmail.com','9e3f95c855f9bde7c8a0a793f2765b57','4','1514618514','1514618523');
INSERT INTO olala_share VALUES('20','895','Thai Huy To','0905779086','huyto.qng@gmail.com','4b1d2c56b0c1cf756d52b6fd26a565ae','2','1514792970','1514794776');

-- --------------------------------------------------------

CREATE TABLE `olala_street` (
  `street_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`street_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_tags` (
  `tags_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `count` bigint(20) NOT NULL DEFAULT '0',
  `click` bigint(20) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tags_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO olala_tags VALUES('7','Kiến trúc','kien-truc','4','20','1513669122','1515532879','1');
INSERT INTO olala_tags VALUES('8','Nhà ở','nha-o','9','5','1513669122','1515657455','1');
INSERT INTO olala_tags VALUES('10','Sài Gòn','sai-gon','2','0','1513669141','1513669141','1');
INSERT INTO olala_tags VALUES('11','Đà Nẵng','da-nang','2','2','1513669163','1515516653','1');
INSERT INTO olala_tags VALUES('12','Ý tưởng','y-tuong','1','0','1513670256','1513670256','1');
INSERT INTO olala_tags VALUES('13','Toà nhà','toa-nha','1','0','1513670256','1513670256','1');
INSERT INTO olala_tags VALUES('15','Nội thất','noi-that','4','0','1513670538','1515657455','1');
INSERT INTO olala_tags VALUES('16','Hà Nội','ha-noi','1','0','1513670539','1515657455','1');
INSERT INTO olala_tags VALUES('17','Tin tức','tin-tuc','7','1','1513670686','1517626927','1');
INSERT INTO olala_tags VALUES('18','Thông tin thị trường','thong-tin-thi-truong','2','0','1513670687','1513670687','1');
INSERT INTO olala_tags VALUES('19','Nhật Bản','nhat-ban','1','0','1513670687','1513670687','1');
INSERT INTO olala_tags VALUES('20','Giới thiệu','gioi-thieu','1','1','1516350305','1518060089','1');
INSERT INTO olala_tags VALUES('21','Về chúng tôi','ve-chung-toi','1','0','1516350305','1518060089','1');
INSERT INTO olala_tags VALUES('22','Bản tin bất động sản','ban-tin-bat-dong-san','7','0','1516677398','1517626927','25');
INSERT INTO olala_tags VALUES('23','Dự án','du-an','6','0','1516900007','1517891014','25');
INSERT INTO olala_tags VALUES('24','Căn hộ chung cư','can-ho-chung-cu','6','0','1516900007','1517891014','25');
INSERT INTO olala_tags VALUES('25','Đất bán','dat-ban','0','0','1517218806','1517218806','1');
INSERT INTO olala_tags VALUES('26','Đất thổ cư','dat-tho-cu','0','0','1517218806','1517218806','1');
INSERT INTO olala_tags VALUES('27','Góc tư vấn','goc-tu-van','5','0','1517627930','1517628435','25');
INSERT INTO olala_tags VALUES('28','Tư vấn kiến trúc','tu-van-kien-truc','4','0','1517627931','1517628435','25');
INSERT INTO olala_tags VALUES('29','Mẫu nhà đẹp','mau-nha-dep','1','0','1517628148','1517628165','25');
INSERT INTO olala_tags VALUES('30','Đất nền dự án','dat-nen-du-an','0','0','1517630594','1517630594','25');
INSERT INTO olala_tags VALUES('31','Nhà bán','nha-ban','0','0','1517631245','1517631245','25');
INSERT INTO olala_tags VALUES('32','Nhà phố - Nhà mặt tiền','nha-pho-nha-mat-tien','0','0','1517631245','1517631245','25');
INSERT INTO olala_tags VALUES('33','Biệt thự - Villa','biet-thu-villa','0','0','1517631784','1517631784','25');

-- --------------------------------------------------------

CREATE TABLE `olala_tour` (
  `tour_id` int(11) NOT NULL AUTO_INCREMENT,
  `tour_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `tour_keys` varchar(255) NOT NULL,
  `price` bigint(15) NOT NULL DEFAULT '0',
  `date_schedule` varchar(255) NOT NULL,
  `date_departure` int(11) NOT NULL DEFAULT '0',
  `means` varchar(255) NOT NULL,
  `tour_type` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `sale` int(3) NOT NULL DEFAULT '0',
  `schedule` text NOT NULL,
  `price_list_service` text NOT NULL,
  `upload_id` bigint(20) NOT NULL,
  `maps` text NOT NULL,
  `video` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `pin` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tour_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_tour_menu` (
  `tour_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tour_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=157 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala_uploads_tmp` (
  `upload_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` int(1) NOT NULL DEFAULT '0',
  `list_img` text NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`upload_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2415 DEFAULT CHARSET=utf8;

INSERT INTO olala_uploads_tmp VALUES('1606','0','','1494148567');
INSERT INTO olala_uploads_tmp VALUES('1607','0','','1494148608');
INSERT INTO olala_uploads_tmp VALUES('1608','0','','1494148724');
INSERT INTO olala_uploads_tmp VALUES('1628','0','','1494522106');
INSERT INTO olala_uploads_tmp VALUES('1619','1','','1494180762');
INSERT INTO olala_uploads_tmp VALUES('1622','0','','1494183294');
INSERT INTO olala_uploads_tmp VALUES('1616','0','','1494180652');
INSERT INTO olala_uploads_tmp VALUES('1627','0','','1494217625');
INSERT INTO olala_uploads_tmp VALUES('1629','0','','1494953260');
INSERT INTO olala_uploads_tmp VALUES('1630','0','','1494955327');
INSERT INTO olala_uploads_tmp VALUES('1631','0','','1494956909');
INSERT INTO olala_uploads_tmp VALUES('1632','0','','1494956952');
INSERT INTO olala_uploads_tmp VALUES('1633','0','','1494957143');
INSERT INTO olala_uploads_tmp VALUES('1634','0','','1494957148');
INSERT INTO olala_uploads_tmp VALUES('1635','0','','1494957283');
INSERT INTO olala_uploads_tmp VALUES('1636','0','','1494957291');
INSERT INTO olala_uploads_tmp VALUES('1637','0','','1494957477');
INSERT INTO olala_uploads_tmp VALUES('1638','0','','1494957571');
INSERT INTO olala_uploads_tmp VALUES('1639','0','','1494957620');
INSERT INTO olala_uploads_tmp VALUES('1640','0','','1494957740');
INSERT INTO olala_uploads_tmp VALUES('1641','0','','1494957784');
INSERT INTO olala_uploads_tmp VALUES('1642','0','','1494957897');
INSERT INTO olala_uploads_tmp VALUES('1643','0','','1494957911');
INSERT INTO olala_uploads_tmp VALUES('1644','0','','1494957928');
INSERT INTO olala_uploads_tmp VALUES('1645','0','','1494957938');
INSERT INTO olala_uploads_tmp VALUES('1646','0','','1494957963');
INSERT INTO olala_uploads_tmp VALUES('1647','0','','1494958319');
INSERT INTO olala_uploads_tmp VALUES('1648','0','','1494958338');
INSERT INTO olala_uploads_tmp VALUES('1649','0','','1494958380');
INSERT INTO olala_uploads_tmp VALUES('1650','0','','1494964431');
INSERT INTO olala_uploads_tmp VALUES('1651','0','','1494964594');
INSERT INTO olala_uploads_tmp VALUES('1652','0','','1494964628');
INSERT INTO olala_uploads_tmp VALUES('1653','0','','1494964706');
INSERT INTO olala_uploads_tmp VALUES('1654','0','','1494964720');
INSERT INTO olala_uploads_tmp VALUES('1655','0','','1494964728');
INSERT INTO olala_uploads_tmp VALUES('1656','0','','1494965079');
INSERT INTO olala_uploads_tmp VALUES('1657','0','','1494965086');
INSERT INTO olala_uploads_tmp VALUES('1658','0','','1494965100');
INSERT INTO olala_uploads_tmp VALUES('1659','0','','1494965108');
INSERT INTO olala_uploads_tmp VALUES('1660','0','','1494965195');
INSERT INTO olala_uploads_tmp VALUES('1661','0','','1494965197');
INSERT INTO olala_uploads_tmp VALUES('1662','0','','1494965321');
INSERT INTO olala_uploads_tmp VALUES('1663','0','','1494965622');
INSERT INTO olala_uploads_tmp VALUES('1664','0','','1494965634');
INSERT INTO olala_uploads_tmp VALUES('1665','0','','1494965702');
INSERT INTO olala_uploads_tmp VALUES('1666','0','','1494965808');
INSERT INTO olala_uploads_tmp VALUES('1667','0','','1494965898');
INSERT INTO olala_uploads_tmp VALUES('1668','0','','1494965988');
INSERT INTO olala_uploads_tmp VALUES('1669','0','','1495042897');
INSERT INTO olala_uploads_tmp VALUES('1670','0','','1495042931');
INSERT INTO olala_uploads_tmp VALUES('1671','0','','1495042992');
INSERT INTO olala_uploads_tmp VALUES('1672','0','','1495043043');
INSERT INTO olala_uploads_tmp VALUES('1673','0','','1495043080');
INSERT INTO olala_uploads_tmp VALUES('1674','0','','1495043121');
INSERT INTO olala_uploads_tmp VALUES('1675','0','','1495043181');
INSERT INTO olala_uploads_tmp VALUES('1676','0','','1495043969');
INSERT INTO olala_uploads_tmp VALUES('1677','0','','1495071652');
INSERT INTO olala_uploads_tmp VALUES('1678','0','','1495073071');
INSERT INTO olala_uploads_tmp VALUES('1679','0','','1495077827');
INSERT INTO olala_uploads_tmp VALUES('1680','0','','1495077935');
INSERT INTO olala_uploads_tmp VALUES('1681','0','','1495077944');
INSERT INTO olala_uploads_tmp VALUES('1682','0','','1495078243');
INSERT INTO olala_uploads_tmp VALUES('1683','0','','1495078255');
INSERT INTO olala_uploads_tmp VALUES('1684','0','','1495080039');
INSERT INTO olala_uploads_tmp VALUES('1685','0','','1495080041');
INSERT INTO olala_uploads_tmp VALUES('1686','0','','1495080128');
INSERT INTO olala_uploads_tmp VALUES('1687','0','','1495080264');
INSERT INTO olala_uploads_tmp VALUES('1688','0','','1495081141');
INSERT INTO olala_uploads_tmp VALUES('1689','0','','1495081156');
INSERT INTO olala_uploads_tmp VALUES('1690','0','','1495081196');
INSERT INTO olala_uploads_tmp VALUES('1691','0','','1495081212');
INSERT INTO olala_uploads_tmp VALUES('1692','0','','1495081253');
INSERT INTO olala_uploads_tmp VALUES('1693','0','','1495081273');
INSERT INTO olala_uploads_tmp VALUES('1694','0','','1495081338');
INSERT INTO olala_uploads_tmp VALUES('1695','0','','1495081368');
INSERT INTO olala_uploads_tmp VALUES('1696','0','','1495081388');
INSERT INTO olala_uploads_tmp VALUES('1697','0','','1495081414');
INSERT INTO olala_uploads_tmp VALUES('1698','0','','1495081426');
INSERT INTO olala_uploads_tmp VALUES('1699','0','','1495082018');
INSERT INTO olala_uploads_tmp VALUES('1700','0','','1495082099');
INSERT INTO olala_uploads_tmp VALUES('1701','0','','1495082263');
INSERT INTO olala_uploads_tmp VALUES('1702','0','','1495090079');
INSERT INTO olala_uploads_tmp VALUES('1703','0','','1495090087');
INSERT INTO olala_uploads_tmp VALUES('1704','0','','1495090095');
INSERT INTO olala_uploads_tmp VALUES('1705','0','','1495090509');
INSERT INTO olala_uploads_tmp VALUES('1706','0','','1495091563');
INSERT INTO olala_uploads_tmp VALUES('1707','0','','1495091622');
INSERT INTO olala_uploads_tmp VALUES('1708','0','','1495091681');
INSERT INTO olala_uploads_tmp VALUES('1709','0','','1495091842');
INSERT INTO olala_uploads_tmp VALUES('1710','0','','1495092033');
INSERT INTO olala_uploads_tmp VALUES('1711','0','','1495092064');
INSERT INTO olala_uploads_tmp VALUES('1712','0','','1495092066');
INSERT INTO olala_uploads_tmp VALUES('1713','0','','1495092142');
INSERT INTO olala_uploads_tmp VALUES('1714','0','','1495092189');
INSERT INTO olala_uploads_tmp VALUES('1715','0','','1495092205');
INSERT INTO olala_uploads_tmp VALUES('1716','0','','1495092208');
INSERT INTO olala_uploads_tmp VALUES('1717','0','','1495092245');
INSERT INTO olala_uploads_tmp VALUES('1718','0','','1495092309');
INSERT INTO olala_uploads_tmp VALUES('1719','0','','1495092339');
INSERT INTO olala_uploads_tmp VALUES('1720','0','','1495092354');
INSERT INTO olala_uploads_tmp VALUES('1721','0','','1495092390');
INSERT INTO olala_uploads_tmp VALUES('1722','0','','1495092406');
INSERT INTO olala_uploads_tmp VALUES('1723','0','','1495092453');
INSERT INTO olala_uploads_tmp VALUES('1724','0','','1495092462');
INSERT INTO olala_uploads_tmp VALUES('1725','0','','1495092683');
INSERT INTO olala_uploads_tmp VALUES('1726','0','','1495092730');
INSERT INTO olala_uploads_tmp VALUES('1727','0','','1495092796');
INSERT INTO olala_uploads_tmp VALUES('1728','0','','1495092880');
INSERT INTO olala_uploads_tmp VALUES('1729','0','','1495093352');
INSERT INTO olala_uploads_tmp VALUES('1730','0','','1495093880');
INSERT INTO olala_uploads_tmp VALUES('1731','0','','1495094500');
INSERT INTO olala_uploads_tmp VALUES('1732','0','','1495094582');
INSERT INTO olala_uploads_tmp VALUES('1733','0','','1495094601');
INSERT INTO olala_uploads_tmp VALUES('1734','0','','1495094603');
INSERT INTO olala_uploads_tmp VALUES('1735','0','','1495094640');
INSERT INTO olala_uploads_tmp VALUES('1736','0','','1495094707');
INSERT INTO olala_uploads_tmp VALUES('1737','0','','1495094808');
INSERT INTO olala_uploads_tmp VALUES('1738','0','','1495094867');
INSERT INTO olala_uploads_tmp VALUES('1739','0','','1495094913');
INSERT INTO olala_uploads_tmp VALUES('1740','0','','1495095142');
INSERT INTO olala_uploads_tmp VALUES('1741','0','','1495095336');
INSERT INTO olala_uploads_tmp VALUES('1742','0','','1495096192');
INSERT INTO olala_uploads_tmp VALUES('1743','0','','1495097070');
INSERT INTO olala_uploads_tmp VALUES('1744','0','','1495097239');
INSERT INTO olala_uploads_tmp VALUES('1745','0','','1495097275');
INSERT INTO olala_uploads_tmp VALUES('1746','0','','1495097289');
INSERT INTO olala_uploads_tmp VALUES('1747','0','','1495098068');
INSERT INTO olala_uploads_tmp VALUES('1748','0','','1495098188');
INSERT INTO olala_uploads_tmp VALUES('1749','0','','1495098424');
INSERT INTO olala_uploads_tmp VALUES('1750','0','','1495098682');
INSERT INTO olala_uploads_tmp VALUES('1751','0','','1495102772');
INSERT INTO olala_uploads_tmp VALUES('1752','0','','1495103096');
INSERT INTO olala_uploads_tmp VALUES('1753','0','','1495103191');
INSERT INTO olala_uploads_tmp VALUES('1754','0','','1495103200');
INSERT INTO olala_uploads_tmp VALUES('1755','0','','1495103240');
INSERT INTO olala_uploads_tmp VALUES('1756','0','','1495126834');
INSERT INTO olala_uploads_tmp VALUES('1757','0','','1495126842');
INSERT INTO olala_uploads_tmp VALUES('1758','0','','1495179895');
INSERT INTO olala_uploads_tmp VALUES('1759','0','','1495186231');
INSERT INTO olala_uploads_tmp VALUES('1760','0','','1495204220');
INSERT INTO olala_uploads_tmp VALUES('1761','0','','1495214441');
INSERT INTO olala_uploads_tmp VALUES('1762','0','','1495214502');
INSERT INTO olala_uploads_tmp VALUES('1763','0','','1495214510');
INSERT INTO olala_uploads_tmp VALUES('1764','0','','1495214557');
INSERT INTO olala_uploads_tmp VALUES('1765','0','','1495214574');
INSERT INTO olala_uploads_tmp VALUES('1766','0','','1495214615');
INSERT INTO olala_uploads_tmp VALUES('1767','0','','1495214627');
INSERT INTO olala_uploads_tmp VALUES('1777','0','','1495222079');
INSERT INTO olala_uploads_tmp VALUES('1769','0','','1495218917');
INSERT INTO olala_uploads_tmp VALUES('1770','0','','1495218918');
INSERT INTO olala_uploads_tmp VALUES('1771','0','','1495218930');
INSERT INTO olala_uploads_tmp VALUES('1772','0','','1495219014');
INSERT INTO olala_uploads_tmp VALUES('1780','0','','1495222936');
INSERT INTO olala_uploads_tmp VALUES('1781','0','','1495225687');
INSERT INTO olala_uploads_tmp VALUES('1782','0','','1495225695');
INSERT INTO olala_uploads_tmp VALUES('1783','0','','1495225709');
INSERT INTO olala_uploads_tmp VALUES('1784','0','','1495225783');
INSERT INTO olala_uploads_tmp VALUES('1785','0','','1495225788');
INSERT INTO olala_uploads_tmp VALUES('1786','0','','1495225795');
INSERT INTO olala_uploads_tmp VALUES('1787','0','','1495225921');
INSERT INTO olala_uploads_tmp VALUES('1788','0','','1495225980');
INSERT INTO olala_uploads_tmp VALUES('1815','0','','1498926316');
INSERT INTO olala_uploads_tmp VALUES('1790','0','','1495226209');
INSERT INTO olala_uploads_tmp VALUES('1791','0','','1495226270');
INSERT INTO olala_uploads_tmp VALUES('1792','0','','1495226279');
INSERT INTO olala_uploads_tmp VALUES('1793','1','','1495295825');
INSERT INTO olala_uploads_tmp VALUES('2174','0','','1516354287');
INSERT INTO olala_uploads_tmp VALUES('2173','1','','1516350265');
INSERT INTO olala_uploads_tmp VALUES('1798','0','1495358188_1798_668c88252cb9e162b36d6713cb174c0d.jpg;1495358191_1798_a0d5434b0d5b08def83572649240c0d0.jpg;1495358193_1798_38a1905ecf631d468fddb233ee51b363.jpg;1495358196_1798_76764969447e3dbec7c38db97a6ad7ac.jpg;1495358198_1798_41556e4e12791ab26815bba9270fb00e.jpg;1495358201_1798_a9b7093b799d6d1af3f0f36140a99b00.jpg;1495358312_1798_4a1f7b9a6eaa938287d515789d6ce165.jpg;1495358597_1798_877678f580798b55d2ba436ed981e43f.jpg;1495358713_1798_98a69e0f2b0f255debde85fec5527457.jpg;1495359221_1798_30b32757c538d89ad60fc821bffaf712.jpg;','1495357896');
INSERT INTO olala_uploads_tmp VALUES('1799','0','','1495378192');
INSERT INTO olala_uploads_tmp VALUES('1822','0','','1498930039');
INSERT INTO olala_uploads_tmp VALUES('1872','0','','1512200462');
INSERT INTO olala_uploads_tmp VALUES('1868','0','','1512199995');
INSERT INTO olala_uploads_tmp VALUES('1867','0','','1512199992');
INSERT INTO olala_uploads_tmp VALUES('1870','0','','1512200004');
INSERT INTO olala_uploads_tmp VALUES('1869','0','','1512199997');
INSERT INTO olala_uploads_tmp VALUES('1871','0','','1512200459');
INSERT INTO olala_uploads_tmp VALUES('1873','0','','1512200480');
INSERT INTO olala_uploads_tmp VALUES('1862','0','','1512199394');
INSERT INTO olala_uploads_tmp VALUES('1861','0','','1512199378');
INSERT INTO olala_uploads_tmp VALUES('1860','0','','1512199283');
INSERT INTO olala_uploads_tmp VALUES('1859','0','','1512199258');
INSERT INTO olala_uploads_tmp VALUES('1858','0','','1512196492');
INSERT INTO olala_uploads_tmp VALUES('1857','0','','1512196489');
INSERT INTO olala_uploads_tmp VALUES('1856','0','','1512196235');
INSERT INTO olala_uploads_tmp VALUES('1801','0','','1495380859');
INSERT INTO olala_uploads_tmp VALUES('1805','0','','1495383166');
INSERT INTO olala_uploads_tmp VALUES('1803','0','','1495381092');
INSERT INTO olala_uploads_tmp VALUES('1804','0','','1495381176');
INSERT INTO olala_uploads_tmp VALUES('1806','0','','1495383327');
INSERT INTO olala_uploads_tmp VALUES('1807','0','','1495438809');
INSERT INTO olala_uploads_tmp VALUES('1808','0','','1495564220');
INSERT INTO olala_uploads_tmp VALUES('1809','0','','1496917138');
INSERT INTO olala_uploads_tmp VALUES('1810','0','','1496941270');
INSERT INTO olala_uploads_tmp VALUES('1812','0','','1498783037');
INSERT INTO olala_uploads_tmp VALUES('1813','0','','1498783213');
INSERT INTO olala_uploads_tmp VALUES('1814','0','','1498783548');
INSERT INTO olala_uploads_tmp VALUES('1874','0','','1512200572');
INSERT INTO olala_uploads_tmp VALUES('1875','0','','1512200591');
INSERT INTO olala_uploads_tmp VALUES('1876','0','','1512200603');
INSERT INTO olala_uploads_tmp VALUES('1877','0','','1512200625');
INSERT INTO olala_uploads_tmp VALUES('1878','0','','1512200962');
INSERT INTO olala_uploads_tmp VALUES('1879','0','','1512201090');
INSERT INTO olala_uploads_tmp VALUES('1880','0','','1512201162');
INSERT INTO olala_uploads_tmp VALUES('1881','0','','1512201165');
INSERT INTO olala_uploads_tmp VALUES('2171','0','','1516139245');
INSERT INTO olala_uploads_tmp VALUES('1866','0','','1512199983');
INSERT INTO olala_uploads_tmp VALUES('1865','0','','1512199903');
INSERT INTO olala_uploads_tmp VALUES('1864','0','','1512199424');
INSERT INTO olala_uploads_tmp VALUES('1863','0','','1512199422');
INSERT INTO olala_uploads_tmp VALUES('1855','0','','1512195909');
INSERT INTO olala_uploads_tmp VALUES('1941','0','','1515214301');
INSERT INTO olala_uploads_tmp VALUES('2230','1','','1518025971');
INSERT INTO olala_uploads_tmp VALUES('1846','0','','1500602267');
INSERT INTO olala_uploads_tmp VALUES('1848','0','','1502208452');
INSERT INTO olala_uploads_tmp VALUES('1850','0','','1502293558');
INSERT INTO olala_uploads_tmp VALUES('1851','0','','1502522062');
INSERT INTO olala_uploads_tmp VALUES('1895','0','','1513580979');
INSERT INTO olala_uploads_tmp VALUES('1884','0','','1512355126');
INSERT INTO olala_uploads_tmp VALUES('2406','1','','1519832195');
INSERT INTO olala_uploads_tmp VALUES('2407','1','','1519835098');
INSERT INTO olala_uploads_tmp VALUES('2408','1','','1519835704');
INSERT INTO olala_uploads_tmp VALUES('2409','1','','1519836442');
INSERT INTO olala_uploads_tmp VALUES('2410','1','','1519836783');
INSERT INTO olala_uploads_tmp VALUES('2411','1','','1519837394');
INSERT INTO olala_uploads_tmp VALUES('2412','1','','1519837548');
INSERT INTO olala_uploads_tmp VALUES('2413','1','','1519837842');
INSERT INTO olala_uploads_tmp VALUES('2414','1','','1519838692');
INSERT INTO olala_uploads_tmp VALUES('2179','0','','1516898823');
INSERT INTO olala_uploads_tmp VALUES('2178','0','','1516898771');
INSERT INTO olala_uploads_tmp VALUES('2177','1','','1516677486');
INSERT INTO olala_uploads_tmp VALUES('2176','1','','1516677413');
INSERT INTO olala_uploads_tmp VALUES('2175','1','','1516677284');
INSERT INTO olala_uploads_tmp VALUES('1896','0','','1513611478');
INSERT INTO olala_uploads_tmp VALUES('1897','0','','1513612543');
INSERT INTO olala_uploads_tmp VALUES('1898','0','','1513612561');
INSERT INTO olala_uploads_tmp VALUES('1899','0','','1513613547');
INSERT INTO olala_uploads_tmp VALUES('1900','0','','1513613624');
INSERT INTO olala_uploads_tmp VALUES('1901','0','','1513613659');
INSERT INTO olala_uploads_tmp VALUES('1904','0','','1513614302');
INSERT INTO olala_uploads_tmp VALUES('1905','0','','1513615488');
INSERT INTO olala_uploads_tmp VALUES('2170','0','','1516139232');
INSERT INTO olala_uploads_tmp VALUES('2169','0','','1516139163');
INSERT INTO olala_uploads_tmp VALUES('2168','0','','1516139161');
INSERT INTO olala_uploads_tmp VALUES('1914','0','','1513667575');
INSERT INTO olala_uploads_tmp VALUES('1915','0','','1513667630');
INSERT INTO olala_uploads_tmp VALUES('1923','0','','1513753446');
INSERT INTO olala_uploads_tmp VALUES('1917','0','','1513667813');
INSERT INTO olala_uploads_tmp VALUES('1922','0','','1513744161');
INSERT INTO olala_uploads_tmp VALUES('1921','0','','1513741762');
INSERT INTO olala_uploads_tmp VALUES('1924','0','','1513761677');
INSERT INTO olala_uploads_tmp VALUES('1925','0','','1513761807');
INSERT INTO olala_uploads_tmp VALUES('1940','0','','1514649365');
INSERT INTO olala_uploads_tmp VALUES('1927','0','','1513777098');
INSERT INTO olala_uploads_tmp VALUES('1928','0','','1513788910');
INSERT INTO olala_uploads_tmp VALUES('1929','0','','1513788912');
INSERT INTO olala_uploads_tmp VALUES('1930','0','','1513789012');
INSERT INTO olala_uploads_tmp VALUES('1931','0','','1513930085');
INSERT INTO olala_uploads_tmp VALUES('1932','0','','1513930095');
INSERT INTO olala_uploads_tmp VALUES('1933','0','','1513930419');
INSERT INTO olala_uploads_tmp VALUES('1934','0','','1513930437');
INSERT INTO olala_uploads_tmp VALUES('1935','0','','1513930488');
INSERT INTO olala_uploads_tmp VALUES('1936','0','','1513930504');
INSERT INTO olala_uploads_tmp VALUES('1937','0','','1513930650');
INSERT INTO olala_uploads_tmp VALUES('1938','0','','1514195304');
INSERT INTO olala_uploads_tmp VALUES('1939','0','','1514195323');
INSERT INTO olala_uploads_tmp VALUES('1942','0','','1515214599');
INSERT INTO olala_uploads_tmp VALUES('1943','0','','1515214669');
INSERT INTO olala_uploads_tmp VALUES('1944','0','','1515214689');
INSERT INTO olala_uploads_tmp VALUES('1945','0','','1515214694');
INSERT INTO olala_uploads_tmp VALUES('1946','0','','1515214709');
INSERT INTO olala_uploads_tmp VALUES('1947','0','','1515214762');
INSERT INTO olala_uploads_tmp VALUES('1948','0','','1515214922');
INSERT INTO olala_uploads_tmp VALUES('1949','0','','1515215198');
INSERT INTO olala_uploads_tmp VALUES('1950','0','','1515401574');
INSERT INTO olala_uploads_tmp VALUES('1951','0','','1515401577');
INSERT INTO olala_uploads_tmp VALUES('1952','0','','1515401954');
INSERT INTO olala_uploads_tmp VALUES('1953','0','','1515401967');
INSERT INTO olala_uploads_tmp VALUES('1954','0','','1515401977');
INSERT INTO olala_uploads_tmp VALUES('1955','0','','1515402106');
INSERT INTO olala_uploads_tmp VALUES('1956','0','','1515402607');
INSERT INTO olala_uploads_tmp VALUES('1957','0','','1515402610');
INSERT INTO olala_uploads_tmp VALUES('1958','0','','1515402623');
INSERT INTO olala_uploads_tmp VALUES('1959','0','','1515402689');
INSERT INTO olala_uploads_tmp VALUES('1960','0','','1515402694');
INSERT INTO olala_uploads_tmp VALUES('1961','0','','1515402754');
INSERT INTO olala_uploads_tmp VALUES('1962','0','','1515402908');
INSERT INTO olala_uploads_tmp VALUES('1963','0','','1515402945');
INSERT INTO olala_uploads_tmp VALUES('1964','0','','1515402970');
INSERT INTO olala_uploads_tmp VALUES('1965','0','','1515403040');
INSERT INTO olala_uploads_tmp VALUES('1966','0','','1515403042');
INSERT INTO olala_uploads_tmp VALUES('1967','0','','1515403170');
INSERT INTO olala_uploads_tmp VALUES('1968','0','','1515403183');
INSERT INTO olala_uploads_tmp VALUES('1969','0','','1515403187');
INSERT INTO olala_uploads_tmp VALUES('1970','0','','1515403190');
INSERT INTO olala_uploads_tmp VALUES('1971','0','','1515403598');
INSERT INTO olala_uploads_tmp VALUES('1972','0','','1515404112');
INSERT INTO olala_uploads_tmp VALUES('1973','0','','1515404245');
INSERT INTO olala_uploads_tmp VALUES('1974','0','','1515404286');
INSERT INTO olala_uploads_tmp VALUES('1975','0','','1515404316');
INSERT INTO olala_uploads_tmp VALUES('1976','0','','1515404356');
INSERT INTO olala_uploads_tmp VALUES('1977','0','','1515404446');
INSERT INTO olala_uploads_tmp VALUES('1978','0','','1515404454');
INSERT INTO olala_uploads_tmp VALUES('1979','0','','1515404500');
INSERT INTO olala_uploads_tmp VALUES('1980','0','','1515404546');
INSERT INTO olala_uploads_tmp VALUES('1981','0','','1515404561');
INSERT INTO olala_uploads_tmp VALUES('1982','0','','1515404619');
INSERT INTO olala_uploads_tmp VALUES('1983','0','','1515404667');
INSERT INTO olala_uploads_tmp VALUES('1984','0','','1515404719');
INSERT INTO olala_uploads_tmp VALUES('1985','0','','1515405018');
INSERT INTO olala_uploads_tmp VALUES('1986','0','','1515405094');
INSERT INTO olala_uploads_tmp VALUES('1987','0','','1515405094');
INSERT INTO olala_uploads_tmp VALUES('1988','0','','1515405099');
INSERT INTO olala_uploads_tmp VALUES('1989','0','','1515405141');
INSERT INTO olala_uploads_tmp VALUES('1990','0','','1515405152');
INSERT INTO olala_uploads_tmp VALUES('1991','0','','1515405159');
INSERT INTO olala_uploads_tmp VALUES('1992','0','','1515405257');
INSERT INTO olala_uploads_tmp VALUES('1993','0','','1515405376');
INSERT INTO olala_uploads_tmp VALUES('1994','0','','1515405550');
INSERT INTO olala_uploads_tmp VALUES('1995','0','','1515405571');
INSERT INTO olala_uploads_tmp VALUES('1996','0','','1515405613');
INSERT INTO olala_uploads_tmp VALUES('1997','0','','1515405657');
INSERT INTO olala_uploads_tmp VALUES('1998','0','','1515405709');
INSERT INTO olala_uploads_tmp VALUES('1999','0','','1515405750');
INSERT INTO olala_uploads_tmp VALUES('2000','0','','1515405763');
INSERT INTO olala_uploads_tmp VALUES('2001','0','','1515448172');
INSERT INTO olala_uploads_tmp VALUES('2002','0','','1515448187');
INSERT INTO olala_uploads_tmp VALUES('2003','0','','1515448342');
INSERT INTO olala_uploads_tmp VALUES('2004','0','','1515448342');
INSERT INTO olala_uploads_tmp VALUES('2005','0','','1515448350');
INSERT INTO olala_uploads_tmp VALUES('2006','0','','1515448459');
INSERT INTO olala_uploads_tmp VALUES('2007','0','','1515448632');
INSERT INTO olala_uploads_tmp VALUES('2008','0','','1515448654');
INSERT INTO olala_uploads_tmp VALUES('2009','0','','1515449804');
INSERT INTO olala_uploads_tmp VALUES('2010','0','','1515449812');
INSERT INTO olala_uploads_tmp VALUES('2011','0','','1515449870');
INSERT INTO olala_uploads_tmp VALUES('2012','0','','1515449875');
INSERT INTO olala_uploads_tmp VALUES('2013','0','','1515450054');
INSERT INTO olala_uploads_tmp VALUES('2014','0','','1515450066');
INSERT INTO olala_uploads_tmp VALUES('2015','0','','1515450128');
INSERT INTO olala_uploads_tmp VALUES('2016','0','','1515450378');
INSERT INTO olala_uploads_tmp VALUES('2017','0','','1515450429');
INSERT INTO olala_uploads_tmp VALUES('2018','0','','1515450493');
INSERT INTO olala_uploads_tmp VALUES('2019','0','','1515450512');
INSERT INTO olala_uploads_tmp VALUES('2020','0','','1515450524');
INSERT INTO olala_uploads_tmp VALUES('2021','0','','1515450590');
INSERT INTO olala_uploads_tmp VALUES('2022','0','','1515450905');
INSERT INTO olala_uploads_tmp VALUES('2023','0','','1515450936');
INSERT INTO olala_uploads_tmp VALUES('2024','0','','1515451033');
INSERT INTO olala_uploads_tmp VALUES('2025','0','','1515451075');
INSERT INTO olala_uploads_tmp VALUES('2026','0','','1515451102');
INSERT INTO olala_uploads_tmp VALUES('2027','0','','1515451209');
INSERT INTO olala_uploads_tmp VALUES('2028','0','','1515451215');
INSERT INTO olala_uploads_tmp VALUES('2029','0','','1515451399');
INSERT INTO olala_uploads_tmp VALUES('2030','0','','1515451614');
INSERT INTO olala_uploads_tmp VALUES('2031','0','','1515451725');
INSERT INTO olala_uploads_tmp VALUES('2032','0','','1515451903');
INSERT INTO olala_uploads_tmp VALUES('2033','0','','1515451916');
INSERT INTO olala_uploads_tmp VALUES('2034','0','','1515451943');
INSERT INTO olala_uploads_tmp VALUES('2035','0','','1515452284');
INSERT INTO olala_uploads_tmp VALUES('2036','0','','1515453283');
INSERT INTO olala_uploads_tmp VALUES('2037','0','','1515453296');
INSERT INTO olala_uploads_tmp VALUES('2038','0','','1515453325');
INSERT INTO olala_uploads_tmp VALUES('2039','0','','1515453345');
INSERT INTO olala_uploads_tmp VALUES('2040','0','','1515453628');
INSERT INTO olala_uploads_tmp VALUES('2041','0','','1515453633');
INSERT INTO olala_uploads_tmp VALUES('2042','0','','1515454042');
INSERT INTO olala_uploads_tmp VALUES('2043','0','','1515454688');
INSERT INTO olala_uploads_tmp VALUES('2044','0','','1515454692');
INSERT INTO olala_uploads_tmp VALUES('2045','0','','1515454742');
INSERT INTO olala_uploads_tmp VALUES('2046','0','','1515455314');
INSERT INTO olala_uploads_tmp VALUES('2047','0','','1515455321');
INSERT INTO olala_uploads_tmp VALUES('2048','0','','1515455343');
INSERT INTO olala_uploads_tmp VALUES('2049','0','','1515455517');
INSERT INTO olala_uploads_tmp VALUES('2050','0','','1515455524');
INSERT INTO olala_uploads_tmp VALUES('2051','0','','1515455524');
INSERT INTO olala_uploads_tmp VALUES('2052','0','','1515455545');
INSERT INTO olala_uploads_tmp VALUES('2053','0','','1515455554');
INSERT INTO olala_uploads_tmp VALUES('2054','0','','1515455572');
INSERT INTO olala_uploads_tmp VALUES('2055','0','','1515455596');
INSERT INTO olala_uploads_tmp VALUES('2056','0','','1515455643');
INSERT INTO olala_uploads_tmp VALUES('2057','0','','1515455792');
INSERT INTO olala_uploads_tmp VALUES('2058','0','','1515455828');
INSERT INTO olala_uploads_tmp VALUES('2059','0','','1515455941');
INSERT INTO olala_uploads_tmp VALUES('2060','0','','1515455978');
INSERT INTO olala_uploads_tmp VALUES('2061','0','','1515456004');
INSERT INTO olala_uploads_tmp VALUES('2062','0','','1515456057');
INSERT INTO olala_uploads_tmp VALUES('2063','0','','1515456083');
INSERT INTO olala_uploads_tmp VALUES('2064','0','','1515456302');
INSERT INTO olala_uploads_tmp VALUES('2065','0','','1515456362');
INSERT INTO olala_uploads_tmp VALUES('2066','0','','1515456392');
INSERT INTO olala_uploads_tmp VALUES('2067','0','','1515456687');
INSERT INTO olala_uploads_tmp VALUES('2068','0','','1515456706');
INSERT INTO olala_uploads_tmp VALUES('2069','0','','1515456736');
INSERT INTO olala_uploads_tmp VALUES('2070','0','','1515456803');
INSERT INTO olala_uploads_tmp VALUES('2071','0','','1515456833');
INSERT INTO olala_uploads_tmp VALUES('2072','0','','1515456919');
INSERT INTO olala_uploads_tmp VALUES('2073','0','','1515456940');
INSERT INTO olala_uploads_tmp VALUES('2074','0','','1515456967');
INSERT INTO olala_uploads_tmp VALUES('2075','0','','1515456985');
INSERT INTO olala_uploads_tmp VALUES('2076','0','','1515457026');
INSERT INTO olala_uploads_tmp VALUES('2077','0','','1515457039');
INSERT INTO olala_uploads_tmp VALUES('2078','0','','1515457136');
INSERT INTO olala_uploads_tmp VALUES('2079','0','','1515457152');
INSERT INTO olala_uploads_tmp VALUES('2080','0','','1515457166');
INSERT INTO olala_uploads_tmp VALUES('2081','0','','1515457182');
INSERT INTO olala_uploads_tmp VALUES('2082','0','','1515457197');
INSERT INTO olala_uploads_tmp VALUES('2083','0','','1515457205');
INSERT INTO olala_uploads_tmp VALUES('2084','0','','1515457213');
INSERT INTO olala_uploads_tmp VALUES('2085','0','','1515457227');
INSERT INTO olala_uploads_tmp VALUES('2086','0','','1515457326');
INSERT INTO olala_uploads_tmp VALUES('2087','0','','1515457404');
INSERT INTO olala_uploads_tmp VALUES('2088','0','','1515457454');
INSERT INTO olala_uploads_tmp VALUES('2089','0','','1515457491');
INSERT INTO olala_uploads_tmp VALUES('2090','0','','1515457493');
INSERT INTO olala_uploads_tmp VALUES('2091','0','','1515457580');
INSERT INTO olala_uploads_tmp VALUES('2092','0','','1515457619');
INSERT INTO olala_uploads_tmp VALUES('2093','0','','1515457620');
INSERT INTO olala_uploads_tmp VALUES('2094','0','','1515458002');
INSERT INTO olala_uploads_tmp VALUES('2095','0','','1515458045');
INSERT INTO olala_uploads_tmp VALUES('2096','0','','1515458108');
INSERT INTO olala_uploads_tmp VALUES('2097','0','','1515467254');
INSERT INTO olala_uploads_tmp VALUES('2098','0','','1515467337');
INSERT INTO olala_uploads_tmp VALUES('2099','0','','1515467700');
INSERT INTO olala_uploads_tmp VALUES('2100','0','','1515467768');
INSERT INTO olala_uploads_tmp VALUES('2101','0','','1515467971');
INSERT INTO olala_uploads_tmp VALUES('2102','0','','1515467999');
INSERT INTO olala_uploads_tmp VALUES('2103','0','','1515468461');
INSERT INTO olala_uploads_tmp VALUES('2104','0','','1515469672');
INSERT INTO olala_uploads_tmp VALUES('2105','0','','1515471848');
INSERT INTO olala_uploads_tmp VALUES('2106','0','','1515471850');
INSERT INTO olala_uploads_tmp VALUES('2107','0','','1515516672');
INSERT INTO olala_uploads_tmp VALUES('2108','0','','1515517106');
INSERT INTO olala_uploads_tmp VALUES('2109','0','','1515517127');
INSERT INTO olala_uploads_tmp VALUES('2110','0','','1515517129');
INSERT INTO olala_uploads_tmp VALUES('2111','0','','1515518223');
INSERT INTO olala_uploads_tmp VALUES('2112','0','','1515518280');
INSERT INTO olala_uploads_tmp VALUES('2113','0','','1515518331');
INSERT INTO olala_uploads_tmp VALUES('2114','0','','1515518401');
INSERT INTO olala_uploads_tmp VALUES('2115','0','','1515518610');
INSERT INTO olala_uploads_tmp VALUES('2116','0','','1515518616');
INSERT INTO olala_uploads_tmp VALUES('2117','0','','1515518748');
INSERT INTO olala_uploads_tmp VALUES('2118','0','','1515518776');
INSERT INTO olala_uploads_tmp VALUES('2119','0','','1515518911');
INSERT INTO olala_uploads_tmp VALUES('2120','0','','1515519168');
INSERT INTO olala_uploads_tmp VALUES('2121','0','','1515519243');
INSERT INTO olala_uploads_tmp VALUES('2122','0','','1515520821');
INSERT INTO olala_uploads_tmp VALUES('2123','0','','1515520993');
INSERT INTO olala_uploads_tmp VALUES('2124','0','','1515521010');
INSERT INTO olala_uploads_tmp VALUES('2125','0','','1515521010');
INSERT INTO olala_uploads_tmp VALUES('2126','0','','1515521190');
INSERT INTO olala_uploads_tmp VALUES('2127','0','','1515521190');
INSERT INTO olala_uploads_tmp VALUES('2128','0','','1515521190');
INSERT INTO olala_uploads_tmp VALUES('2129','0','','1515524381');
INSERT INTO olala_uploads_tmp VALUES('2130','0','','1515524703');
INSERT INTO olala_uploads_tmp VALUES('2131','0','','1515552176');
INSERT INTO olala_uploads_tmp VALUES('2132','0','','1515552289');
INSERT INTO olala_uploads_tmp VALUES('2133','0','','1515554338');
INSERT INTO olala_uploads_tmp VALUES('2134','0','','1515554368');
INSERT INTO olala_uploads_tmp VALUES('2135','0','','1515554369');
INSERT INTO olala_uploads_tmp VALUES('2136','0','','1515554510');
INSERT INTO olala_uploads_tmp VALUES('2137','0','','1515554512');
INSERT INTO olala_uploads_tmp VALUES('2138','0','','1515624298');
INSERT INTO olala_uploads_tmp VALUES('2139','0','','1515626737');
INSERT INTO olala_uploads_tmp VALUES('2140','0','','1515645038');
INSERT INTO olala_uploads_tmp VALUES('2141','0','','1515651326');
INSERT INTO olala_uploads_tmp VALUES('2142','0','','1515651363');
INSERT INTO olala_uploads_tmp VALUES('2143','0','','1515651380');
INSERT INTO olala_uploads_tmp VALUES('2144','0','','1515651452');
INSERT INTO olala_uploads_tmp VALUES('2145','0','','1515651521');
INSERT INTO olala_uploads_tmp VALUES('2146','0','','1515653076');
INSERT INTO olala_uploads_tmp VALUES('2147','0','','1515653131');
INSERT INTO olala_uploads_tmp VALUES('2148','0','','1515653295');
INSERT INTO olala_uploads_tmp VALUES('2149','0','','1515653300');
INSERT INTO olala_uploads_tmp VALUES('2150','0','','1515653343');
INSERT INTO olala_uploads_tmp VALUES('2151','0','','1515653379');
INSERT INTO olala_uploads_tmp VALUES('2152','0','','1515653463');
INSERT INTO olala_uploads_tmp VALUES('2153','0','','1515653789');
INSERT INTO olala_uploads_tmp VALUES('2154','0','','1515653798');
INSERT INTO olala_uploads_tmp VALUES('2155','0','','1515653823');
INSERT INTO olala_uploads_tmp VALUES('2156','0','','1515654036');
INSERT INTO olala_uploads_tmp VALUES('2157','0','','1515654222');
INSERT INTO olala_uploads_tmp VALUES('2158','0','','1515654285');
INSERT INTO olala_uploads_tmp VALUES('2159','0','','1515654476');
INSERT INTO olala_uploads_tmp VALUES('2160','0','','1515654478');
INSERT INTO olala_uploads_tmp VALUES('2161','0','','1515654479');
INSERT INTO olala_uploads_tmp VALUES('2162','0','','1515654646');
INSERT INTO olala_uploads_tmp VALUES('2163','0','','1515654656');
INSERT INTO olala_uploads_tmp VALUES('2164','0','','1515654657');
INSERT INTO olala_uploads_tmp VALUES('2165','0','','1515654657');
INSERT INTO olala_uploads_tmp VALUES('2166','0','','1515654657');
INSERT INTO olala_uploads_tmp VALUES('2167','0','','1515660330');
INSERT INTO olala_uploads_tmp VALUES('2183','1','','1516985812');
INSERT INTO olala_uploads_tmp VALUES('2184','0','','1516987127');
INSERT INTO olala_uploads_tmp VALUES('2185','0','','1516987225');
INSERT INTO olala_uploads_tmp VALUES('2186','0','','1516987567');
INSERT INTO olala_uploads_tmp VALUES('2187','0','','1516988575');
INSERT INTO olala_uploads_tmp VALUES('2188','0','','1516989166');
INSERT INTO olala_uploads_tmp VALUES('2189','0','','1516989358');
INSERT INTO olala_uploads_tmp VALUES('2190','0','','1516989363');
INSERT INTO olala_uploads_tmp VALUES('2191','0','','1516989386');
INSERT INTO olala_uploads_tmp VALUES('2192','0','','1517021922');
INSERT INTO olala_uploads_tmp VALUES('2193','0','','1517023207');
INSERT INTO olala_uploads_tmp VALUES('2194','0','','1517023215');
INSERT INTO olala_uploads_tmp VALUES('2195','0','','1517023238');
INSERT INTO olala_uploads_tmp VALUES('2196','0','','1517023460');
INSERT INTO olala_uploads_tmp VALUES('2197','0','','1517023619');
INSERT INTO olala_uploads_tmp VALUES('2198','0','','1517023650');
INSERT INTO olala_uploads_tmp VALUES('2199','0','','1517023700');
INSERT INTO olala_uploads_tmp VALUES('2200','0','','1517023985');
INSERT INTO olala_uploads_tmp VALUES('2201','0','','1517023992');
INSERT INTO olala_uploads_tmp VALUES('2202','0','','1517024000');
INSERT INTO olala_uploads_tmp VALUES('2203','0','','1517024313');
INSERT INTO olala_uploads_tmp VALUES('2204','0','','1517128617');
INSERT INTO olala_uploads_tmp VALUES('2205','0','','1517128632');
INSERT INTO olala_uploads_tmp VALUES('2206','1','','1517218585');
INSERT INTO olala_uploads_tmp VALUES('2207','1','','1517220102');
INSERT INTO olala_uploads_tmp VALUES('2208','1','','1517626608');
INSERT INTO olala_uploads_tmp VALUES('2209','1','','1517626690');
INSERT INTO olala_uploads_tmp VALUES('2240','0','','1519444177');
INSERT INTO olala_uploads_tmp VALUES('2211','1','','1517626879');
INSERT INTO olala_uploads_tmp VALUES('2405','0','','1519832104');
INSERT INTO olala_uploads_tmp VALUES('2404','1','1519876802_2404_911c195710b7f869c32c6d5cd7251839.jpg;1519876802_2404_d5708621a21425803c5a100d374c3b68.jpg;1519876803_2404_be02917e44c17fa312dfd30727823082.jpg;1519876803_2404_d7c80768484d12f6cb1a543454ea9860.jpg;1519876804_2404_5056aca984b96d84782be49a6de0cf72.jpg;1519876804_2404_4e743addcd772190cc7672c99d30f8a3.jpg;1519876805_2404_a618354826c1e784956f115336dab726.jpg;1519876805_2404_e601e17d1fcdd8f2cf18d6a8ea0bcef9.jpg;1519876818_2404_c376dce3e660d2c14bd3f02a5f897d49.jpg;1519876818_2404_c286911a5a601addaa964fc8bfec1fd0.jpg;1519876819_2404_a238acc78471e3791c8f4927e0ff8325.jpg;1519876819_2404_6f3a40632e7b3a875c78418be3273614.jpg;1519876820_2404_d1a732af66dd9c73ebd3d178a8a142a9.jpg;1519876821_2404_980c8cd4b967d261e9b0d5fee0d42aed.jpg;','1519809549');
INSERT INTO olala_uploads_tmp VALUES('2403','1','1519875141_2403_ac23257fb9505c520d9293ff508b9b04.png;1519875141_2403_d869d9b8798491151b9f0f813b6e2cd2.png;1519875142_2403_6b4b780bccfaa59c1cd8b9b86eef895e.png;1519875142_2403_3cabbb4f059a4a9c666ed4703fd171b3.png;1519875142_2403_1f938d8aea931a8c7a825430f2d7cb03.png;1519875143_2403_5b84f0bee2237ab86ca44733d9572fed.png;1519875143_2403_7b75b57bc35a55083e0f728eafb6e43d.png;1519875143_2403_dcc176f488c89d3829b9c10515b5948a.png;1519875144_2403_8e6a8392211d9f2ac05be9e67a231edf.png;1519875144_2403_52ee7db167af35959bff9c8fdb104dc8.png;1519875157_2403_db1f311a7476b49e5410476cd3943889.png;1519875158_2403_362994a2aacc5f1980a8a0854a2fecc5.png;1519875158_2403_bffb6bb46c9df4eabf98f88b67c0db6d.png;1519875158_2403_7a78bc8334b728cc6498f2bf310a8b0b.png;1519875159_2403_91931c1a5071ca707895f2459cf0c7a6.png;1519875159_2403_21921fac80ad55163d448a0c7d8a58aa.png;1519875159_2403_0f232e958b55102fef6aa6cbac0874f0.png;1519875160_2403_402b0b2322f19912ea485d275674959a.png;1519875160_2403_96ef83f2037b66a6a71ed501ffe903ac.png;1519875161_2403_f2394c24ab4b2e895bb51f97ad9811d2.jpg;1519875215_2403_ed08ad021a1d795b66531412d36d23cb.jpg;1519875216_2403_bf2f33507ff1e77d5bd7fc469a4059c2.jpg;1519875216_2403_fe9b342791509aaa28c5f8a80b7a94fb.jpg;1519875216_2403_ce792f909e120ee293abc1b1110ac72c.jpg;1519875217_2403_b21bb7c1cd59b9ba511dd49b73ac3184.jpg;1519875217_2403_b0f5592fe30e05fd95e98d3f6d5867c5.jpg;1519875218_2403_1abd221b8d61a36dcce7ac443b81fb8d.jpg;1519875219_2403_e2f09dcc7b2371f7536bc5ccce8555c5.jpg;1519875221_2403_9178a739a48c91ceb76acd7e9e8d3fed.jpg;1519875223_2403_39d4ac90ee298e9729886b250428faa2.jpg;1519875238_2403_21947a735e07994ba3f03b2c1d4c4de1.jpg;1519875239_2403_a13b39ff8853b1bc9291adfba06e64aa.jpg;1519875240_2403_08df8c3c6f62ebed829cfb3ea4e58cf0.jpg;1519875240_2403_6433b2f7912b79059be5a65f08ef78a6.jpg;1519875240_2403_bbf1584567a7587c4774aa169820af9b.jpg;1519875241_2403_67cc33e613e8f091e821dc8d9b4749a6.jpg;','1519808456');
INSERT INTO olala_uploads_tmp VALUES('2239','0','','1519444170');
INSERT INTO olala_uploads_tmp VALUES('2238','0','','1518134077');
INSERT INTO olala_uploads_tmp VALUES('2237','0','','1518131968');
INSERT INTO olala_uploads_tmp VALUES('2220','1','','1517629032');
INSERT INTO olala_uploads_tmp VALUES('2221','1','','1517630417');
INSERT INTO olala_uploads_tmp VALUES('2222','1','','1517630674');
INSERT INTO olala_uploads_tmp VALUES('2223','0','','1517631008');
INSERT INTO olala_uploads_tmp VALUES('2236','0','','1518131944');
INSERT INTO olala_uploads_tmp VALUES('2235','0','','1518130013');
INSERT INTO olala_uploads_tmp VALUES('2234','1','','1518026225');
INSERT INTO olala_uploads_tmp VALUES('2233','1','','1518026184');
INSERT INTO olala_uploads_tmp VALUES('2232','1','','1518026146');
INSERT INTO olala_uploads_tmp VALUES('2231','1','','1518026114');
INSERT INTO olala_uploads_tmp VALUES('2241','0','','1519444238');
INSERT INTO olala_uploads_tmp VALUES('2242','0','','1519444241');
INSERT INTO olala_uploads_tmp VALUES('2243','0','','1519444255');
INSERT INTO olala_uploads_tmp VALUES('2244','0','','1519445287');
INSERT INTO olala_uploads_tmp VALUES('2245','0','','1519445308');
INSERT INTO olala_uploads_tmp VALUES('2246','0','','1519445308');
INSERT INTO olala_uploads_tmp VALUES('2247','0','','1519445328');
INSERT INTO olala_uploads_tmp VALUES('2248','0','','1519445782');
INSERT INTO olala_uploads_tmp VALUES('2249','0','','1519446085');
INSERT INTO olala_uploads_tmp VALUES('2250','0','','1519446262');
INSERT INTO olala_uploads_tmp VALUES('2251','0','','1519446332');
INSERT INTO olala_uploads_tmp VALUES('2252','0','','1519446416');
INSERT INTO olala_uploads_tmp VALUES('2253','0','','1519446484');
INSERT INTO olala_uploads_tmp VALUES('2254','0','','1519446586');
INSERT INTO olala_uploads_tmp VALUES('2255','0','','1519446587');
INSERT INTO olala_uploads_tmp VALUES('2256','0','','1519453153');
INSERT INTO olala_uploads_tmp VALUES('2257','0','','1519456477');
INSERT INTO olala_uploads_tmp VALUES('2258','0','','1519458704');
INSERT INTO olala_uploads_tmp VALUES('2259','0','','1519458800');
INSERT INTO olala_uploads_tmp VALUES('2260','0','','1519613315');
INSERT INTO olala_uploads_tmp VALUES('2261','0','','1519613392');
INSERT INTO olala_uploads_tmp VALUES('2262','0','','1519613515');
INSERT INTO olala_uploads_tmp VALUES('2263','0','','1519613520');
INSERT INTO olala_uploads_tmp VALUES('2264','0','','1519613521');
INSERT INTO olala_uploads_tmp VALUES('2265','0','','1519613522');
INSERT INTO olala_uploads_tmp VALUES('2266','0','','1519613751');
INSERT INTO olala_uploads_tmp VALUES('2267','0','','1519613785');
INSERT INTO olala_uploads_tmp VALUES('2268','0','','1519613795');
INSERT INTO olala_uploads_tmp VALUES('2269','0','','1519628355');
INSERT INTO olala_uploads_tmp VALUES('2270','0','','1519628364');
INSERT INTO olala_uploads_tmp VALUES('2271','0','','1519628365');
INSERT INTO olala_uploads_tmp VALUES('2272','0','','1519628365');
INSERT INTO olala_uploads_tmp VALUES('2273','0','','1519628365');
INSERT INTO olala_uploads_tmp VALUES('2274','0','','1519628366');
INSERT INTO olala_uploads_tmp VALUES('2275','0','','1519628366');
INSERT INTO olala_uploads_tmp VALUES('2276','0','','1519628366');
INSERT INTO olala_uploads_tmp VALUES('2277','0','','1519628366');
INSERT INTO olala_uploads_tmp VALUES('2278','0','','1519628419');
INSERT INTO olala_uploads_tmp VALUES('2279','0','','1519628422');
INSERT INTO olala_uploads_tmp VALUES('2280','0','','1519628595');
INSERT INTO olala_uploads_tmp VALUES('2281','0','','1519628656');
INSERT INTO olala_uploads_tmp VALUES('2282','0','','1519628656');
INSERT INTO olala_uploads_tmp VALUES('2283','0','','1519628656');
INSERT INTO olala_uploads_tmp VALUES('2284','0','','1519628657');
INSERT INTO olala_uploads_tmp VALUES('2285','0','','1519628657');
INSERT INTO olala_uploads_tmp VALUES('2286','0','','1519628657');
INSERT INTO olala_uploads_tmp VALUES('2287','0','','1519628657');
INSERT INTO olala_uploads_tmp VALUES('2288','0','','1519628657');
INSERT INTO olala_uploads_tmp VALUES('2289','0','','1519628657');
INSERT INTO olala_uploads_tmp VALUES('2290','0','','1519628663');
INSERT INTO olala_uploads_tmp VALUES('2291','0','','1519628663');
INSERT INTO olala_uploads_tmp VALUES('2292','0','','1519628663');
INSERT INTO olala_uploads_tmp VALUES('2293','0','','1519628664');
INSERT INTO olala_uploads_tmp VALUES('2294','0','','1519628664');
INSERT INTO olala_uploads_tmp VALUES('2295','0','','1519629479');
INSERT INTO olala_uploads_tmp VALUES('2296','0','','1519629482');
INSERT INTO olala_uploads_tmp VALUES('2297','0','','1519631569');
INSERT INTO olala_uploads_tmp VALUES('2298','0','','1519631703');
INSERT INTO olala_uploads_tmp VALUES('2299','0','','1519631794');
INSERT INTO olala_uploads_tmp VALUES('2300','0','','1519631796');
INSERT INTO olala_uploads_tmp VALUES('2301','0','','1519632616');
INSERT INTO olala_uploads_tmp VALUES('2302','0','','1519633405');
INSERT INTO olala_uploads_tmp VALUES('2303','0','','1519633406');
INSERT INTO olala_uploads_tmp VALUES('2304','0','','1519633449');
INSERT INTO olala_uploads_tmp VALUES('2305','0','','1519633451');
INSERT INTO olala_uploads_tmp VALUES('2306','0','','1519633454');
INSERT INTO olala_uploads_tmp VALUES('2307','0','','1519633460');
INSERT INTO olala_uploads_tmp VALUES('2308','0','','1519633481');
INSERT INTO olala_uploads_tmp VALUES('2309','0','','1519633559');
INSERT INTO olala_uploads_tmp VALUES('2310','0','','1519635470');
INSERT INTO olala_uploads_tmp VALUES('2311','0','','1519635479');
INSERT INTO olala_uploads_tmp VALUES('2312','0','','1519635497');
INSERT INTO olala_uploads_tmp VALUES('2313','0','','1519635503');
INSERT INTO olala_uploads_tmp VALUES('2314','0','','1519635505');
INSERT INTO olala_uploads_tmp VALUES('2315','0','','1519635547');
INSERT INTO olala_uploads_tmp VALUES('2316','0','','1519635672');
INSERT INTO olala_uploads_tmp VALUES('2317','0','','1519635680');
INSERT INTO olala_uploads_tmp VALUES('2318','0','','1519635735');
INSERT INTO olala_uploads_tmp VALUES('2319','0','','1519635738');
INSERT INTO olala_uploads_tmp VALUES('2320','0','','1519635773');
INSERT INTO olala_uploads_tmp VALUES('2321','0','','1519635798');
INSERT INTO olala_uploads_tmp VALUES('2322','0','','1519635837');
INSERT INTO olala_uploads_tmp VALUES('2323','0','','1519635868');
INSERT INTO olala_uploads_tmp VALUES('2324','0','','1519635870');
INSERT INTO olala_uploads_tmp VALUES('2325','0','','1519635872');
INSERT INTO olala_uploads_tmp VALUES('2326','0','','1519635872');
INSERT INTO olala_uploads_tmp VALUES('2327','0','','1519636078');
INSERT INTO olala_uploads_tmp VALUES('2328','0','','1519636105');
INSERT INTO olala_uploads_tmp VALUES('2329','0','','1519636238');
INSERT INTO olala_uploads_tmp VALUES('2330','0','','1519636256');
INSERT INTO olala_uploads_tmp VALUES('2331','0','','1519636257');
INSERT INTO olala_uploads_tmp VALUES('2332','0','','1519636259');
INSERT INTO olala_uploads_tmp VALUES('2333','0','','1519636498');
INSERT INTO olala_uploads_tmp VALUES('2334','0','','1519637121');
INSERT INTO olala_uploads_tmp VALUES('2335','0','','1519637404');
INSERT INTO olala_uploads_tmp VALUES('2336','0','','1519637434');
INSERT INTO olala_uploads_tmp VALUES('2337','0','','1519637436');
INSERT INTO olala_uploads_tmp VALUES('2338','0','','1519637454');
INSERT INTO olala_uploads_tmp VALUES('2339','0','','1519637608');
INSERT INTO olala_uploads_tmp VALUES('2340','0','','1519637680');
INSERT INTO olala_uploads_tmp VALUES('2341','0','','1519637700');
INSERT INTO olala_uploads_tmp VALUES('2342','0','','1519637750');
INSERT INTO olala_uploads_tmp VALUES('2343','0','','1519637930');
INSERT INTO olala_uploads_tmp VALUES('2344','0','','1519638027');
INSERT INTO olala_uploads_tmp VALUES('2345','0','','1519638280');
INSERT INTO olala_uploads_tmp VALUES('2346','0','','1519638788');
INSERT INTO olala_uploads_tmp VALUES('2347','0','','1519638801');
INSERT INTO olala_uploads_tmp VALUES('2348','0','','1519638802');
INSERT INTO olala_uploads_tmp VALUES('2349','0','','1519638802');
INSERT INTO olala_uploads_tmp VALUES('2350','0','','1519638802');
INSERT INTO olala_uploads_tmp VALUES('2351','0','','1519638810');
INSERT INTO olala_uploads_tmp VALUES('2352','0','','1519638998');
INSERT INTO olala_uploads_tmp VALUES('2353','0','','1519639060');
INSERT INTO olala_uploads_tmp VALUES('2354','0','','1519639256');
INSERT INTO olala_uploads_tmp VALUES('2355','0','','1519639272');
INSERT INTO olala_uploads_tmp VALUES('2356','0','','1519699627');
INSERT INTO olala_uploads_tmp VALUES('2357','0','','1519699677');
INSERT INTO olala_uploads_tmp VALUES('2358','0','','1519699692');
INSERT INTO olala_uploads_tmp VALUES('2359','0','','1519700871');
INSERT INTO olala_uploads_tmp VALUES('2360','0','','1519700873');
INSERT INTO olala_uploads_tmp VALUES('2361','0','','1519701696');
INSERT INTO olala_uploads_tmp VALUES('2362','0','','1519701798');
INSERT INTO olala_uploads_tmp VALUES('2363','0','','1519701834');
INSERT INTO olala_uploads_tmp VALUES('2364','0','','1519701835');
INSERT INTO olala_uploads_tmp VALUES('2365','0','','1519701860');
INSERT INTO olala_uploads_tmp VALUES('2366','0','','1519701866');
INSERT INTO olala_uploads_tmp VALUES('2367','0','','1519701867');
INSERT INTO olala_uploads_tmp VALUES('2368','0','','1519701939');
INSERT INTO olala_uploads_tmp VALUES('2369','0','','1519701940');
INSERT INTO olala_uploads_tmp VALUES('2370','0','','1519702036');
INSERT INTO olala_uploads_tmp VALUES('2371','0','','1519702061');
INSERT INTO olala_uploads_tmp VALUES('2372','0','','1519702070');
INSERT INTO olala_uploads_tmp VALUES('2373','0','','1519702071');
INSERT INTO olala_uploads_tmp VALUES('2374','0','','1519702273');
INSERT INTO olala_uploads_tmp VALUES('2375','0','','1519702299');
INSERT INTO olala_uploads_tmp VALUES('2376','0','','1519702301');
INSERT INTO olala_uploads_tmp VALUES('2377','0','','1519702303');
INSERT INTO olala_uploads_tmp VALUES('2378','0','','1519702407');
INSERT INTO olala_uploads_tmp VALUES('2379','0','','1519702697');
INSERT INTO olala_uploads_tmp VALUES('2380','0','','1519702698');
INSERT INTO olala_uploads_tmp VALUES('2381','0','','1519702708');
INSERT INTO olala_uploads_tmp VALUES('2382','0','','1519702764');
INSERT INTO olala_uploads_tmp VALUES('2383','0','','1519702864');
INSERT INTO olala_uploads_tmp VALUES('2384','0','','1519702982');
INSERT INTO olala_uploads_tmp VALUES('2385','0','','1519703012');
INSERT INTO olala_uploads_tmp VALUES('2386','0','','1519703074');
INSERT INTO olala_uploads_tmp VALUES('2387','0','','1519703120');
INSERT INTO olala_uploads_tmp VALUES('2388','0','','1519703142');
INSERT INTO olala_uploads_tmp VALUES('2389','0','','1519703217');
INSERT INTO olala_uploads_tmp VALUES('2390','0','','1519703265');
INSERT INTO olala_uploads_tmp VALUES('2391','0','','1519703385');
INSERT INTO olala_uploads_tmp VALUES('2392','0','','1519703388');
INSERT INTO olala_uploads_tmp VALUES('2393','0','','1519703389');
INSERT INTO olala_uploads_tmp VALUES('2394','0','','1519703389');
INSERT INTO olala_uploads_tmp VALUES('2395','0','','1519703401');
INSERT INTO olala_uploads_tmp VALUES('2396','0','','1519703405');
INSERT INTO olala_uploads_tmp VALUES('2397','0','','1519703407');
INSERT INTO olala_uploads_tmp VALUES('2398','0','','1519703419');
INSERT INTO olala_uploads_tmp VALUES('2399','0','','1519703505');
INSERT INTO olala_uploads_tmp VALUES('2400','0','','1519704159');
INSERT INTO olala_uploads_tmp VALUES('2401','0','','1519704160');
INSERT INTO olala_uploads_tmp VALUES('2402','0','','1519791796');

-- --------------------------------------------------------

CREATE TABLE `olala_vote` (
  `vote_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `session` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `vote` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vote_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

